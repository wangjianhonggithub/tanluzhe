<?php 
namespace Admin\Controller;
/**
* 反馈控制器
*/
use Think\Controller;
class OtherController extends Controller
{	
	/**
	 * 租房反馈
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-09
	 * @Email    carlos0608@163.com
	 */
	public function Zufang()
	{
		$m = M('weituo');
		$count = $m->where('type=1')->count();
		$p = getpage($count,10);
		$list = $m->field(true)->where('type=1')->order('id desc')->limit($p->firstRow, $p->listRows)->select();
		$this->assign('result',$list);
		$this->assign('page', $p->show()); // 赋值分页输出
		$this->display();
	}
	/**
	 * 执行租房反馈
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-10
	 * @Email    carlos0608@163.com
	 */
	public function ZuFangFanKui()
	{
		$id = $_GET['id'];
		$result = M('weituo')->where("id=$id")->find();
		$this->assign('result',$result);
		$this->display();
	}
	/**
	 * 添加反馈
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-10
	 * @Email    carlos0608@163.com
	 */
	public function DoZuFangFanKui()
	{
		$data['fankui'] = I('post.fankui');
		$data['status'] = 1;
		$id = I('post.id');
		$weituo = M('weituo');
		$res = $weituo->where("id=$id")->save($data);
		if ($res) {
			$this->success('操作成功','/Admin/Other/Zufang');
		}else{
			$this->error('操作失败');
		}
	}
	/**
	 * 找房列表
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-10
	 * @Email    carlos0608@163.com
	 */
	public function Zhaodian()
	{
		$m = M('weituo');
		$count = $m->where('type=2')->count();
		$p = getpage($count,10);
		$list = $m->field(true)->where('type=2')->order('id desc')->limit($p->firstRow, $p->listRows)->select();
		$this->assign('result',$list);
		$this->assign('page', $p->show());
		$this->display();
	}
	/**
	 * 找店反馈
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-10
	 * @Email    carlos0608@163.com
	 */
	public function ZhaodianFanKui()
	{
		$id = $_GET['id'];
		$result = M('weituo')->where("id=$id")->find();
		$this->assign('result',$result);
		$this->display();
	}

	public function DoZhaodianFanKui()
	{
		$data['fankui'] = I('post.fankui');
		$data['status'] = 1;
		$id = I('post.id');
		$weituo = M('weituo');
		$res = $weituo->where("id=$id")->save($data);
		if ($res) {
			$this->success('操作成功','/Admin/Other/Zufang');
		}else{
			$this->error('操作失败');
		}
	}

	public function StaffList()
	{
		$m = M('staff');
		$count = $m->count();
		$p = getpage($count,10);
		$list = $m->field(true)->order('id desc')->limit($p->firstRow, $p->listRows)->select();
		$this->assign('result',$list);
		$this->assign('page', $p->show());
		$this->display();
	}

	public function StaffAdd()
	{
		$this->display();
	}

	public function DoStaffAdd()
	{
		if (IS_POST) {
			$data['staff_name'] = I('post.staff_name');
			$data['staff_description'] = I('post.staff_description');
			$data['create_time'] = time();
			$upload = new \Think\Upload();// 实例化上传类
	        $upload->maxSize   =     3145728 ;// 设置附件上传大小
	        $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
	        $upload->rootPath  =     './Uploads/'; // 设置附件上传根目录
	        $upload->savePath  =     ''; // 设置附件上传（子）目录
	        $info   =   $upload->upload();
	        if(!$info) {// 上传错误提示错误信息
	            $this->error($upload->getError());
	        }else{// 上传成功
	            foreach($info as $file){
	                $res =  $file['savepath'].$file['savename'];
	            }
	            $data['staff_img'] = '/Uploads/'.$res;
	            $Staff = D("Staff");
				if (!$Staff->create()) {
					exit($Staff->getError());
				}else{
					if ($Staff->add($data)) {
						$this->success('操作成功','/Admin/Other/StaffList');
					}else{
						$this->error('操作失败');
					}
				}
	        }
		}else{
			$this->error('非法请求');
		}
	}

	public function StaffUpdate()
	{
		$id = $_GET['id'];
		$result = M('staff')->where("id=$id")->find();
		$this->assign('result',$result);
		$this->display();
	}

	public function DoStaffUpdate()
	{
		$id = I('post.id');
		$data['staff_name'] = I('post.staff_name');
		$data['staff_description'] = I('post.staff_description');
		if($_FILES['staff_img']['name'] != '') {
		    $upload = new \Think\Upload();// 实例化上传类
		    $upload->maxSize   =     3145728 ;// 设置附件上传大小
		    $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
		    $upload->rootPath  =     './Uploads/'; // 设置附件上传根目录
		    $upload->savePath  =     ''; // 设置附件上传（子）目录
		    $info   =   $upload->upload();
		    if(!$info) {// 上传错误提示错误信息
		        $this->error($upload->getError());
		    }else{// 上传成功
		        foreach($info as $file){
		            $res =  $file['savepath'].$file['savename'];
		        }
		        $data['staff_img'] = '/Uploads/'.$res;
		    }
		}
		$Staff = D("Staff")->UpdateStaff($id,$data);
		if ($Staff) {
			$this->success('操作成功','/Admin/Other/StaffList');
		}else{
			 $this->error('操作失败');
		}
	}

	public function StaffDelete()
	{
		$id = $_GET['id'];
		$Staff = D("Staff")->DeleteStaff($id);
		if ($Staff) {
			$this->success('操作成功','/Admin/Other/StaffList');
		}else{
			 $this->error('操作失败');
		}
	}


	public function XuQiu()
	{
		$m = M('xuqiu');
		$count = $m->where('type=1')->count();
		$p = getpage($count,10);
		$list = $m->field(true)->where('type=1')->order('id desc')->limit($p->firstRow, $p->listRows)->select();
		$this->assign('result',$list);
		$this->assign('page', $p->show());
		$this->display();
	}

	public function DeleteXuQiu()
	{
		$id = $_GET['id'];
		$result = M('xuqiu')->where("id=$id")->delete();
		if ($result) {
			$this->success('操作成功');
		}else{
			$this->error('操作失败');
		}
	}

	public function ZiXun()
	{
		$m = M('xuqiu');
		$count = $m->where('type=2')->count();
		$p = getpage($count,10);
		$list = $m->field(true)->where('type=2')->order('id desc')->limit($p->firstRow, $p->listRows)->select();
		$this->assign('result',$list);
		$this->assign('page', $p->show());
		$this->display();
	}

	public function DeleteZiXun()
	{
		$id = $_GET['id'];
		$result = M('xuqiu')->where("id=$id")->delete();
		if ($result) {
			$this->success('操作成功');
		}else{
			$this->error('操作失败');
		}
	}

	public function NiMing()
	{
		$m = M('niming');
		$count = $m->count();
		$p = getpage($count,10);
		$list = $m->field(true)->order('id desc')->limit($p->firstRow, $p->listRows)->select();
		$this->assign('result',$list);
		$this->assign('page', $p->show());
		$this->display();
	}

	public function DeleteNiMing()
	{
		$id = $_GET['id'];
		$result = M('niming')->where("id=$id")->delete();
		if ($result) {
			$this->success('操作成功');
		}else{
			$this->error('操作失败');
		}
	}
}
 ?>