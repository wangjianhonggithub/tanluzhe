<?php 
namespace Admin\Controller;
/**
* 业务--控制器
*/
use Think\Controller;
class YewuController extends Controller
{
	public function YewuList()
	{
		$m = D('Yewu');
		$count = $m->count();
		$p = getpage($count,10);
		$list = $m->field(true)->order('id desc')->limit($p->firstRow, $p->listRows)->select();
		$this->assign('result',$list);
		$this->assign('page', $p->show()); // 赋值分页输出
		$this->display();
	}

	public function YewuAdd()
	{
		$this->display();
	}

	public function DoYewuAdd()
	{
		if (IS_POST) {
			$data['yewu_name'] = I('post.yewu_name');
			$data['yewu_miaoshu'] = $_POST['yewu_miaoshu'];
			$data['yewu_img'] = $_POST['yewu_img'];
			$data['create_time'] = time();
			$Yewu = D('Yewu');
			if (!$Yewu->create()) {
				exit($Yewu->getError());
			}else{
				if ($Yewu->add($data)) {
					$this->success('操作成功','/Admin/Yewu/YewuList');
				}else{
					$this->error('操作失败');
				}
			}
		}else{
			$this->error('非法请求');
		}
	}

	public function YewuUpdate()
	{
		$id = $_GET['id'];
		$result = D('Yewu')->GetYewuOne($id);
		$this->assign('result',$result);
	 	$this->display();
	}

	public function DoYewuUpdate()
	{
		$id = I('post.id');
		$data['yewu_name'] = I('post.yewu_name');
		$data['yewu_miaoshu'] = I('post.yewu_miaoshu');
		$data['yewu_img'] = I('post.yewu_img');
		$Yewu = D('Yewu')->UpdateYewu($id,$data);
		if ($Yewu) {
			$this->success('操作成功','/Admin/Yewu/YewuList');
		}else{
			$this->error('操作失败');
		}

	}

	public function YewuFanwei()
	{
		$m = M('yewufanwei');
		$count = $m->join('carlos_yewu ON carlos_yewu.id = carlos_yewufanwei.yid')->count();
		$p = getpage($count,10);
		$list = $m->join('carlos_yewu ON carlos_yewu.id = carlos_yewufanwei.yid')->order('yfid desc')->limit($p->firstRow, $p->listRows)->select();
		$this->assign('result',$list);
		$this->assign('page', $p->show()); // 赋值分页输出
		$this->display();
	}

	public function FanweiAdd()
	{
		$result = M('yewu')->select();
		$this->assign('result',$result);
		$this->display();
	}

	public function DoFanweiAdd()
	{
		if (IS_POST) {
			$data['fanwei'] = I('post.fanwei');
			$data['miaoshu'] = $_POST['miaoshu'];
			$data['create_time'] =  time();
			$data['yid'] = I('post.yid');
			$fanwei = D('Yewufanwei');
			if (!$fanwei->create()) {
				exit($fanwei->getError());
			}else{
				if ($fanwei->add($data)) {
					$this->success('操作成功','/Admin/Yewu/YewuFanwei');
				}else{
					$this->error('操作失败');
				}
			}
		}else{
			$this->error('非法请求');
		}
	}

	public function FanweiUpdate()
	{
		$id = $_GET['id'];
		$fanwei = D('Yewufanwei')->GetFanweiOne($id);
		$this->assign('fanwei',$fanwei);
		$result = M('yewu')->select();
		$this->assign('result',$result);
		$this->display();
	}

	public function DoFanWeiUpdate()
	{
		$id = I('post.id');
		$data['fanwei'] = I('post.fanwei');
		$data['miaoshu'] = $_POST['miaoshu'];
		$data['yid'] = I('post.yid');
		$fanwei = D('Yewufanwei')->UpdateFanwei($id,$data);
		if ($fanwei) {
			$this->success('操作成功','/Admin/Yewu/YewuFanwei');
		}else{
			$this->error('操作失败');
		}
	}

	public function DeleteFanwei()
	{
		$id = $_GET['id'];
		$fanwei = D('Yewufanwei')->DeleteFanwei($id);
		if ($fanwei) {
			$this->success('操作成功','/Admin/Yewu/YewuFanwei');
		}else{
			$this->error('操作失败');
		}
	}
}
 ?>