<?php 
namespace Admin\Controller;
/**
*招聘 -- 控制器
*/
use Think\Controller;
class JoinController extends Controller
{
	/**
	 * 招聘列表
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-06
	 * @Email    carlos0608@163.com
	 */
	public function JoinList()
	{
		$m = D('Join');
		$count = $m->where($where)->count();
		$p = getpage($count,1);
		$list = $m->field(true)->where($where)->order('id desc')->limit($p->firstRow, $p->listRows)->select();
		$this->assign('result',$list);
		$this->assign('page', $p->show()); // 赋值分页输出
		$this->display();
	}
	/**
	 * 显示添加招聘
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-06
	 * @Email    carlos0608@163.com
	 */
	public function JoinAdd()
	{
		$this->display();
	}
	/**
	 * 执行添加
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-06
	 * @Email    carlos0608@163.com
	 */
	public function DoJoinAdd()
	{
		if (IS_POST) {
			$data['job_name'] = I('post.job_name');
			$data['job_description'] = I('post.job_description');
			$data['job_demand'] = I('post.job_demand');
			$data['create_time'] = time();
			$data['update_time'] = time();
			$join = D('Join');
			if (!$join->create()) {
				exit($join->getError());
			}else{
				if ($join->add()) {
					$this->success('操作成功','/Admin/Join/JoinList');
				}else{
					$this->error('操作失败');
				}
			}
		}else{
			$this->error('非法请求');
		}
	}
	/**
	 * 显示修改
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-06
	 * @Email    carlos0608@163.com
	 */
	public function UpdateJoin()
	{
		$id = $_GET['id'];
		$result = D('Join')->GetJoinOne($id);
		$this->assign('result',$result);
		$this->display();
	}
	/**
	 * 执行修改
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-06
	 * @Email    carlos0608@163.com
	 */
	public function DoUpdateJoin()
	{
		$id = I('post.id');
		$data['job_name'] = I('post.job_name');
		$data['job_description'] = I('post.job_description');
		$data['job_demand'] = I('post.job_demand');
		$data['update_time'] = time();
		$join = D('Join')->UpdateJoin($id,$data);
		if ($join) {
			$this->success('操作成功','/Admin/Join/JoinList');
		}else{
			$this->error('操作失败');
		}
	}
	/**
	 * 删除
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-06
	 * @Email    carlos0608@163.com
	 */
	public function DeleteJoin()
	{
		$id = $_GET['id'];
		$join = D('Join')->DeleteJoin($id);
		if ($join) {
			$this->success('操作成功','/Admin/Join/JoinList');
		}else{
			$this->error('操作失败');
		}
	}

	public function Jianli()
	{
		$m = M('resume');
		$count = $m->count();
		$p = getpage($count,10);
		$list = $m->field(true)->order('id desc')->limit($p->firstRow, $p->listRows)->select();
		$this->assign('result',$list);
		$this->assign('page', $p->show()); // 赋值分页输出
		$this->display();
	}

	public function JoinInfo()
	{
		$id = $_GET['id'];
		$result = M('resume')->where("id=$id")->find();
		$this->assign('result',$result);
		$this->display();
	}
}
 ?>