<?php 
namespace Admin\Controller;
/**
* 登录 注销 -- 控制器
*/
use Think\Controller;
class LoginController extends Controller
{
	/**
	 * 显示登录界面
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-03
	 * @Email    carlos0608@163.com
	 */
	public function Login()
	{
		$this->display();
	}
	/**
	 * 执行登录
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-03
	 * @Email    carlos0608@163.com
	 */
	public function DoLogin()
	{
		if (IS_POST) {
			$admin_user = I('post.admin_user');
		  	$admin_passwd = md5(I('post.admin_passwd'));
		  	$AdminUser = M('admin_user');
		  	$result = $AdminUser->where("admin_user='$admin_user' AND admin_passwd='$admin_passwd'")->select();
		  	if ($result) {
		  		session('AdminUserId',$result[0]['id']); 
				$this->success('登录成功!!!','/Admin');
		  	}else{
		  		$this->error('登录失败!!!请检查账号和密码是否正确...');
		  	}
		}else{
			$this->error('非法请求');
		}
	  	
	}
	
}
 ?>