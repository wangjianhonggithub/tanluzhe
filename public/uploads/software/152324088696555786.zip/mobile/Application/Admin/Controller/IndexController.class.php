<?php
namespace Admin\Controller;
use Think\Controller;
class IndexController extends Controller {
    public function index(){
        if(session('AdminUserId') == ''){
            $this->redirect('/Admin/Login/login');
        }
        $m = D('User');
        $count = $m->where($where)->count();
        $p = getpage($count,10);
        $list = $m->field(true)->where($where)->order('id desc')->limit($p->firstRow, $p->listRows)->select();
		$this->assign('result',$list);
        $this->assign('page', $p->show());
        $this->display();
    }

}