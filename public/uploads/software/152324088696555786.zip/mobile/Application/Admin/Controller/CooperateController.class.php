<?php 
namespace Admin\Controller;
use Think\Controller;
// use Admin\Model\CooperationModel;
/**
 * @author CarLos <carlos0608@163.com>
 * 合作管理--控制器`
 */
class CooperateController extends Controller
{	
	/**
	 * 合作伙伴列表页面
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-02
	 * @Email    carlos0608@163.com
	 */
	public function CooperateList()
	{
		$m = D('Cooperation');
        $count = $m->where($where)->count();
        $p = getpage($count,1);
        $list = $m->field(true)->where($where)->order('id desc')->limit($p->firstRow, $p->listRows)->select();
		$this->assign('result',$list);
        $this->assign('page', $p->show()); // 赋值分页输出
		$this->display();
	}
	/**
	 * 执行添加合作伙伴
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-02
	 * @Email    carlos0608@163.com
	 */
	public function CooperateAdd()
	{
		$this->display();
	}
	/**
	 * 执行合作伙伴的添加
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-02
	 * @Email    carlos0608@163.com
	 */
	public function DoCooperateAdd()
	{	
		if (IS_POST) {
	        $data['cooperation_name'] = $_POST['cooperation_name'];
	        $data['cooperation_description'] =  $_POST['cooperation_description'];
	        $data['cooperation_path'] =  $_POST['cooperation_path'];
	        $data['create_time'] = time();
	        $data['update_time'] = time();
	        $upload = new \Think\Upload();// 实例化上传类
	        $upload->maxSize   =     3145728 ;// 设置附件上传大小
	        $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
	        $upload->rootPath  =     './Uploads/'; // 设置附件上传根目录
	        $upload->savePath  =     ''; // 设置附件上传（子）目录
	        $info   =   $upload->upload();
	        if(!$info) {// 上传错误提示错误信息
	            $this->error($upload->getError());
	        }else{// 上传成功
	            foreach($info as $file){
	                $res =  $file['savepath'].$file['savename'];
	            }
	            $data['cooperation_img'] = '/Uploads/'.$res;
	            $Cooperation = D("Cooperation");
				if (!$Cooperation->create()) {
					 exit($Cooperation->getError());
				}else{
					$Cooperation->add($data);
					$this->success('操作成功','/Admin/Cooperate/CooperateList');
				}
	        }
			
		}else{
			 $this->error('非法请求');
		}
	}
	/**
	 * 显示修改页面
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-02
	 * @Email    carlos0608@163.com
	 * @return   [type]             [description]
	 */
	public function updateCooperate()
	{
		 $id = $_GET['id'];
		 $Cooperation = D("Cooperation");
		 $result = $Cooperation->GetCooperationOne($id);
		 $this->assign('result',$result);
		 $this->display();
	}

	public function DoUpdateCooperate()
	{
		$id = $_POST['id'];
		$data['cooperation_name'] = $_POST['cooperation_name'];
	    $data['cooperation_description'] =  $_POST['cooperation_description'];
	    $data['cooperation_path'] =  $_POST['cooperation_path'];
	    $data['update_time'] = time();
	    if($_FILES['cooperation_img']['name'] != '') {
		    $upload = new \Think\Upload();// 实例化上传类
		    $upload->maxSize   =     3145728 ;// 设置附件上传大小
		    $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
		    $upload->rootPath  =     './Uploads/'; // 设置附件上传根目录
		    $upload->savePath  =     ''; // 设置附件上传（子）目录
		    $info   =   $upload->upload();
		    if(!$info) {// 上传错误提示错误信息
		        $this->error($upload->getError());
		    }else{// 上传成功
		        foreach($info as $file){
		            $res =  $file['savepath'].$file['savename'];
		        }
		        $data['cooperation_img'] = '/Uploads/'.$res;
		    }
		}
		$Cooperation = D("Cooperation")->updateCooperation($id,$data);
		if ($Cooperation) {
			$this->success('操作成功','/Admin/Cooperate/CooperateList');
		}else{
			 $this->error('操作失败');
		}
	}

	public function DeleteCooperation(){
		$id = $_GET['id'];
		$Cooperation = D("Cooperation")->Delete($id);
		if ($Cooperation) {
			$this->success('操作成功','/Admin/Cooperate/CooperateList');
		}else{
			 $this->error('操作失败');
		}
	}

}	
 ?>