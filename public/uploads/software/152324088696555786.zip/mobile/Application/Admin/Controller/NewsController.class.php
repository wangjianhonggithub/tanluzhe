<?php 
namespace Admin\Controller;
/**
* 新闻资讯--控制器
*/
use Think\Controller;
class NewsController extends Controller
{
	/**
	 * 新闻资讯列表
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-03
	 * @Email    carlos0608@163.com
	 */
	public function NewsList()
	{
		$m = M('news');
        $count = $m->join('carlos_classify ON carlos_classify.classify_id = carlos_news.classify_id')->count();
        $p = getpage($count,10);
        $list = $m->join('carlos_classify ON carlos_classify.classify_id = carlos_news.classify_id')->order('id desc')->limit($p->firstRow, $p->listRows)->select();
        $this->assign('result',$list);
        $this->assign('page', $p->show()); // 赋值分页输出
		$this->display();
	}

	/**
	 * 新闻资讯添加页面
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-03
	 * @Email    carlos0608@163.com
	 */
	public function NewsAdd(){
        $Classify = D('Classify');
		$res = $Classify->select();
		$this->assign('res',$res);
		$this->display();
	}

	/**
	 * 执行新闻资讯的添加
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-03
	 * @Email    carlos0608@163.com
	 */
	public function DoNewsAdd(){
		if (IS_POST) {
			$data['news_title'] = I('post.news_title');
			$data['news_description'] = I('post.news_description');
			$data['news_content'] = I('post.content');
			$data['classify_id'] = I('post.classify_id');
			$data['create_time'] = time();
			$data['update_time'] = time();
			$upload = new \Think\Upload();// 实例化上传类
	        $upload->maxSize   =     3145728 ;// 设置附件上传大小
	        $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
	        $upload->rootPath  =     './Uploads/'; // 设置附件上传根目录
	        $upload->savePath  =     ''; // 设置附件上传（子）目录
	        $info   =   $upload->upload();
	        if(!$info) {// 上传错误提示错误信息
	            $this->error($upload->getError());
	        }else{// 上传成功
	            foreach($info as $file){
	                $res =  $file['savepath'].$file['savename'];
	            }
	            $data['news_img'] = '/Uploads/'.$res;
	           	$News = D('News');
				if (!$News->create()) {
					exit($News->getError());
				}else{
					if($News->add($data)){
						$this->success('操作成功','/Admin/News/NewsList');
					}else{
						$this->error('操作失败');
					}
				}
	        }
			
		}else{
			$this->error('非法请求');
		}
	}
	/**
	 * 显示新闻资讯修改页面
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-03
	 * @Email    carlos0608@163.com
	 */
	public function UpdateNews()
	{
		$id = $_GET['id'];
		$result = D('News')->GetNewsOne($id);
		$Classify = D('Classify');
		$res = $Classify->select();
		$this->assign('res',$res);
	 	$this->assign('result',$result);
	 	$this->display();
	}
	/**
	 * 执行新闻咨询的修改
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-03
	 * @Email    carlos0608@163.com
	 */
	public function DoUpdateNews()
	{	
		$id = I('post.id');
		$data['news_title'] = I('post.news_title');
		$data['news_description'] = I('post.news_description');
		$data['news_content'] = I('post.content');
		$data['classify_id'] = I('post.classify_id');
		$data['update_time'] = time();
		if($_FILES['news_img']['name'] != '') {
            $upload = new \Think\Upload();// 实例化上传类
            $upload->maxSize = 3145728;// 设置附件上传大小
            $upload->exts = array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
            $upload->rootPath = './Uploads/'; // 设置附件上传根目录
            $upload->savePath = ''; // 设置附件上传（子）目录
            // 上传文件
            $info = $upload->upload();
            if (!$info) {// 上传错误提示错误信息
                $this->error($upload->getError());
            } else {// 上传成功
                $res = $info['news_img']['savepath'] . $info['news_img']['savename'];
                $data['news_img'] = '/Uploads/' . $res;
            }
        }
		$News = D('News');
		if ($News->UpdateNews($id,$data)) {
			$this->success('操作成功','/Admin/News/NewsList');
		}else{
			$this->error('操作失败');
		}
	}

	public function DeleteNews()
	{
		$id=$_GET['id'];
		$News = D('news');
		if ($News->DeleteNews($id)) {
			$this->success('操作成功');
		}else{
			$this->error('操作失败');
		}
	}
	/**
	 * 分类列表
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-04
	 * @Email    carlos0608@163.com
	 * @return   [type]             [description]
	 */
	public function classify()
	{
		$m = D('Classify');
        $count = $m->where($where)->count();
        $p = getpage($count,10);
        $list = $m->field(true)->where($where)->order('classify_id desc')->limit($p->firstRow, $p->listRows)->select();
        $this->assign('result',$list);
        $this->assign('page', $p->show()); // 赋值分页输出
		$this->display();
	}
	/**
	 * 显示添加文章分类
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-04
	 * @Email    carlos0608@163.com
	 */
	public function ClassifyAdd()
	{
		$this->display();
	}
	/**
	 * 执行添加分类
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-04
	 * @Email    carlos0608@163.com
	 */
	public function DoClassifyAdd()
	{
		if (IS_POST) {
			$data['classify_name'] = I('post.classify_name');
			$data['create_time'] = time();
			$data['update_time'] = time();
			$Classify = D('Classify');
			if (!$Classify->create()) {
				exit($Classify->getError());
			}else{
				if ($Classify->add($data)) {
					$this->success('操作成功','/Admin/News/classify');
				}else{
					$this->error('操作失败');
				}
			}
		}else{
			$this->error('非法请求');
		}
	}
	/**
	 * 显示修改
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-04
	 * @Email    carlos0608@163.com
	 */
	public function ClassifyUpdate()
	{
		$id = $_GET['id'];
		$Classify = D('Classify');
		$result = $Classify->GetClassifyOne($id);
		$this->assign('result',$result);
		$this->display();
	}
	/**
	 * 执行修改
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-04
	 * @Email    carlos0608@163.com
	 */
	public function DoClassifyUpdate()
	{
		$data['classify_name'] = I('post.classify_name');
		$data['update_time'] = time();
		$id = I('post.classify_id');
		$Classify = D('Classify');
		$result = $Classify->UpdateClassify($id,$data);
		if ($result) {
			$this->success('操作成功','/Admin/News/classify');
		}else{
			$this->error('操作失败');
		}
	}
	/**
	 * 删除分类
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-06
	 * @Email    carlos0608@163.com
	 */
	public function DeleteClassify()
	{
		$id = $_GET['id'];
		$Classify = D('Classify');
		$result = $Classify->DeleteClassify($id);
		if ($result) {
			$this->success('操作成功','/Admin/News/classify');
		}else{
			$this->error('操作失败');
		}
	}
}
 ?>