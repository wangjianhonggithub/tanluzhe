<?php 
namespace Admin\Controller;
/**
* 轮播图 --- 控制器
*/
use Think\Controller;
class BannerController extends Controller
{
	/**
	 * 首页轮播图列表
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-03
	 * @Email    carlos0608@163.com
	 */
	public function BannerList()
	{
		$m = M('column');
		$count = $m->join('carlos_banner ON carlos_banner.cid = carlos_column.id')->count();
		$p = getpage($count,10);
		$list = $m->join('carlos_banner ON carlos_banner.cid = carlos_column.id')->order('id desc')->limit($p->firstRow, $p->listRows)->select();
		$this->assign('result',$list);
		$this->assign('page', $p->show()); // 赋值分页输出
		$this->display();
	}
	/**
	 * 添加banner的页面
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-03
	 * @Email    carlos0608@163.com
	 */
	public function BannerAdd()
	{
		$Column = M('column');
		$result = $Column->select();
		$this->assign('result',$result);
		$this->display();
	}
	/**
	 * 执行添加banner
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-03
	 * @Email    carlos0608@163.com
	 */
	public function DoBannerAdd()
	{
		$data['banner_path'] = I('post.path');
		$data['create_time'] = time();
		$data['update_time'] = time();
		$data['cid'] = I('post.cid');

		$upload = new \Think\Upload();// 实例化上传类
        $upload->maxSize   =     3145728 ;// 设置附件上传大小
        $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
        $upload->rootPath  =     './Uploads/'; // 设置附件上传根目录
        $upload->savePath  =     ''; // 设置附件上传（子）目录
        $info   =   $upload->upload();
        if(!$info) {// 上传错误提示错误信息
            $this->error($upload->getError());
        }else{// 上传成功
            foreach($info as $file){
                $res =  $file['savepath'].$file['savename'];
            }
            $data['banner_img'] = '/Uploads/'.$res;
            $Banner = D("Banner");
			if ($Banner->add($data)) {
				$this->success('操作成功','/Admin/Banner/BannerList');
			}else{
				$this->error('操作失败');
			}
        }
	}
	/**
	 * 创造Banner修改页面
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-03
	 * @Email    carlos0608@163.com
	 */
	public function UpdateBanner()
	{	
		$id	= $_GET['id'];
		$Column = M('column');
		$res = $Column->select();
		$this->assign('res',$res);
		$result = D('Banner')->GetBannerOne($id);
		$this->assign('result', $result); // 赋值分页输出
		$this->display();
	}
	/**
	 * 执行修改操作
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-03
	 * @Email    carlos0608@163.com
	 */
	public function DoUpdateBanner()
	{	
		$id = I('post.id');
		$data['banner_path'] = I('post.path');
		$data['update_time'] = time();
		if($_FILES['image']['name'] != '') {
		    $upload = new \Think\Upload();// 实例化上传类
		    $upload->maxSize   =     3145728 ;// 设置附件上传大小
		    $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
		    $upload->rootPath  =     './Uploads/'; // 设置附件上传根目录
		    $upload->savePath  =     ''; // 设置附件上传（子）目录
		    $info   =   $upload->upload();
		    if(!$info) {// 上传错误提示错误信息
		        $this->error($upload->getError());
		    }else{// 上传成功
		        foreach($info as $file){
		            $res =  $file['savepath'].$file['savename'];
		        }
		        $data['banner_img'] = '/Uploads/'.$res;
		    }
		}
		$Banner = D("Banner")->UpdateBanner($id,$data);
		if ($Banner) {
			$this->success('操作成功','/Admin/Banner/BannerList');
		}else{
			 $this->error('操作失败');
		}
	}


	public function DeleteBanner()
	{
		$id = $_GET['id'];
		$Banner = D('Banner');
		if ($Banner->DeleteBanner($id)) {
			$this->success('操作成功');
		}else{
			$this->error('操作失败');
		}
	}
	/**
	 * banner栏目
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-04
	 * @Email    carlos0608@163.com
	 */
	public function BannerColumnList()
	{
		$Column = M('column');
		$result = $Column->select();
		$this->assign('result', $result); // 赋值分页输出
		$this->display();
	}
	/**
	 * 添加栏目
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-04
	 * @Email    carlos0608@163.com
	 */
	public function AddColumnList()
	{	
		$Column = M('column');
		$result = $Column->select();
		$this->assign('result', $result); // 赋值分页输出
		$this->display();
	}
	/**
	 * 执行添加
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-04
	 * @Email    carlos0608@163.com
	 */
	public function DoAddColumn()
	{
		if (IS_POST) {
			$data['pid'] = I('post.pid');
			$data['column_name'] = I('post.column_name');
			$data['create_time'] = time();
			$data['update_time'] = time();
			$Column = D('Column');
			if (!$Column->create()) {
				 exit($Column->getError());
			}else{
				if ($Column->add($data)) {
					$this->success('操作成功','/Admin/Banner/BannerColumnList');
				}else{
					$this->error('操作失败');
				}
			}
		}else{
			$this->error('非法请求');
		}
	}
	/**
	 * 显示修改页面
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-04
	 * @Email    carlos0608@163.com
	 */
	public function UpdateColumn()
	{
		$id = $_GET['id'];
		$Column = D('Column');
		$res = $Column->GetColumnOne($id);
		$result = $Column->select();
		$this->assign('res', $res); // 赋值分页输出
		$this->assign('result', $result); // 赋值分页输出
		$this->display();
	}
	/**
	 * 执行栏目修改
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-04
	 * @Email    carlos0608@163.com
	 */
	public function DoUpdateColumn()
	{	
		$id = I('post.id');
		$data['pid'] = I('post.pid');
		$data['column_name'] = I('post.column_name');
		$data['update_time'] = time();
		$Column = D('Column')->UpdateColumn($id,$data);
		if ($Column) {
			$this->success('操作成功','/Admin/Banner/BannerColumnList');
		}else{
			$this->error('操作失败');
		}
	}
}
 ?>