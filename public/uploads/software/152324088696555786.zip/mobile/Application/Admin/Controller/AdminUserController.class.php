<?php 
namespace Admin\Controller;
/**
* 后台用户 -- 控制器
*/
use Think\Controller;
class AdminUserController extends Controller
{
	/**
	 *后台用户列表
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-03
	 * @Email    carlos0608@163.com
	 */
	public function AdminUserList()
	{
		$m = D('AdminUser');
		$count = $m->where($where)->count();
		$p = getpage($count,10);
		$list = $m->field(true)->where($where)->order('id desc')->limit($p->firstRow, $p->listRows)->select();
		$this->assign('result',$list);
		$this->assign('page', $p->show()); // 赋值分页输出
		$this->display();
	}
	/**
	 * 显示添加后台用户界面
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-03
	 * @Email    carlos0608@163.com
	 */
	public function AdminUserAdd()
	{
		$this->display();
	}

	public function DoAdminUserAdd()
	{
		if (IS_POST) {
			$data['admin_user'] = I('post.admin_user');
			$data['admin_passwd'] = md5(I('post.admin_passwd'));
			$data['admin_nickname'] = I('post.admin_nickname');
			$data['create_time'] = time();
			$data['update_time'] = time();
			$AdminUser = D('AdminUser');
			if (!$AdminUser->create()) {
				exit($AdminUser->getError());
			}else{
				if ($AdminUser->add($data)) {
					$this->success('操作成功','/Admin/AdminUser/AdminUserList');
				}else{
					$this->error('操作失败');
				}
			}
		}else{
			$this->error('非法请求');
		}
	}
	/**
	 * 后台修改账号密码
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-03
	 * @Email    carlos0608@163.com
	 */
	public function UpdateAdminUser()
	{
		$id = session('AdminUserId');
		$result = D('AdminUser')->GetAdminUserOne($id);
		$this->assign('result',$result);
		$this->display();
	}
	/**
	 * 用户密码及昵称的修改
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-04
	 * @Email    carlos0608@163.com
	 */
	public function DoUpdateAdminUser()
	{
		$rules = array(
		     array('repasswd','passwd','确认密码不正确',0,'confirm'), // 验证确认密码是否和密码一致
		     array('passwd','require','密码不能为空'), // 自定义函数验证密码格式
		);
		$User = M("AdminUser"); // 实例化User对象
		if (!$User->validate($rules)->create()){
		     // 如果创建失败 表示验证没有通过 输出错误提示信息
		     exit($User->getError());
		}else{
			$AdminUser = D('AdminUser');
			$id = I('post.id');
			$data['admin_passwd'] = md5(I('post.passwd'));
			$data['admin_nickname'] = I('post.admin_nickname');
		     if ($AdminUser->UpdateAdminPass($id,$data)) {
		     	$this->success('操作成功!!!','/Admin/Login/Login');
		     }else{
		     	$this->error('操作失败');
		     }
		}
	}
	/**
	 * 删除后台用户
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-03
	 * @Email    carlos0608@163.com
	 */
	public function DeleteAdminUser()
	{
		$id = I('get.id');
		if (D('AdminUser')->DodeleteAdminUser($id)) {
			$this->success('操作成功');
		}else{
			$this->error('操作失败');
		}
	}
}
 ?>