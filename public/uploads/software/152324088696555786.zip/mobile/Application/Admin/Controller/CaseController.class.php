<?php 
namespace Admin\Controller;
/**
* 案例 -- 控制器
*/
use Think\Controller;
class CaseController extends Controller
{
	/**
	 * 案例显示的列表
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-05
	 * @Email    carlos0608@163.com
	 */
	public function CaseList()
	{	
		$m = D('Case');
		$count = $m->where('type=1')->join('carlos_case_classify ON carlos_case_classify.classify_id = carlos_case.classify_id')->count();
		$p = getpage($count,10);
		$list = $m->where('type=1')->join('carlos_case_classify ON carlos_case_classify.classify_id = carlos_case.classify_id')->order('id desc')->limit($p->firstRow, $p->listRows)->select();
		$this->assign('result',$list);
		$this->assign('page', $p->show()); // 赋值分页输出
		$this->display();
	}
	/**
	 * 显示添加案例
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-05
	 * @Email    carlos0608@163.com
	 */
	public function CaseAdd()
	{
		$Classify = D('CaseClassify');
		$res = $Classify->select();
		$this->assign('res',$res);
		$this->display();
	}
	/**
	 * 执行添加案例
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-05
	 * @Email    carlos0608@163.com
	 */
	public function DoCaseAdd()
	{
		if (IS_POST) {
			$data['case_title'] = I('post.case_title');
			$data['case_description'] = I('post.case_description');
			$data['case_content'] = I('post.case_content');
			$data['classify_id'] = I('post.classify_id');
			$data['create_time'] = time();
			$data['update_time'] = time();
			$data['type'] = 1;
			$upload = new \Think\Upload();// 实例化上传类
	        $upload->maxSize   =     3145728 ;// 设置附件上传大小
	        $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
	        $upload->rootPath  =     './Uploads/'; // 设置附件上传根目录
	        $upload->savePath  =     ''; // 设置附件上传（子）目录
	        $info   =   $upload->upload();
	        if(!$info) {// 上传错误提示错误信息
	            $this->error($upload->getError());
	        }else{// 上传成功
	            foreach($info as $file){
	                $res =  $file['savepath'].$file['savename'];
	            }
	            $data['case_img'] = '/Uploads/'.$res;
	            $Case = D("Case");
				if (!$Case->create()) {
					exit($Case->getError());
				}else{
					if ($Case->add($data)) {
						$this->success('操作成功','/Admin/Case/CaseList');
					}else{
						$this->error('操作失败');
					}
				}
	        }
		}else{
			$this->error('非法请求');
		}
	}
	/**
	 * 显示修改
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-05
	 * @Email    carlos0608@163.com
	 */
	public function UpdateCase()
	{
		$id = $_GET['id'];
		$result = D('Case')->GetCaseOne($id);
		$this->assign('result',$result);
		$Classify = D('CaseClassify');
		$res = $Classify->select();
		$this->assign('res',$res);
		$this->display();
	}
	/**
	 * 执行修改
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-05
	 * @Email    carlos0608@163.com
	 */
	public function DoUpdateCase()
	{
		$id = I('post.id');
		$data['case_title'] = I('post.case_title');
		$data['case_description'] = I('post.case_description');
		$data['case_content'] = I('post.case_content');
		$data['classify_id'] = I('post.classify_id');
		$data['type'] = 1;
		$data['update_time'] = time();
		if($_FILES['case_img']['name'] != '') {
		    $upload = new \Think\Upload();// 实例化上传类
		    $upload->maxSize   =     3145728 ;// 设置附件上传大小
		    $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
		    $upload->rootPath  =     './Uploads/'; // 设置附件上传根目录
		    $upload->savePath  =     ''; // 设置附件上传（子）目录
		    $info   =   $upload->upload();
		    if(!$info) {// 上传错误提示错误信息
		        $this->error($upload->getError());
		    }else{// 上传成功
		        foreach($info as $file){
		            $res =  $file['savepath'].$file['savename'];
		        }
		        $data['banner_img'] = '/Uploads/'.$res;
		    }
		}
		$Case = D("Case")->UpdateCase($id,$data);
		if ($Case) {
			$this->success('操作成功','/Admin/Case/CaseList');
		}else{
			 $this->error('操作失败');
		}
	}

	public function DeleteCase()
	{
		$id = $_GET['id'];
		$result = D('Case')->DeleteCase($id);
		if ($result) {
			$this->success('操作成功','/Admin/Case/CaseList');
		}else{
			 $this->error('操作失败');
		}
	}
	/**
	 * 案例分类
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-08
	 * @Email    carlos0608@163.com
	 */
	public function CaseClassify()
	{
		$m = D('CaseClassify');
        $count = $m->where($where)->count();
        $p = getpage($count,10);
        $list = $m->field(true)->where($where)->order('classify_id desc')->limit($p->firstRow, $p->listRows)->select();
        $this->assign('result',$list);
        $this->assign('page', $p->show()); // 赋值分页输出
		$this->display();
	}
	/**
	 * 显示案例分类的添加
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-08
	 * @Email    carlos0608@163.com
	 */
	public function CaseClassifyAdd()
	{
		$this->display();
	}
	/**
	 * 添加案例分类
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-08
	 * @Email    carlos0608@163.com
	 */
	public function DoCaseClassifyAdd()
	{
		if (IS_POST) {
			$data['case_classify_name'] = I('post.case_classify_name');
			$data['create_time'] = time();
			$data['update_time'] = time();
			$CaseClassify = D('CaseClassify');
			if (!$CaseClassify->create()) {
				exit($CaseClassify->getError());
			}else{
				if ($CaseClassify->add($data)) {
					$this->success('操作成功','/Admin/Case/CaseClassify');
				}else{
					$this->error('操作失败');
				}
			}
		}else{
			$this->error('非法请求');
		}
	}
	/**
	 * 显示修改分类
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-08
	 * @Email    carlos0608@163.com
	 */
	public function CaseClassifyUpdate()
	{
		$id = $_GET['id'];
		$Classify = D('CaseClassify');
		$result = $Classify->GetClassifyOne($id);
		$this->assign('result',$result);
		$this->display();
	}
	/**
	 * 执行修改
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-08
	 * @Email    carlos0608@163.com
	 */
	public function DoCaseClassifyUpdate()
	{
		$data['case_classify_name'] = I('post.case_classify_name');
		$data['update_time'] = time();
		$id = I('post.classify_id');
		$Classify = D('CaseClassify');
		$result = $Classify->UpdateClassify($id,$data);
		if ($result) {
			$this->success('操作成功','/Admin/Case/CaseClassify');
		}else{
			$this->error('操作失败');
		}
	}
	/**
	 * 执行删除
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-08
	 * @Email    carlos0608@163.com
	 */
	public function DeleteCaseClassify()
	{
		$id = $_GET['id'];
		$Classify = D('CaseClassify');
		$result = $Classify->DeleteClassify($id);
		if ($result) {
			$this->success('操作成功','/Admin/Case/CaseClassify');
		}else{
			$this->error('操作失败');
		}
	}

	public function TouBiao()
	{
		$m = D('Case');
		$count = $m->where('type=2')->join('carlos_case_classify ON carlos_case_classify.classify_id = carlos_case.classify_id')->count();
		$p = getpage($count,10);
		$list = $m->where('type=2')->join('carlos_case_classify ON carlos_case_classify.classify_id = carlos_case.classify_id')->order('id desc')->limit($p->firstRow, $p->listRows)->select();
		$this->assign('result',$list);
		$this->assign('page', $p->show()); // 赋值分页输出
		$this->display();
	}

	public function TouBiaoAdd()
	{
		$Classify = D('CaseClassify');
		$res = $Classify->select();
		$this->assign('res',$res);
		$this->display();
	}

	public function DoTouBiaoAdd()
	{
		if (IS_POST) {
			$data['case_title'] = I('post.case_title');
			$data['case_description'] = I('post.case_description');
			$data['case_content'] = I('post.case_content');
			$data['classify_id'] = I('post.classify_id');
			$data['create_time'] = time();
			$data['update_time'] = time();
			$data['type'] = 2;
			$upload = new \Think\Upload();// 实例化上传类
	        $upload->maxSize   =     3145728 ;// 设置附件上传大小
	        $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
	        $upload->rootPath  =     './Uploads/'; // 设置附件上传根目录
	        $upload->savePath  =     ''; // 设置附件上传（子）目录
	        $info   =   $upload->upload();
	        if(!$info) {// 上传错误提示错误信息
	            $this->error($upload->getError());
	        }else{// 上传成功
	            foreach($info as $file){
	                $res =  $file['savepath'].$file['savename'];
	            }
	            $data['case_img'] = '/Uploads/'.$res;
	            $Case = D("Case");
				if (!$Case->create()) {
					exit($Case->getError());
				}else{
					if ($Case->add($data)) {
						$this->success('操作成功','/Admin/Case/CaseList');
					}else{
						$this->error('操作失败');
					}
				}
	        }
		}else{
			$this->error('非法请求');
		}
	}

	public function UpdateTouBiao()
	{
		$id = $_GET['id'];
		$result = D('Case')->GetCaseOne($id);
		$this->assign('result',$result);
		$Classify = D('CaseClassify');
		$res = $Classify->select();
		$this->assign('res',$res);
		$this->display();
	}

	public function DoUpdateTouBiao()
	{
		$id = I('post.id');
		$data['case_title'] = I('post.case_title');
		$data['case_description'] = I('post.case_description');
		$data['case_content'] = I('post.case_content');
		$data['type'] = 2;
		$data['update_time'] = time();
		if($_FILES['case_img']['name'] != '') {
		    $upload = new \Think\Upload();// 实例化上传类
		    $upload->maxSize   =     3145728 ;// 设置附件上传大小
		    $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
		    $upload->rootPath  =     './Uploads/'; // 设置附件上传根目录
		    $upload->savePath  =     ''; // 设置附件上传（子）目录
		    $info   =   $upload->upload();
		    if(!$info) {// 上传错误提示错误信息
		        $this->error($upload->getError());
		    }else{// 上传成功
		        foreach($info as $file){
		            $res =  $file['savepath'].$file['savename'];
		        }
		        $data['banner_img'] = '/Uploads/'.$res;
		    }
		}
		$Case = D("Case")->UpdateCase($id,$data);
		if ($Case) {
			$this->success('操作成功','/Admin/Case/CaseList');
		}else{
			 $this->error('操作失败');
		}
	}

	public function DeleteTouBiao()
	{
		$id = $_GET['id'];
		$result = D('Case')->DeleteCase($id);
		if ($result) {
			$this->success('操作成功','/Admin/Case/CaseList');
		}else{
			 $this->error('操作失败');
		}
	}
}
 ?>