<?php 
namespace Admin\Controller;
/**
*网站的配置管理---控制器
*@author 翟佳宇
*email carlos0608@163.com
*/
use Think\Controller;
class ConfController extends Controller
{
	/**
	 * 显示网站配置操作页面
	 */
	public function conf(){
		$result = D('Conf')->GetConfOne(1);
		$this->assign('result',$result);
		$this->display();
	}
	/**
	 * 执行配置项修改
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-05
	 * @Email    carlos0608@163.com
	 */
	public function DoUpdateConf()
	{

		$data['conf_company_address'] = I('post.conf_company_address');
		$data['conf_company_telephone'] = I('post.conf_company_telephone');
		$data['conf_company_records'] = I('post.conf_company_records');
		$data['conf_company_email'] = I('post.conf_company_email');
		$data['conf_24hours'] = I('post.conf_24hours');
		$data['conf_company_name'] = I('post.conf_company_name');
		$data['conf_join_telephone'] = I('post.conf_join_telephone');
		$data['conf_jion_email'] = I('post.conf_jion_email');
		$data['conf_join_picture'] = I('post.conf_join_picture');
		$data['conf_extend_picture'] = I('post.conf_extend_picture');
		if ($_FILES['conf_qrcode']['name'] != '' && $_FILES['conf_company_logo']['name'] != ''){
            $upload = new \Think\Upload();// 实例化上传类
            $upload->maxSize = 3145728;// 设置附件上传大小
            $upload->exts = array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
            $upload->rootPath = './Uploads/'; // 设置附件上传根目录
            $upload->savePath = ''; // 设置附件上传（子）目录
            // 上传文件
            $info = $upload->upload();
            if (!$info) {// 上传错误提示错误信息
                $this->error($upload->getError());
            } else {// 上传成功
                $res = $info['conf_qrcode']['savepath'] . $info['conf_qrcode']['savename'];
                $resa = $info['conf_company_logo']['savepath'] . $info['conf_company_logo']['savename'];
                $data['conf_qrcode'] = '/Uploads/' . $res;
                $data['conf_company_logo'] = '/Uploads/' . $resa;
            }
        }else{
            if($_FILES['conf_qrcode']['name'] != '') {
                $upload = new \Think\Upload();// 实例化上传类
                $upload->maxSize = 3145728;// 设置附件上传大小
                $upload->exts = array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
                $upload->rootPath = './Uploads/'; // 设置附件上传根目录
                $upload->savePath = ''; // 设置附件上传（子）目录
                // 上传文件
                $info = $upload->upload();
                if (!$info) {// 上传错误提示错误信息
                    $this->error($upload->getError());
                } else {// 上传成功
                    $resa = $info['conf_qrcode']['savepath'] . $info['conf_qrcode']['savename'];
                    $data['conf_qrcode'] = '/Uploads/' . $resa;
                    //实例化数据库
                }
            }
            if($_FILES['conf_company_logo']['name'] != '') {
                $upload = new \Think\Upload();// 实例化上传类
                $upload->maxSize = 3145728;// 设置附件上传大小
                $upload->exts = array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
                $upload->rootPath = './Uploads/'; // 设置附件上传根目录
                $upload->savePath = ''; // 设置附件上传（子）目录
                // 上传文件
                $info = $upload->upload();
                if (!$info) {// 上传错误提示错误信息
                    $this->error($upload->getError());
                } else {// 上传成功
                    $res = $info['conf_company_logo']['savepath'] . $info['conf_company_logo']['savename'];
                    $data['conf_company_logo'] = '/Uploads/' . $res;
                }
            }
        }
		$Conf = D("Conf")->UpdateConf(1,$data);
		if ($Conf) {
			$this->success('操作成功');
		}else{
			 $this->error('操作失败');
		}
	}


    /**
     * 经营的业务范围
     * @Author   CarLos(翟)
     * @DateTime 2018-01-06
     * @Email    carlos0608@163.com
     */
    public function BusinessList()
    {
        $m = D('Business');
        $count = $m->where($where)->count();
        $p = getpage($count,10);
        $list = $m->field(true)->where($where)->order('id desc')->limit($p->firstRow, $p->listRows)->select();
        $this->assign('result',$list);
        $this->assign('page', $p->show()); // 赋值分页输出
        $this->display();

    }   
    /**
     *显示添加页面
     * @Author   CarLos(翟)
     * @DateTime 2018-01-06
     * @Email    carlos0608@163.com
     */
    public function BusinessAdd()
    {   
        $this->display();
    }
    /**
     * 执行添加
     * @Author   CarLos(翟)
     * @DateTime 2018-01-06
     * @Email    carlos0608@163.com
     */
    public function DoBusinessAdd()
    {
        if (IS_POST) {
            $data['business_name'] = I('post.business_name');
            $data['business_content'] = I('post.business_content');
            $data['create_time'] = time();
            $data['update_time'] = time();
            $upload = new \Think\Upload();// 实例化上传类
            $upload->maxSize   =     3145728 ;// 设置附件上传大小
            $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
            $upload->rootPath  =     './Uploads/'; // 设置附件上传根目录
            $upload->savePath  =     ''; // 设置附件上传（子）目录
            $info   =   $upload->upload();
            if(!$info) {// 上传错误提示错误信息
                $this->error($upload->getError());
            }else{// 上传成功
                foreach($info as $file){
                    $res =  $file['savepath'].$file['savename'];
                }
                $data['business_img'] = '/Uploads/'.$res;
                $business = D("Business");
                if (!$business->create()) {
                    exit($business->getError());
                }else{
                    if ($business->add($data)) {
                        $this->success('操作成功','/Admin/Conf/BusinessList');
                    }else{
                        $this->error('操作失败');
                    }
                }
            }
        }else{
            $this->error('非法请求');
        }
    }

    /**
     * 显示修改
     * @Author   CarLos(翟)
     * @DateTime 2018-01-06
     * @Email    carlos0608@163.com
     */
    public function UpdateBusiness()
    {
        $id = $_GET['id'];
        $Business = D('Business')->UpdateBusiness($id);
        $this->assign('result',$Business);
        $this->display();
    }

    public function DoUpdateBusiness()
    {
        $data['business_name'] = I('post.business_name');
        $data['business_content'] = I('post.business_content');
        $data['update_time'] = time();
        $id = I('post.id');
        if($_FILES['business_img']['name'] != '') {
           
            $upload = new \Think\Upload();// 实例化上传类
            $upload->maxSize   =     3145728 ;// 设置附件上传大小
            $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
            $upload->rootPath  =     './Uploads/'; // 设置附件上传根目录
            $upload->savePath  =     ''; // 设置附件上传（子）目录
            $info   =   $upload->upload();
            if(!$info) {// 上传错误提示错误信息
                $this->error($upload->getError());
            }else{// 上传成功
                foreach($info as $file){
                    $res =  $file['savepath'].$file['savename'];
                }
                $data['business_img'] = '/Uploads/'.$res;
            }
        }
        $Business = D('Business')->DoUpdateBusiness($id,$data);
        if ($Business) {
            $this->success('操作成功','/Admin/Conf/BusinessList');
        }else{
             $this->error('操作失败');
        }
    }

    public function DeleteBusiness()
    {
        $id = $_GET['id'];
        $Business = D('Business')->DeleteBusiness($id);
        if ($Business) {
            $this->success('操作成功','/Admin/Conf/BusinessList');
        }else{
             $this->error('操作失败');
        }
    }

    public function Company()
    {
        $company = M('company')->where("id=1")->find();
        $this->assign('result',$company);
        $this->display();
    }

    public function DoCompany()
    {
        $data['jianjie_img'] = I('post.jianjie_img');
        $data['jianjie_content'] = I('post.jianjie_content');
        $data['wenhua_img'] = I('post.wenhua_img');
        $data['wenhua_content'] = I('post.wenhua_content');
        $data['guanyu_img'] = I('post.guanyu_img');
        $data['guanyu_content'] = I('post.guanyu_content');
        $data['zhaoshang_img'] = I('post.zhaoshang_img');
        $data['zhaoshang_choubei'] = I('post.zhaoshang_choubei');
        $data['zhaoshang_xushui'] = I('post.zhaoshang_xushui');
        $data['zhaoshang_zhixing'] = I('post.zhaoshang_zhixing');
        $data['zhaoshang_jiewei'] = I('post.zhaoshang_jiewei');
        $data['zhaoshang_content'] = I('post.zhaoshang_content');
        $data['zhaoshang_liucheng'] = I('post.zhaoshang_liucheng');
        $data['zhaoshang_liaojieta'] = I('post.zhaoshang_liaojieta');
        $data['zhaoshang_fuwuduixiang'] = I('post.zhaoshang_fuwuduixiang');
        $data['zhaoshang_jianshejihua'] = I('post.zhaoshang_jianshejihua');
        $Company = M('company');
        $res = $Company->where('id=1')->save($data);
        if ($res) {
            $this->success('操作成功');
        }else{
            $this->error('操作失败');
        }
    }


    public function Qiye()
    {
        $qiye = M('qiye')->where("id=1")->find();
        $this->assign('result',$qiye);
        $this->display();
    }

    public function DoQiye()
    {
        $data['qiye_yuanjing_img'] = I('post.qiye_yuanjing_img');
        $data['qiye_yuanjing_content'] = I('post.qiye_yuanjing_content');
        $data['qiye_hexin_img'] = I('post.qiye_hexin_img');
        $data['qiye_hexin_content'] = I('post.qiye_hexin_content');
        $data['qiye_zhanlue_zimg'] = I('post.qiye_zhanlue_zimg');
        $data['qiye_zhanlue_yimg'] = I('post.qiye_zhanlue_yimg');
        $data['qiye_zhanlue_content'] = I('post.qiye_zhanlue_content');
        $Company = M('qiye');
        $res = $Company->where('id=1')->save($data);
        if ($res) {
            $this->success('操作成功');
        }else{
            $this->error('操作失败');
        }
    }

    public function YewuInfo()
    {
        $m = M('yewuinfo');
        $count = $m->where($where)->count();
        $p = getpage($count,10);
        $list = $m->field(true)->where($where)->order('id desc')->limit($p->firstRow, $p->listRows)->select();
        $this->assign('result',$list);
        $this->assign('page', $p->show()); // 赋值分页输出
        $this->display();
    }

    public function YewuinfoAdd()
    {
        $this->display();
    }

    public function DoYewuinfoAdd()
    {
        $data['info'] =$_POST['info'];
        $data['create_time'] = time();
        $info = M('yewuinfo');
        if ($info->add($data)) {
            $this->success('操作成功','/Admin/Conf/YewuInfo');
        }else{
            $this->error('操作失败');
        }
    }

    public function yewuinfoUpdate()
    {
        $id = $_GET['id'];
        $yewuinfo = D('yewuinfo')->where("id=$id")->find();
        $this->assign('result',$yewuinfo);
        $this->display();
    }

    public function DoYewuInfoUpdate()
    {
        $data['info'] = I('post.info');
        $id = I('post.id');
        $info = M('yewuinfo');
        if ($info->where("id=$id")->save($data)) {
            $this->success('操作成功','/Admin/Conf/YewuInfo');
        }else{
            $this->error('操作失败');
        }
    }

    public function yewuinfoDelete()
    {
        $id = $_GET['id'];
        $info = M('yewuinfo');
        if ($info->where("id=$id")->delete()) {
            $this->success('操作成功','/Admin/Conf/YewuInfo');
        }else{
            $this->error('操作失败');
        }
    }
}
 ?>