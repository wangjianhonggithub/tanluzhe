<?php 
namespace Admin\Controller;
/**
* 
*/
use Think\Controller;
class UserController extends Controller
{
	public function ChongZhi()
	{
		$m = M('chongzhi');
		$count = $m->count();
		$p = getpage($count,10);
		$list = $m->field(true)->order('id desc')->limit($p->firstRow, $p->listRows)->select();
		$this->assign('result',$list);
		$this->assign('page', $p->show()); // 赋值分页输出
		$this->display();
	}

	public function DoChongZhi()
	{
		$mobile = $_GET['mobile'];
		$str = rand(1000000,9999999);
		$strMi = md5($str);
		$Staff = M("user")->where("username=$mobile")->save(['password'=>$strMi]);
		if ($Staff) {
			$chongzhi = M("chongzhi")->where("mobile=$mobile")->save(['mingma'=>$str]);
			if ($chongzhi) {
				$this->success('操作成功');
			}else{
				 $this->error('操作失败');
			}
			
		}else{
			 $this->error('重置失败');
		}
	}

	public function DeleteChongzhi()
	{
		$id = $_GET['id'];
		$Staff = M("chongzhi")->where("id=$id")->delete();
		if ($Staff) {
			$this->success('操作成功');
		}else{
			 $this->error('操作失败');
		}
	}

	public function Phone()
	{
		$m = M('update_phone');
		$count = $m->count();
		$p = getpage($count,10);
		$list = $m->field(true)->order('id desc')->limit($p->firstRow, $p->listRows)->select();
		$this->assign('result',$list);
		$this->assign('page', $p->show()); // 赋值分页输出
		$this->display();
	}

	public function UpdatePhone()
	{
		$id = $_GET['id'];
		$uid = $_GET['uid'];
		$phone = $_GET['phone'];
		$result = M('user')->where("id=$uid")->save(['username'=>$phone]);
		if ($result) {
			$res = M('update_phone')->where("id=$id")->save(['status'=>1]);
			if ($res) {
				$this->success('修改成功');
			}else{
				$this->error('修改失败');
			}
		}else{
			$this->error('操作失败');
		}
	}
}
 ?>