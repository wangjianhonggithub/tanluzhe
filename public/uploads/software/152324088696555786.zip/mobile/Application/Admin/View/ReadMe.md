后台列表页模板样例 后套模板 WMS -->
<include file="Public:Header" />
<!-- 首页用户列表开始 -->
<div class="container">
	<div class="mws-panel grid_7">
    	<div class="mws-panel-header">
        	<span><i class="icon-table"></i> 合作管理</span>
        </div>
        <div class="mws-panel-toolbar">
            <div class="btn-toolbar">
                <div class="btn-group">
                    <a href="" class="btn"><i class="icol-accept"></i> 添加合作方</a>
                </div>
            </div>
        </div>
        <div class="mws-panel-body no-padding">
            <table class="mws-table">
                <thead>
                    <tr>
                        <th>合作方ID</th>
                        <th>合作方名称</th>
                        <th>合作方描述</th>
                        <th>合作方链接</th>
                        <th>创建时间</th>
                        <th>修改时间</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>ID</td>
                        <td>阿里巴巴</td>
                        <td>先进的电商平台</td>
                        <td>www.taobao.com</td>
                        <td>xxxx-xx-xx xx:xx:xx</td>
                        <td>xxxx-xx-xx xx:xx:xx</td>
                        <td><a href="">修改</a>|<a href="" title="">删除</a></td>
                    </tr>
                </tbody>
                <tr class="content">
                        <td colspan="3" bgcolor="#FFFFFF"><div class="pages">
                                {$page}
                        </div></td>  
                    </tr>
            </table>
        </div>    	
    </div>
</div>
<!-- 结束 -->
<include file="Public:Footer" />





<!-- enctype 表单提交二进制转换 -->
multipart/form-data
<!-- 结束 -->




<!-- 后台样式 添加模板 WMS 开始-->
<include file="Public:Header" />
<!-- 首页用户列表开始 -->
<div class="container">
    <div class="mws-panel grid_7">
        <div class="mws-panel-header">
            <span><i class="icon-table"></i> 添加</span>
        </div>
        <div class="mws-panel-body no-padding">
            <form class="mws-form" action="form_layouts.html">
                <div class="mws-form-inline">
                    <div class="mws-form-row">
                        <label class="mws-form-label">合作方名称</label>
                        <div class="mws-form-item">
                            <input type="text" class="large">
                        </div>
                    </div>
                    <div class="mws-form-row">
                        <label class="mws-form-label">合作方描述</label>
                        <div class="mws-form-item">
                            <input type="text" class="large">
                        </div>
                    </div>
                    <div class="mws-form-row">
                        <label class="mws-form-label">合作方LOGO</label>
                        <div class="mws-form-item">
                            <input type="file" class="large">
                        </div>
                    </div>
                    <div class="mws-form-row">
                        <label class="mws-form-label">合作方网络链接</label>
                        <div class="mws-form-item">
                            <input type="text" class="large" placeholder="http://">
                        </div>
                    </div>
                </div>
                <div class="mws-button-row">
                    <input type="submit" value="点击提交" class="btn btn-danger">
                </div>
            </form>
        </div>   
    </div>
</div>
<!-- 结束 -->
<include file="Public:Footer" />
<!-- 结束 -->




<!-- 插件小工具 百度编辑器   开始(引入链接)-->
<!-- view 代码 -->
<div class="mws-form-row">
    <label class="mws-form-label">新闻资讯内容</label>
    <div class="mws-form-item">
        <script id="container" name="neirong" type="text/plain">
        </script>
    </div>
</div>
<script type="text/javascript" src="/public/ueditor/ueditor.config.js"></script>
<!-- 编辑器源码文件 -->
<script type="text/javascript" src="/public/ueditor/ueditor.all.js"></script>
<!-- 实例化编辑器 -->
<script>
    var editor = UE.getEditor('container',{
        initialFrameWidth :830,//设置编辑器宽度
        initialFrameHeight:400,//设置编辑器高度
        scaleEnabled:true
    });
</script>
<!-- 返回的方法 不能直接用在编辑器里所以需要转化一下 -->
 <?php echo htmlspecialchars_decode($result['case_content'])?>
<!-- 结束 -->

<!-- 分页 控制器里的 开始-->
$m = D('Cooperation');
$count = $m->where($where)->count();
$p = getpage($count,1);
$list = $m->field(true)->where($where)->order('id desc')->limit($p->firstRow, $p->listRows)->select();
$this->assign('result',$list);
$this->assign('page', $p->show()); // 赋值分页输出
<!-- 结束 -->


<!-- 列表循环 加分页样式  开始-->
<volist name="result" id="v">
<tr>
    <td>{$v.id}</td>
    <td>{$v.cooperation_name}</td>
    <td>{$v.cooperation_description}</td>
    <td>{$v.cooperation_path}</td>
    <td><img src="{$v.cooperation_img}" alt="" style="width:100px;height:100px;"></td>
    <td><?php echo date('Y-m-d H:i:s',$v['create_time']);?></td>
    <td><?php echo date('Y-m-d H:i:s',$v['update_time']);?></td>
    <td><a href="/Admin/Cooperate/updateCooperate?id={$v.id}">修改</a>|<a href="/Admin/Cooperate/DeleteCooperation?id={$v.id}" title="">删除</a></td>
</tr>

</volist>
<tr class="content">
    <td colspan="3" bgcolor="#FFFFFF"><div class="pages">
            {$page}
    </div></td>  
</tr>
<!-- 结束 -->

<!-- 富文本标签不显示的情况  开始-->
<?php echo htmlspecialchars_decode($v['news_content']) ?>
<!-- 结束