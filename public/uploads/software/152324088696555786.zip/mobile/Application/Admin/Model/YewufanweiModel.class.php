<?php 
namespace Admin\Model;
/**
* 范围模型
*/
use Think\Model;
class YewufanweiModel extends Model
{
	protected $tableName='yewufanwei';
	protected $_validate = array(
     array('fanwei','require','请填写名称'), 
     array('miaoshu','require','请填写描述'), 
   	);

   	public static function GetFanweiOne($id)
   	{
   		$fanwei = M('yewufanwei')->where("yfid=$id")->find();
   		return $fanwei;
   	}

   	public static function UpdateFanwei($id,$data)
   	{
   		$fanwei = M('yewufanwei')->where("yfid=$id")->save($data);
   		return $fanwei;
   	}
	
	public static function DeleteFanwei($id)
   	{
   		$fanwei = M('yewufanwei')->where("yfid=$id")->delete();
   		return $fanwei;
   	}
}
 ?>