<?php 
namespace Admin\Model;
use Think\Model;
class CooperationModel extends Model
{
	protected $tableName = 'cooperation';
	protected $_validate = array(
     array('cooperation_name','require','请填写合作方的名称'), 
     array('cooperation_description','require','请填写合作方的描述'), 
     array('cooperation_path','require','请填写合作方的网络地址'), 
   	);
	/**
	 * 查询单条提供修改
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-02
	 * @Email    carlos0608@163.com
	 * @param    [type]             $id [description]
	 */
	public function GetCooperationOne($id){
		$Cooperation = M("Cooperation"); // 实例化User对象
		// 查找status值为1name值为think的用户数据 
		$Cooperation->where("id=$id")->find();
		return $Cooperation->data();
	}


	/**
	 * 执行修改的操作
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-02
	 * @Email    carlos0608@163.com
	 * @return   [type]             [description]
	 */
	public function updateCooperation($id,$data){
		$Cooperation = M("Cooperation"); // 实例化User对象
		$result = $Cooperation->where("id=$id")->save($data); // 根据条件保存修改的数据
		return $result;
	}

	public function Delete($id)
	{
		$Cooperation = M("Cooperation"); // 实例化User对象
		$result = $Cooperation->where("id=$id")->delete(); 
		return $result;
	}
}
 ?>