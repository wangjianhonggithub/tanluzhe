<?php 
namespace Admin\Model;
/**
* Banner模型
*/
use Think\Model\RelationModel;
class BannerModel extends RelationModel
{
	protected $tableName = 'banner';
	
	/**
	 * 获取单条数据提供修改
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-03
	 * @Email    carlos0608@163.com
	 */
	public static function GetBannerOne($id)
	{
		$Banner = M('banner');
		$result = $Banner->where("banner_id=$id")->find();
		return $result;
	}
	/**
	 * 执行修改
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-03
	 * @Email    carlos0608@163.com
	 * @param    [type]             $id   [description]
	 * @param    [type]             $data [description]
	 */
	public static function UpdateBanner($id,$data)
	{
		$Banner = M('banner');
		$result = $Banner->where("banner_id=$id")->save($data);
		return $result;
	}

	public static function DeleteBanner($id)
	{
		$Banner = M('banner');
		$result = $Banner->where("banner_id=$id")->delete();
		return $result;
	}
}
 ?>