<?php 
namespace Admin\Model;
/**
* 招聘模型
*/
use Think\Model;
class JoinModel extends Model
{
	protected $tableName = 'join';
	protected $_validate = array(
		 array('job_name','require','请填写要招聘的岗位'), //默认情况下用正则进行验证
		 array('job_demand','require','请填写职位的职责和需求组'), //默认情况下用正则进行验证
    );
	/**
	 * 查询一条数据提供休息改
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-06
	 * @Email    carlos0608@163.com
	 * @param    [type]             $id [description]
	 */
	public static function GetJoinOne($id)
	{
		$Join = M('join');
		$result = $Join->where("id=$id")->find();
		return $result;
	}
	/**
	 * 执行修改
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-06
	 * @Email    carlos0608@163.com
	 * @param    [type]             $id   [description]
	 * @param    [type]             $data [description]
	 */
	public static function UpdateJoin($id,$data)
	{
		$Join = M('join');
		$result = $Join->where("id=$id")->save($data);
		return $result;
	}

	public static function DeleteJoin($id)
	{
		$Join = M('join');
		$result = $Join->where("id=$id")->delete();
		return $result;
	}
}
 ?>