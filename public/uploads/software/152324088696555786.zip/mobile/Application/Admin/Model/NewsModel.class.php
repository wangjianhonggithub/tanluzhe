<?php 
namespace Admin\Model;
/**
* 新闻资讯模型
*/
use Think\Model;
class NewsModel extends Model
{
	protected $tableName = 'news';
	protected $_validate = array(
     array('news_title','require','请填写新闻资讯的标题'), 
     array('news_description','require','请填写新闻资讯的描述'), 
     array('news_content','require','请填写新闻资讯的内容'), 
   	);
   	/**
     * 获取单条数据提供给修改操作
     * @Author   CarLos(翟)
     * @DateTime 2018-01-03
     * @Email    carlos0608@163.com
     * @param    get             $id  修改的新闻iD
     */
   	public static function GetNewsOne($id)
    {
   		$News = M('news');
   		$result = $News->where("id=$id")->find();
   		return $result;
   	}
    /**
     * 执行修改操作
     * @Author   CarLos(翟)
     * @DateTime 2018-01-03
     * @Email    carlos0608@163.com
     * @param    [type]             $id   [description]
     * @param    [type]             $data [description]
     */
    public static function UpdateNews($id,$data)
    {
      $News = M('news');
      $result = $News->where("id=$id")->save($data);
      return $result;
    }

    public static function DeleteNews($id)
    {
      $News = M('news');
      $result = $News->where("id=$id")->delete();
      return $result;
    }
}
 ?>
