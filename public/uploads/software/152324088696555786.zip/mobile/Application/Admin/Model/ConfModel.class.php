<?php 
namespace Admin\Model;
/**
* 配置文件 --模型
*/
use Think\Model;
class ConfModel extends Model
{
	protected $tableName = 'conf';
	/**
	 * 获取单条数据
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-05
	 * @Email    carlos0608@163.com
	 * @param    [type]             $id [description]
	 */
	public static function GetConfOne($id)
	{
		$Conf = M('Conf');
		$result = $Conf->where("id=$id")->find();
		return $result;
	}

	public static function UpdateConf($id,$data)
	{
		$Conf = M('Conf');
		$result = $Conf->where("id=$id")->save($data);
		return $result;
	}
}
 ?>