<?php 
namespace Admin\Model;
/**
* 职员-- 模型
*/
use Think\Model;
class StaffModel extends Model
{
	protected $tableName = 'staff';
	protected $_validate = array(
		 array('staff_name','require','请填写职位/职员名称'), //默认情况下用正则进行验证
		 array('staff_description','require','请填写职位/职员描述名称'), //默认情况下用正则进行验证
    );
	/**
	 * 修改
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-10
	 * @Email    carlos0608@163.com
	 * @param    [type]             $id   [description]
	 * @param    [type]             $data [description]
	 */
	public static function UpdateStaff($id,$data)
	{
		$staff = M('staff');
		$result = $staff->where("id=$id")->save($data);
		return $result;
	}

	public static function DeleteStaff($id)
	{
		$staff = M('staff');
		$result = $staff->where("id=$id")->delete();
		return $result;
	}
}
 ?>