<?php 
namespace Admin\Model;
/**
* 案例模型
*/
use Think\Model;
class CaseModel extends Model
{
	protected $tableName = 'case';
 	protected $_validate = array(
	    array('case_title','require','请填写案例标题'), //默认情况下用正则进行验证
	    array('case_description','require','请填写案例描述'), //默认情况下用正则进行验证
	    array('case_content','require','请填写案例内容'), //默认情况下用正则进行验证
	);
 	/**
 	 * 获取单条数据
 	 * @Author   CarLos(翟)
 	 * @DateTime 2018-01-05
 	 * @Email    carlos0608@163.com
 	 */
	public static function GetCaseOne($id)
	{
		$Case = M('case');
		$result = $Case->where("id=$id")->find();
		return $result;
	}
	/**
	 * 执行修改操作
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-05
	 * @Email    carlos0608@163.com
	 */
	public static function UpdateCase($id,$data)
	{
		$Case = M('case');
		$result = $Case->where("id=$id")->save($data);
		return $result;
	}
	/**
	 * 删除案例
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-05
	 * @Email    carlos0608@163.com
	 */
	public static function DeleteCase($id)
	{
		$Case = M('case');
		$result = $Case->where("id=$id")->delete();
		return $result;
	}
}
 ?>