<?php 
namespace Admin\Model;
/**
* 新闻资讯模型
*/
use Think\Model;
class UserModel extends Model
{
	protected $tableName = 'user';
	protected $_validate = array(
     array('username','','用户名已经存在请换一个用户名！',0,'unique',1), 
     array('password','require','请填写密码'),
     array('password','^1[3|4|5|8][0-9]\d{4,8}$','请输入正确的手机号!',0,'regex',1),
   	);

}
 ?>
