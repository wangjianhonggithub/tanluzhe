<?php 
namespace Admin\Model;
/**
* 分类模型
*/
use Think\Model;
class ClassifyModel extends Model
{
	protected $tableName = 'classify';
 	protected $_validate = array(
		 array('classify_name','require','请填写分类名称'), //默认情况下用正则进行验证
    );
 	/**
 	 * 获取单条数据提供修改
 	 * @Author   CarLos(翟)
 	 * @DateTime 2018-01-04
 	 * @Email    carlos0608@163.com
 	 * @param    [type]             $id [description]
 	 */
    public static function GetClassifyOne($id)
    {
    	$Classify = M('classify');
    	$result = $Classify->where("classify_id=$id")->find();
    	return $result;
    }
    /**
     * 执行修改
     * @Author   CarLos(翟)
     * @DateTime 2018-01-04
     * @Email    carlos0608@163.com
     * @param    [type]             $id   [description]
     * @param    [type]             $data [description]
     */
    public static function UpdateClassify($id,$data)
    {
    	$Classify = M('classify');
    	$result = $Classify->where("classify_id=$id")->save($data);
    	return $result;
    } 

    public static function DeleteClassify($id)
    {
    	$Classify = M('classify');
    	$result = $Classify->where("classify_id=$id")->delete();
    	return $result;
    }
}
 ?>