<?php 
namespace Admin\Model;
/**
* 导航模型
*/
use Think\Model\RelationModel;
class ColumnModel extends RelationModel
{
	protected $tableName="column";
	protected $_validate = array(
     array('column_name','require','请填写导航名称!!!'), //默认情况下用正则进行验证
     array('pid','require','请选择父级栏目!!!'), //默认情况下用正则进行验证
    );
	/**
	 * 提供给修改的数据
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-04
	 * @Email    carlos0608@163.com
	 */
    public static function GetColumnOne($id)
    {
    	$column = M('column');
    	$result = $column->where("id=$id")->find();
    	return $result;
    }

    public function UpdateColumn($id,$data)
    {
    	$column = M('column');
    	$result = $column->where("id=$id")->save($data);
    	return $result;
    }
}
 ?>