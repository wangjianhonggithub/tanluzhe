<?php 
namespace Admin\Model;
/**
* 后台用户模型
*/
use Think\Model;
class AdminUserModel extends Model
{
	protected $tableName = 'admin_user';
	protected $_validate = array(
     array('admin_user','','帐号名称已经存在！',0,'unique',1), 
     array('admin_passwd','require','请填写密码'), 
     array('admin_nickname','require','请填写用户的昵称'), 
   	);
	/**
	 * 查找单条数据
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-04
	 * @Email    carlos0608@163.com
	 * @param    [type]             $id [description]
	 */
	public static function GetAdminUserOne($id)
	{
		$AdminUser = M('admin_user');
		$result = $AdminUser->where("id=$id")->find();
		return $result;
	}
	/**
	 * 修改后台用户的密码
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-04
	 * @Email    carlos0608@163.com
	 */
	public static function  UpdateAdminPass($id,$data)
	{
		$AdminUser = D('AdminUser');
		$result = $AdminUser->where("id=$id")->save($data);
		return $result;

	}
	/**
	 * 删除后台操作
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-03
	 * @Email    carlos0608@163.com
	 */
	public static function DodeleteAdminUser($id)
	{
		$AdminUser = M('AdminUser');
		$result = $AdminUser->where("id=$id")->delete();
		return $result;
	}
}
 ?>