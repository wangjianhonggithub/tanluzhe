<?php 
namespace Admin\Model;
/**
* 业务 模型
*/
use Think\Model;
class YewuModel extends Model
{
	protected $tableName ='yewu';
	protected $_validate = array(
     array('yewu_name','require','请填写业务类别名称!!!'), //默认情况下用正则进行验证
     array('yewu_miaoshu','require','请填写业务简述!!!'), //默认情况下用正则进行验证
     array('yewu_img','require','请上传业务展示图!!!'), //默认情况下用正则进行验证
    );

    public static function GetYewuOne($id)
    {
    	$result = M('yewu')->where("id=$id")->find();
    	return $result;
    }

    public static function UpdateYewu($id,$data)
    {
    	$result = M('yewu')->where("id=$id")->save($data);
    	return $result;
    }
}
 ?>