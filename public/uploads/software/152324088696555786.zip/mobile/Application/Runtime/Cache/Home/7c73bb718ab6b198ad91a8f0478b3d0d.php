<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>瑞博行 -- 联系我们</title>
    <meta content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" name="viewport" />
    <link rel="stylesheet" href="/Public/Home/css/bootstrap.min.css">
    <link rel="stylesheet" href="/Public/Home/css/contact.css">
    <link rel="stylesheet" href="/Public/Home/css/public.css">
    <link rel="stylesheet" href="/Public/layui/css/layui.css">
    <script  src="/Public/layui/layui.all.js"></script>
    <script src="/Public/Home/js/include.js"></script>
</head>

<!--导航-->
<div class="nav">
    <div class="content">
        <p class="top text-center">
            <span>找商铺就选睿博行！</span>
            <span>一键提交需求 即可为你服务</span>
        </p>
        <p class="entrust">
            <input type="text" id="daohang_mobile">
            <span id="daohangweituo">立即委托</span>
        </p>
        <ul>
            <li><a href="/index.php/Home/SubPage/About">关于我们</a></li>
            <li><a href="/index.php/Home/SubPage/Business">业务板块</a></li>
            <li><a href="/index.php/Home/List/CaseList">招商项目</a></li>
            <li><a href="/index.php/Home/List/ZhaoBiaoList">我要招标</a></li>
            <li><a href="/index.php/Home/List/NewsList">新闻资讯</a></li>
            <li><a href="/index.php/Home/SubPage/Prospect">企业愿景</a></li>
            <li><a href="/index.php/Home/SubPage/Join">加入我们</a></li>
            <li><a href="/index.php/Home/SubPage/Contact">联系我们</a></li>
            <li><a href="/index.php/Home/User/Login">我要登录</a></li>
            <li><a href="/index.php/Home/User/Register">立即注册</a></li>
        </ul>
    </div>
    <a href="javascript:;" class="act">×</a>
</div>
<!--导航-->
<!--banner-->
<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
    <?php
 $bannerInfo = M('mobile_banner')->select(); ?>
    <!-- Indicators -->
    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">
        <?php if(is_array($bannerInfo)): $i = 0; $__LIST__ = $bannerInfo;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><div class="item">
                <img src="<?php echo C('imgurl'); echo ($v["img"]); ?>">
            </div><?php endforeach; endif; else: echo "" ;endif; ?>
    </div>
    <div class="banner">
        <img src="/Public/Home/images/logo.png" alt="logo" class="img-top">
        <a href="javascript:;" class="anniu">
            <img src="/Public/Home/images/three.png">
        </a>
        <div class="wz">
            <p>升级传统<span>新房</span>交易，开启<span>10倍</span>效能卖房</p>
            <p>公司自营项目、合作企业、以及需要资金改造升级的物业</p>
        </div>
        <p class="entrust">
            <input type="text" id="weituoshoujihao" placeholder=" 输入手机号">
            <span id="entrust">立即委托</span>
        </p>
    </div>
</div>
<!--banner-->

<div class="entrust-xq">
    <div class="left">
        <a href="javascript:;" id="lijiweituo" class="ast">立即委托</a>
        <p>
            我们会有客服专员<br>
            联系您，请您耐心等待！
        </p>
    </div>
    <div class="left">
        <a href="/Home/User/UserCenter" class="ast">完善资料并委托</a>
        <p>
            完善资料，帮您分配 <br>
            相应的客服专员，需求明确<br>
            节省您的宝贵时间！<br>
        </p>
        <a href="javascript:;" class="clos">关闭</a>
    </div>
</div>
<script src="/Public/Home/js/jquery-1.7.2.min.js"></script>
<script src="/Public/Home/js/bootstrap.min.js"></script>
<script src="/Public/Home/js/swiper-3.4.0.min.js"></script>
<script type="text/javascript">
    $(".carousel-indicators li").eq(0).addClass("active");
    $(".carousel-inner .item").eq(0).addClass("active");
    $(function(){
        $('#lijiweituo').click(function(){
           var shoujihao =  $('#weituoshoujihao').val();
           console.log(shoujihao);
            if (shoujihao=='') {
                layer.msg('请输入手机号', function(){
                    
                });
                return false;
            }
            var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(17[0-9]{1})|(18[0-9]{1}))+\d{8})$/; 
            if (!myreg.test(shoujihao)) {
                layer.msg('请输入正确的手机号', function(){
                    
                });
                return false;
            }
            $.get('/Home/Other/NiMing',{mobile:shoujihao},function(result){
                if(result == 1)
                {
                    layer.alert('委托成功', {icon: 6});
                }
                 else
                {
                     layer.msg('委托失败', {icon: 5});
                }
            })
        });
        $('#daohangweituo').click(function(){
           var mobile =  $('#daohang_mobile').val();
           console.log(mobile);
            if (mobile=='') {
                layer.msg('请输入手机号', function(){
                    
                });
                return false;
            }
            var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(17[0-9]{1})|(18[0-9]{1}))+\d{8})$/; 
            if (!myreg.test(mobile)) {
                layer.msg('请输入正确的手机号', function(){
                    
                });
                return false;
            }
            $.get('/Home/Other/NiMing',{mobile:mobile},function(result){
                if(result == 1)
                {
                    layer.alert('委托成功', {icon: 6});
                }
                 else
                {
                     layer.msg('委托失败', {icon: 5});
                }
            })
        });
    });
</script>

<div class="contact">
    <div class="content">
        <div class="top text-center">
            <?php $mobile = M('mobile_conf')->select(); ?>
            <p class="bt"><?php echo ($mobile[12]['english']); ?></p>
            <p class="wz"><?php echo ($mobile[12]['chinese']); ?></p>
        </div>
        <div class="da">
            <a href="tel:18910217777">
                <img src="/Public/Home/images/dian.png">
                <p>
                    <span>资讯服务热线</span>
                    <span><?php echo ($ConfInfo["conf_company_telephone"]); ?></span>
                </p>
            </a>
        </div>
        <div class="dizhi text-center">
            <?php echo ($ConfInfo["conf_company_name"]); ?> <br>
            地址：北京<?php echo ($ConfInfo["conf_company_address"]); ?><br>
            邮箱：<?php echo ($ConfInfo["conf_company_email"]); ?><br>
        </div>
        <div class="luxian text-center">
            <p>公交线路</p>
            <p>28路公交车：芳草地南站下车，步行470米至汉威大厦</p>
            <p>976路公交车：大北窑南站下车，步行1.5公里至汉威大厦</p>
            <p>运通107路公交车： 光华桥北站下车，步行850米至汉威大厦</p>
            <p>地铁10号线：金台夕照站（A西北口出）下车，步行850米至汉威大厦</p>
        </div>
        <img src="/Public/Home/images/map.png" class="map">
    </div>
</div>



<!--footer-->
<div class="footer">
    <?php  $Conf = M('conf'); $ConfInfo = $Conf->where('id=1')->find(); ?>
<div class="content text-center">
        <p class="top"><?php echo ($ConfInfo["conf_24hours"]); ?> / <?php echo ($ConfInfo["conf_company_telephone"]); ?> </p>
        <p class="top-w"><?php echo ($ConfInfo["conf_company_address"]); ?></p>
        <div class="wei">
            <img src="<?php echo ($ConfInfo["conf_qrcode"]); ?>">
            <div>
                <p><?php echo ($ConfInfo["conf_company_name"]); ?></p>
                <p><?php echo ($ConfInfo["conf_company_records"]); ?></p>
                <p>技术支持：鼎智诚科技</p>
            </div>
        </div>
    </div>
</div>
<!--footer-->

<div class="fixed-bottom">
    <div class="content">
        <ul>
            <li><a href="/">网站首页</a></li>
            <li><a href="#">立即委托</a></li>
            <li><a href="tel:<?php echo ($ConfInfo["conf_company_telephone"]); ?>">合作热线</a></li>
            <li><a href="/index.php/Home/User/join.html">加入我们</a></li>
        </ul>
    </div>
</div>

<div class="fixed-right">
     <?php
 $Userid = cookie('User_id'); if(empty($Userid)){ ?>
    <a href="/index.php/Home/User/Login">登录</a>
    <?php }else{ ?>
    <a href="/index.php/Home/User/UserCenter">中心</a>
    <?php } ?>
    <a href="/index.php/Home/User/Register">注册</a>
</div>

<script src="/Public/Home/js/jquery-1.7.2.min.js"></script>
<script src="/Public/Home/js/bootstrap.min.js"></script>
<script src="/Public/Home/js/index.js"></script>
</body>
</html>