<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>瑞博行 -- 加入我们</title>
    <meta content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" name="viewport" />
    <link rel="stylesheet" href="/Public/Home/css/bootstrap.min.css">
    <link rel="stylesheet" href="/Public/Home/css/join.css">
    <script src="/Public/Home/js/include.js"></script>
</head>
<body>

<!--导航-->
<nav class="navbar navbar-default">
    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.html"><img  src="/Public/Home/images/logo.png" alt="logo"></a>
        </div>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="/">首页</a></li>
                <li><a href="/Home/SubPage/About">关于瑞博行</a></li>
                <li><a href="/Home/SubPage/Business">业务板块</a></li>
                <li>
                    <a href="/Home/SubPage/Article">
                        招商项目
                    </a>
                    <div class="fixed-nav">
                        <img  src="/Public/Home/images/1.jpg" alt="">
                        <p>
                            <span>真情像草原广阔，层层风雨不能阻隔，一剪寒梅傲立雪招商项目招商项目招商项目招商项目招商项目招商项目招商项目</span>
                            <a href="invitation.html" class="ast">我要招标</a>
                        </p>
                    </div>
                </li>
                <li><a href="/Home/SubPage/Prospect">企业愿景</a></li>
                <li><a href="/Home/SubPage/Join">加入我们</a></li>
            </ul>
        </div><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>
<!--导航-->

<div class="entrust">
    <div class="left">
        <a href="" class="ast">立即委托</a>
        <p>
            我们会有客服专员<br>
            联系您，请您耐心等待！
        </p>
    </div>
    <div class="left">
        <a href="" class="ast">完善资料并委托</a>
        <p>
            完善资料，帮您分配 <br>
            相应的客服专员，需求明确<br>
            节省您的宝贵时间！<br>
        </p>
        <a href="javascript:;" class="clos">关闭</a>
    </div>
</div>

<!--banner-->
<div id="carousel-example-generic" class="carousel slide banner" data-ride="carousel">
    <div class="carousel-inner" role="listbox">
        <div class="item active">
            <img src="/Public/Home/images/banner.jpg">
        </div>
        <div class="item">
            <img src="/Public/Home/images/banner.jpg">
        </div>
        <div class="item">
            <img src="/Public/Home/images/banner.jpg">
        </div>
        <div class="item">
            <img src="/Public/Home/images/banner.jpg">
        </div>
    </div>
    <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
    <div class="banner-fixed">
        <p class="top">找商铺就找瑞博行!</p>
        <p class="title">一键提交需求 即可为你服务</p>
        <p>
            <input type="text" placeholder=" 输入手机号">
            <button id="entrust">立即委托</button>
        </p>
    </div>
</div>
<!--banner-->

<div class="join">
    <div class="left">
        <img src="/Public/Home/images/join-l.png">
    </div>
    <div class="right">
        <img src="/Public/Home/images/join-r.png">
        <div class="s-banner">
            <div id="carousel-example-generic1" class="carousel slide" data-ride="carousel">
                <!-- Indicators -->
                <ol class="carousel-indicators">
                    <li data-target="#carousel-example-generic1" data-slide-to="0" class="active"></li>
                    <li data-target="#carousel-example-generic1" data-slide-to="1"></li>
                    <li data-target="#carousel-example-generic1" data-slide-to="2"></li>
                    <li data-target="#carousel-example-generic1" data-slide-to="3"></li>
                </ol>
                <div class="carousel-inner" role="listbox">
                    <div class="item active">
                        <p class="bt">应聘职位</p>
                        <p class="zw">
                            <span>客户经理</span>
                        </p>
                        <p class="xq">
                            岗位职责： <br><br>
                            1.负责公司分管区域客户培训课程的市场推广和销售工作，并达成业绩指标；<br>
                            2.了解客户需求，完成所辖客户的联络、维护，不断改善客户关系；<br><br>
                            任职要求：<br><br>
                            1.对培训行业营销工作有强烈的兴趣与热情；<br>
                            2.口齿清晰伶俐，普通话标准流利；<br>
                        </p>
                        <p class="anniu">
                            <a href="">2017-06-02</a>
                            <a href="">我要应聘</a>
                        </p>
                    </div>
                    <div class="item">
                        <p class="bt">应聘职位</p>
                        <p class="zw">
                            <span>客户经理</span>
                        </p>
                        <p class="xq">
                            岗位职责： <br><br>
                            1.负责公司分管区域客户培训课程的市场推广和销售工作，并达成业绩指标；<br>
                            2.了解客户需求，完成所辖客户的联络、维护，不断改善客户关系；<br><br>
                            任职要求：<br><br>
                            1.对培训行业营销工作有强烈的兴趣与热情；<br>
                            2.口齿清晰伶俐，普通话标准流利；<br>
                        </p>
                        <p class="anniu">
                            <a href="">2017-06-02</a>
                            <a href="">我要应聘</a>
                        </p>
                    </div>
                    <div class="item">
                        <p class="bt">应聘职位</p>
                        <p class="zw">
                            <span>客户经理</span>
                        </p>
                        <p class="xq">
                            岗位职责： <br><br>
                            1.负责公司分管区域客户培训课程的市场推广和销售工作，并达成业绩指标；<br>
                            2.了解客户需求，完成所辖客户的联络、维护，不断改善客户关系；<br><br>
                            任职要求：<br><br>
                            1.对培训行业营销工作有强烈的兴趣与热情；<br>
                            2.口齿清晰伶俐，普通话标准流利；<br>
                        </p>
                        <p class="anniu">
                            <a href="">2017-06-02</a>
                            <a href="">我要应聘</a>
                        </p>
                    </div>
                    <div class="item">
                        <p class="bt">应聘职位</p>
                        <p class="zw">
                            <span>客户经理</span>
                        </p>
                        <p class="xq">
                            岗位职责： <br><br>
                            1.负责公司分管区域客户培训课程的市场推广和销售工作，并达成业绩指标；<br>
                            2.了解客户需求，完成所辖客户的联络、维护，不断改善客户关系；<br><br>
                            任职要求：<br><br>
                            1.对培训行业营销工作有强烈的兴趣与热情；<br>
                            2.口齿清晰伶俐，普通话标准流利；<br>
                        </p>
                        <p class="anniu">
                            <a href="">2017-06-02</a>
                            <a href="">我要应聘</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="advertising">
    <div class="content">
        <div class="left">
            <ul>
                <li>
                    <img src="/Public/Home/images/jion(1).png">
                    <span>
                        招聘电话 <br>
                        010 - 6506 - 8337
                    </span>
                </li>
                <li>
                    <img src="/Public/Home/images/jion(2).png">
                    <span>
                        简历投送邮箱<br>
                        rbh6668888@163.com
                    </span>
                </li>
                <li>
                    <img src="/Public/Home/images/jion(3).png">
                    <span>
                        应聘地址<br>
                        北京市朝阳区汉威大厦
                    </span>
                </li>
            </ul>
        </div>
        <div class="right">
            <img src="/Public/Home/images/wei.png">
            <p>关注公众号</p>
        </div>
    </div>
</div>

<div class="apply">
    <img src="/Public/Home/images/apply.png" class="img-top">
    <div class="content">
        <img src="/Public/Home/images/apply-l.png" class="apply-img">
        <div class="dan">
            <p class="title">快速编写微简历</p>
            <form action="">
                <ul>
                    <li>
                        <label class="f-one"><span>姓名 </span> <input type="text"></label>
                        <label class="f-two"><span>出生年月 </span> <input type="text"></label>
                        <label class="f-three"><span>联系电话 </span> <input type="text" maxlength="11"></label>
                    </li>
                    <li style="clear: both">
                        <p>
                            <span>性别 </span>
                            <label><input type="radio" name="xin"> <span>男</span></label>
                            <label><input type="radio" name="xin"> <span>女</span></label>
                        </p>
                        <p>
                            <label>
                                <span class="tou">上传我的头像</span><span class="shang"><span>点击上传头像</span><input type="file" style="display: inline-block;"></span>
                            </label>
                        </p>
                    </li>
                    <li>
                        <label><span>上/现任单位以及职务 </span> <input type="text" placeholder="请输入单位"><input type="text" placeholder="请输入职务"></label>
                    </li>
                    <li>
                        <label><span>应聘职务 </span> <input type="text"></label>
                        <label><span>最高学历 </span> <input type="text"><input type="text" placeholder="毕业院校（选填）"></label>
                    </li>
                    <li>
                        <label>
                            <span>工作经历以及个人介绍 </span>
                            <textarea rows="5" placeholder="在线填写您的工作经历个人介绍，提升您的就职机会！"></textarea>
                        </label>
                    </li>
                    <li>
                        <input type="submit" value="立即提交">
                    </li>
                </ul>
            </form>
        </div>
    </div>
</div>

<div class="process">
    <div class="content">
        <p>
            应聘流程
            <span></span>
        </p>
        <img src="/Public/Home/images/liu.png">
    </div>
</div>


<!--搜索案例-->
<div class="seek">
    <div class="content">
        <p class="top">快捷搜索</p>
        <p class="suo">
            <input type="text" placeholder=" 输入关键词">
            <button>立即搜索</button>
        </p>
        <p class="wz">
            找到跟您想似的案例，帮助您更好的了解我们
        </p>
        <div class="fixed-f">
            <p>专业管理团队</p>
        </div>
    </div>
</div>
<!--搜索案例-->

<!--footer-->
<div class="footer">
    <div class="content">
        <div class="left">
            <ul>
                <li>
                    <p class="title">开发产品</p>
                    <p>门面房托管</p>
                    <p>社区商业</p>
                    <p>商场·超市·国企房源</p>
                </li>
                <li>
                    <p class="title">招商品牌</p>
                    <p>招商资源</p>
                    <p>联系人</p>
                    <p>品牌类别</p>
                    <p>前景</p>
                </li>
                <li>
                    <p class="title">招商方式</p>
                    <p>渠道</p>
                    <p>电话</p>
                    <p>网络</p>
                    <p>招标</p>
                </li>
            </ul>
            <div class="fixed-f">
                <p>专业高级顾问</p>
            </div>
        </div>
        <div class="right">
            <span class="r-left">
                <span>CONTACT 联系我们</span>
                <span>北京睿博行卓越商业地产有限公司</span>
                <span>电话：189 - 1021 - 7777 </span>
                <span>邮箱：rbh6668888@163.com</span>
                <span>备案号：xxxxxx</span>
            </span>
            <img  src="/Public/Home/images/w.png">
        </div>
    </div>
</div>
<!--footer-->

<div class="fixed-right">
    <a href="javascript:;">
        <span>联系</span>
        <span>电话</span>
        <p class="fu"><img  src="/Public/Home/images/dian.png" alt=""> <span>189 - 1021 - 7777</span></p>
    </a>
    <a href="login.html">
        <span>立即</span>
        <span>登录</span>
    </a>
    <a href="registered.html">
        <span>免费</span>
        <span>注册</span>
    </a>
    <a href="">
        <span>需求</span>
        <span>反馈</span>
    </a>
</div>

<script src="/Public/Home/js/jquery-1.7.2.min.js"></script>
<script src="/Public/Home/js/bootstrap.min.js"></script>
<script src="/Public/Home/js/join.js"></script>
</body>
</body>
</html>