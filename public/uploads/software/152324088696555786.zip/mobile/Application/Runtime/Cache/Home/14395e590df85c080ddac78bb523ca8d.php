<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>瑞博行 -- 我要招标</title>
    <meta content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" name="viewport" />
    <link rel="stylesheet" href="/Public/Home/css/bootstrap.min.css">
    <link rel="stylesheet" href="/Public/Home/css/invitation.css">
    <script src="/Public/Home/js/include.js"></script>
</head>
<body>

<!--导航-->
<nav class="navbar navbar-default">
    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="/"><img  src="/Public/Home/images/logo.png" alt="logo"></a>
        </div>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="/">首页</a></li>
                <li><a href="/Home/SubPage/About">关于瑞博行</a></li>
                <li><a href="/Home/SubPage/Business">业务板块</a></li>
                <li>
                    <a href="/Home/SubPage/Article">
                        招商项目
                    </a>
                    <div class="fixed-nav">
                        <img  src="/Public/Home/images/1.jpg" alt="">
                        <p>
                            <span>真情像草原广阔，层层风雨不能阻隔，一剪寒梅傲立雪招商项目招商项目招商项目招商项目招商项目招商项目招商项目</span>
                            <a href="invitation.html" class="ast">我要招标</a>
                        </p>
                    </div>
                </li>
                <li><a href="/Home/SubPage/Prospect">企业愿景</a></li>
                <li><a href="/Home/SubPage/Join">加入我们</a></li>
            </ul>
        </div><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>
<!--导航-->

<div class="entrust">
    <div class="left">
        <a href="" class="ast">立即委托</a>
        <p>
            我们会有客服专员<br>
            联系您，请您耐心等待！
        </p>
    </div>
    <div class="left">
        <a href="" class="ast">完善资料并委托</a>
        <p>
            完善资料，帮您分配 <br>
            相应的客服专员，需求明确<br>
            节省您的宝贵时间！<br>
        </p>
        <a href="javascript:;" class="clos">关闭</a>
    </div>
</div>

<!--banner-->
<div id="carousel-example-generic" class="carousel slide banner" data-ride="carousel">
    <div class="carousel-inner" role="listbox">
        <div class="item active">
            <img src="/Public/Home/images/banner.jpg">
        </div>
        <div class="item">
            <img src="/Public/Home/images/banner.jpg">
        </div>
        <div class="item">
            <img src="/Public/Home/images/banner.jpg">
        </div>
        <div class="item">
            <img src="/Public/Home/images/banner.jpg">
        </div>
    </div>
    <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
    <div class="banner-fixed">
        <p class="top">找商铺就找瑞博行!</p>
        <p class="title">一键提交需求 即可为你服务</p>
        <p>
            <input type="text" placeholder=" 输入手机号">
            <button id="entrust">立即委托</button>
        </p>
    </div>
</div>
<!--banner-->

<div class="top">
    <div class="content">
        <ul>
            <li>
                <img src="/Public/Home/images/icn(1).png">
                <p>综合调研</p>
            </li>
            <li>
                <img src="/Public/Home/images/icn(2).png">
                <p>效益评估</p>
            </li>
            <li>
                <img src="/Public/Home/images/icn(3).png">
                <p>市场分析</p>
            </li>
            <li>
                <img src="/Public/Home/images/icn(4).png">
                <p>推广计划</p>
            </li>
            <li>
                <img src="/Public/Home/images/icn(5).png">
                <p>营销几乎</p>
            </li>
            <li>
                <img src="/Public/Home/images/icn(6).png">
                <p>风险评估</p>
            </li>
            <li>
                <img src="/Public/Home/images/icn(7).png">
                <p>项目定位</p>
            </li>
            <li>
                <img src="/Public/Home/images/icn(8).png">
                <p>财物分析</p>
            </li>
        </ul>
    </div>
</div>

<div class="new-b">
    <div class="content">
        <p></p>
        <p>我要招标</p>
    </div>
</div>

<div class="subject">
    <div class="content">
        <div class="biao">
            <div class="left">
                <img src="/Public/Home/images/jian.png">
                <div class="l-right">
                    <p>189 - 1021 - 7777  <span>咨询热线</span></p>
                    <p><span>招商流程</span></p>
                    <p class="wz">了解它</p>
                    <p class="wz">留言咨询/电话咨询</p>
                    <p class="wz">等待回访</p>
                    <p class="wz">上门考察</p>
                    <p class="wz">确定合作</p>
                </div>
            </div>
            <div class="right">
                <form>
                    <p class="top">快速咨询</p>
                    <p>
                        <input type="text" placeholder="请输入姓名">
                        <input type="text" placeholder="请输入您的联系电话">
                    </p>
                    <p>
                        <textarea name="" id="" cols="20" rows="5" placeholder="在线填写需求"></textarea>
                    </p>
                    <p>
                        <input type="submit" value="立即提交">
                    </p>
                </form>
            </div>
        </div>
        <div class="liao">
            <img src="/Public/Home/images/liao.png">
            <div class="wz">
                <p>玉精于雕琢，商场重在管理创新，金力天从业主、商户、消费者角度出发</p>
                <p>
                    运营管理阶段金力天拥有一套行之有效的商业管理体系，构建优秀的经营管理团队，制定租赁管理、商场推广、物业管理等相关管理规程制定，对于业主、
                    租户及消费者三方关系维护有着丰富的经验，时刻监控市场变化及时调整商城运营策略并对运菖风险及时防范。
                </p>
            </div>
        </div>
        <div class="list">
            <ul>
                <li>
                    <img src="/Public/Home/images/img1.png">
                    <div>
                        <p class="top">
                            <span>团</span>
                            <span>队</span>
                            <span>组</span>
                            <span>建</span>
                        </p>
                        <p>物业部</p>
                        <p>运营部组建</p>
                    </div>
                </li>
                <li>
                    <img src="/Public/Home/images/img2.png">
                    <div>
                        <p class="top">
                            <span>交</span>
                            <span>房</span>
                            <span>验</span>
                            <span>收</span>
                        </p>
                        <p>入场签约</p>
                        <p>装修进场</p>
                    </div>
                </li>
                <li>
                    <img src="/Public/Home/images/img3.png">
                    <div>
                        <p class="top">
                            <span>后</span>
                            <span>期</span>
                            <span>养</span>
                            <span>市</span>
                        </p>
                        <p>运营管理</p>
                        <p>物业管理</p>
                        <p>宣传推广</p>
                    </div>
                </li>
                <li>
                    <img src="/Public/Home/images/img4.png">
                    <div>
                        <p class="top">
                            <span>开</span>
                            <span>业</span>
                            <span>促</span>
                            <span>销</span>
                        </p>
                        <p>开业彩排</p>
                        <p>开业营销</p>
                        <p>开业形象推广</p>
                        <p>开业庆典</p>
                        <p>开业促销</p>
                        <p>开业技术问题处理</p>
                    </div>
                </li>
                <li>
                    <img src="/Public/Home/images/img5.png">
                    <div>
                        <p class="top">
                            <span>卖</span>
                            <span>场</span>
                            <span>包</span>
                            <span>装</span>
                        </p>
                        <p>道士系统制作</p>
                        <p>内外场商业气氛营造</p>
                    </div>
                </li>
                <li>
                    <img src="/Public/Home/images/img6.png">
                    <div>
                        <p class="top">
                            <span>入</span>
                            <span>场</span>
                            <span>布</span>
                            <span>货</span>
                        </p>
                        <p>商户入场率</p>
                        <p>入场布货率</p>
                        <p>二装完成率</p>
                    </div>
                </li>
            </ul>
        </div>
        <div class="liao">
            <img src="/Public/Home/images/dui.png">
            <div class="wz">
                <p></p>
                <p>
                    商业地产的建筑规划设计是在市场研究的基础上，承接项目业态规划和方奏设计之间的重要工作，商业地产的建筑规划对于项目
                    最终运营的起着重要的影响作用．我司致力于打造规划设计与商业运莒的完美融台，即能使成为优秀的设计作品还能使项目创造
                    更高的商业价值
                </p>
                <img src="/Public/Home/images/ss.png" class="img-top">
            </div>
        </div>
        <div class="liao">
            <img src="/Public/Home/images/yi.png">
            <div class="wz">
                <ul>
                    <li><a href="javascript:;">基础指标</a></li>
                    <li><a href="javascript:;">总体规划设计</a></li>
                    <li><a href="javascript:;">概念效果图</a></li>
                    <li><a href="javascript:;">建筑设计</a></li>
                    <li><a href="javascript:;">空间设计</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>


<!--搜索案例-->
<div class="seek">
    <div class="content">
        <p class="top">快捷搜索</p>
        <p class="suo">
            <input type="text" placeholder=" 输入关键词">
            <button>立即搜索</button>
        </p>
        <p class="wz">
            找到跟您想似的案例，帮助您更好的了解我们
        </p>
        <div class="fixed-f">
            <p>专业管理团队</p>
        </div>
    </div>
</div>
<!--搜索案例-->

<!--footer-->
<div class="footer">
    <div class="content">
        <div class="left">
            <ul>
                <li>
                    <p class="title">开发产品</p>
                    <p>门面房托管</p>
                    <p>社区商业</p>
                    <p>商场·超市·国企房源</p>
                </li>
                <li>
                    <p class="title">招商品牌</p>
                    <p>招商资源</p>
                    <p>联系人</p>
                    <p>品牌类别</p>
                    <p>前景</p>
                </li>
                <li>
                    <p class="title">招商方式</p>
                    <p>渠道</p>
                    <p>电话</p>
                    <p>网络</p>
                    <p>招标</p>
                </li>
            </ul>
            <div class="fixed-f">
                <p>专业高级顾问</p>
            </div>
        </div>
        <?php  $Conf = M('conf'); $ConfInfo = $Conf->where('id=1')->find(); ?>
        <div class="right">
            <span class="r-left">
                <span>CONTACT 联系我们</span>
                <span><?php echo ($ConfInfo["conf_company_name"]); ?></span>
                <span>电话：<?php echo ($ConfInfo["conf_company_telephone"]); ?> </span>
                <span>邮箱：<?php echo ($ConfInfo["conf_company_email"]); ?></span>
                <span>备案号：<?php echo ($ConfInfo["conf_company_records"]); ?></span>
            </span>
            <img  src="<?php echo ($ConfInfo["conf_qrcode"]); ?>">
        </div>
    </div>
</div>
<!--footer-->

<div class="fixed-right">
    <a href="javascript:;">
        <span>联系</span>
        <span>电话</span>
        <p class="fu"><img  src="/Public/Home/images/dian.png" alt=""> <span><?php echo ($ConfInfo["conf_company_telephone"]); ?></span></p>
    </a>
    <?php
 $Userid = cookie('User_id'); if(empty($Userid)){ ?>
    <a href="/Home/User/Login">
        <span>立即</span>
        <span>登录</span>
    </a>
    <?php }else{ ?>
    <a href="/Home/User/UserCenter">
        <span>个人</span>
        <span>中心</span>
    </a>
    <?php } ?>
    <a href="/Home/User/Register">
        <span>免费</span>
        <span>注册</span>
    </a>
    <a href="">
        <span>需求</span>
        <span>反馈</span>
    </a>
</div>

<script src="/Public/Home/js/jquery-1.7.2.min.js"></script>
<script src="/Public/Home/js/bootstrap.min.js"></script>
<script src="/Public/Home/js/invitation.js"></script>
</body>
</html>