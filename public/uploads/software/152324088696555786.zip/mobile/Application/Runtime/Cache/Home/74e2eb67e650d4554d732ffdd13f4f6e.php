<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>瑞博行 -- 修改手机号</title>
    <meta content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" name="viewport" />
    <link rel="stylesheet" href="/Public/Home/css/bootstrap.min.css">
    <link rel="stylesheet" href="/Public/Home/css/personal-mima.css">
    <link rel="stylesheet" href="/Public/Home/css/personal-nav.css">
    <link rel="stylesheet" href="/Public/layui/css/layui.css">
    <script  src="/Public/layui/layui.all.js"></script>
    <script src="/Public/Home/js/include.js"></script>
</head>
<body>
<div class="personal">
    <div class="content">
        <div class="nav">
    <p class="top">
        <img src="/Public/Home/images/login-logo.png">
        <span>
            个人中心
            <a href="/index.php/Home/User/Loginout">退出</a>
        </span>
    </p>
    <ul>
        <li>
            <a href="/index.php/Home/User/UserCenter">完善资料</a>
        </li>
        <li>
            <a href="/index.php/Home/User/UpdatePasswd">修改密码</a>
        </li>
        <li>
            <a href="/index.php/Home/User/UpdateTelephone">修改手机号</a>
        </li>
        <li>
            <a href="/index.php/Home/User/Single">我的反馈单</a>
        </li>
    </ul>
</div>
<p class="title text-center">
    <span>请选择您需要的业务完善您的资料</span>
    <span>直接跳转到下一步</span>
</p>

<div class="fixed-bottom">
    <div class="content">
        <ul>
            <li><a href="/">网站首页</a></li>
            <li><a href="tel:18910217777">免费电话</a></li>
            <li><a href="">在线沟通</a></li>
            <li><a href="">立即委托</a></li>
        </ul>
    </div>
</div>

<div class="fixed-right">
     <?php
 $Userid = cookie('User_id'); if(empty($Userid)){ ?>
    <a href="/index.php/Home/User/Login">登录</a>
    <?php }else{ ?>
    <a href="/index.php/Home/User/UserCenter">中心</a>
    <?php } ?>
    <a href="/index.php/Home/User/Register">注册</a>
</div>
        <div class="personal-right">
            <p class="top"><span>手机号</span></p>
            <form>
                <label class="lab">
                    <span>您当前注册的手机号</span>
                    <p class="inp"><?php echo ($username["username"]); ?></p>
                    <input type="hidden" name="oldphone" id="oldphone" value="<?php echo ($username["username"]); ?>">
                    <input type="hidden" name="uid" id="uid" value="<?php echo ($username["id"]); ?>">
                </label>
                <label class="lab">
                    <span>请输入更换的手机号</span>
                    <input type="text" name="newphone" id="newphone">
                </label>
                <input type="button" id="shouji_tijiao" class="tujiao" value="提交">
            </form>
        </div>
    </div>
</div>
<script src="/Public/Home/js/jquery-1.7.2.min.js"></script>
<script src="/Public/Home/js/bootstrap.min.js"></script>
<script src="/Public/Home/js/index.js"></script>
<script type="text/javascript">
    $(function(){
        $('#shouji_tijiao').click(function(){
            var oldphone = $('#oldphone').val();
            var newphone = $('#newphone').val();
            var uid = $('#uid').val();
            $.post('/Home/User/DoUpdatePhone',{oldphone:oldphone,newphone:newphone,uid:uid},function(res){
               var msg=eval("("+res+")");
               if (msg.status==2) {
                   layer.msg(msg.info, function(){
                   });
                   return false;
               }
               if (msg.status==1) {
                   layer.alert(msg.info, {icon: 6});
                   window.location.href='/Home/User/UserCenter';
               }
               if (msg.status == 0) {
                   layer.alert(msg.info, {icon: 5});
                   window.location.href='/Home/User/DoUpdatePhone';
               }
            }); 
        });
    });
</script>
</body>
</html>