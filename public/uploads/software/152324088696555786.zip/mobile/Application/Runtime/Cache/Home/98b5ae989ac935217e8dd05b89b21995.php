<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>瑞博行 -- 招商项目</title>
    <meta content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" name="viewport" />
    <link rel="stylesheet" href="/Public/Home/css/bootstrap.min.css">
    <link rel="stylesheet" href="/Public/Home/css/article.css">
    <script src="/Public/Home/js/include.js"></script>
</head>
<body>

<!--导航-->
<nav class="navbar navbar-default">
    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.html"><img  src="/Public/Home/images/logo.png" alt="logo"></a>
        </div>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="/">首页</a></li>
                <li><a href="/Home/SubPage/About">关于瑞博行</a></li>
                <li><a href="/Home/SubPage/Business">业务板块</a></li>
                <li>
                    <a href="/Home/SubPage/Business/Article">
                        招商项目
                    </a>
                    <div class="fixed-nav">
                        <img  src="/Public/Home/images/1.jpg" alt="">
                        <p>
                            <span>真情像草原广阔，层层风雨不能阻隔，一剪寒梅傲立雪招商项目招商项目招商项目招商项目招商项目招商项目招商项目</span>
                            <a href="invitation.html" class="ast">我要招标</a>
                        </p>
                    </div>
                </li>
                <li><a href="prospect.html">企业愿景</a></li>
                <li><a href="join.html">加入我们</a></li>
            </ul>
        </div><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>
<!--导航-->

<div class="entrust">
    <div class="left">
        <a href="" class="ast">立即委托</a>
        <p>
            我们会有客服专员<br>
            联系您，请您耐心等待！
        </p>
    </div>
    <div class="left">
        <a href="" class="ast">完善资料并委托</a>
        <p>
            完善资料，帮您分配 <br>
            相应的客服专员，需求明确<br>
            节省您的宝贵时间！<br>
        </p>
        <a href="javascript:;" class="clos">关闭</a>
    </div>
</div>

<!--banner-->
<div id="carousel-example-generic" class="carousel slide banner" data-ride="carousel">
    <div class="carousel-inner" role="listbox">
        <div class="item active">
            <img src="/Public/Home/images/banner.jpg">
        </div>
        <div class="item">
            <img src="/Public/Home/images/banner.jpg">
        </div>
        <div class="item">
            <img src="/Public/Home/images/banner.jpg">
        </div>
        <div class="item">
            <img src="/Public/Home/images/banner.jpg">
        </div>
    </div>
    <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
    <div class="banner-fixed">
        <p class="top">找商铺就找瑞博行!</p>
        <p class="title">一键提交需求 即可为你服务</p>
        <p>
            <input type="text" placeholder=" 输入手机号">
            <button id="entrust">立即委托</button>
        </p>
    </div>
</div>
<!--banner-->

<div class="title">
    <div class="content">
        <div class="top">
            <p>商业地产的建筑规划设计师在市场研究的基础上，承接项目业态规划和方案设计之间的</p>
            <p>重要工作，商业地产的建筑规划对于项目最终运营的起着重要的影响作用。我司致力于打造规划设计与商业运营的完美融合，即能</p>
            <p>使成为优秀的设计作品还能使项目创造更高的商业价值</p>
        </div>
    </div>
    <div class="tu">
        <div class="left">
            <img src="/Public/Home/images/article-l.png">
        </div>
        <div class="right">
            <ul>
                <li>
                    <a href="javascript:;">
                        <span class="number">01</span>
                        <span class="wz">
                            <span>招商筹备阶段</span>
                            招商团队、人员培训、制定招商原则、招商策略、招商政策、招商周期、招商文本准备
                        </span>
                    </a>
                </li>
                <li>
                    <a href="javascript:;">
                        <span class="number">02</span>
                        <span class="wz">
                            <span>招商蓄水阶段</span>
                            主力店引进、大客户落位、客户蓄水登记、客户资质审核、品牌模拟落位
                        </span>
                    </a>
                </li>
                <li>
                    <a href="javascript:;">
                        <span class="number">03</span>
                        <span class="wz">
                            <span>招商执行阶段</span>
                            招商大会召开、品牌助理点签约、品牌审核、招商数量、租赁协议签署
                        </span>
                    </a>
                </li>
                <li>
                    <a href="javascript:;">
                        <span class="number">04</span>
                        <span class="wz">
                            <span>商户进场阶段</span>
                            招商扫尾、进场装修审核、入场布货审核、瑞博行彩排语言、正式开业
                        </span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>

<div class="subject">
    <div class="content">
        <ul>
            <li>
                <img src="/Public/Home/images/article.png">
                <p class="bt"><b>标题</b></p>
                <p class="title">根据周边商业配比以及消费评测，成功为项目转型定位、合理商业卖场布局，从而盘活物业提前按时间节点运营本项目。</p>
                <p class="anniu"><a href="invitation.html">我要招标</a><a href="javascript:;">2017-08-20</a></p>
            </li>
            <li>
                <img src="/Public/Home/images/article.png">
                <p class="bt"><b>标题</b></p>
                <p class="title">根据周边商业配比以及消费评测，成功为项目转型定位、合理商业卖场布局，从而盘活物业提前按时间节点运营本项目。</p>
                <p class="anniu"><a href="invitation.html">我要招标</a><a href="javascript:;">2017-08-20</a></p>
            </li>
        </ul>
    </div>
</div>



<!--搜索案例-->
<div class="seek">
    <div class="content">
        <p class="top">快捷搜索</p>
        <p class="suo">
            <input type="text" placeholder=" 输入关键词">
            <button>立即搜索</button>
        </p>
        <p class="wz">
            找到跟您想似的案例，帮助您更好的了解我们
        </p>
        <div class="fixed-f">
            <p>专业管理团队</p>
        </div>
    </div>
</div>
<!--搜索案例-->

<!--footer-->
<div class="footer">
    <div class="content">
        <div class="left">
            <ul>
                <li>
                    <p class="title">开发产品</p>
                    <p>门面房托管</p>
                    <p>社区商业</p>
                    <p>商场·超市·国企房源</p>
                </li>
                <li>
                    <p class="title">招商品牌</p>
                    <p>招商资源</p>
                    <p>联系人</p>
                    <p>品牌类别</p>
                    <p>前景</p>
                </li>
                <li>
                    <p class="title">招商方式</p>
                    <p>渠道</p>
                    <p>电话</p>
                    <p>网络</p>
                    <p>招标</p>
                </li>
            </ul>
            <div class="fixed-f">
                <p>专业高级顾问</p>
            </div>
        </div>
        <div class="right">
            <span class="r-left">
                <span>CONTACT 联系我们</span>
                <span>北京睿博行卓越商业地产有限公司</span>
                <span>电话：189 - 1021 - 7777 </span>
                <span>邮箱：rbh6668888@163.com</span>
                <span>备案号：xxxxxx</span>
            </span>
            <img  src="/Public/Home/images/w.png">
        </div>
    </div>
</div>
<!--footer-->

<div class="fixed-right">
    <a href="javascript:;">
        <span>联系</span>
        <span>电话</span>
        <p class="fu"><img  src="/Public/Home/images/dian.png" alt=""> <span>189 - 1021 - 7777</span></p>
    </a>
    <a href="login.html">
        <span>立即</span>
        <span>登录</span>
    </a>
    <a href="registered.html">
        <span>免费</span>
        <span>注册</span>
    </a>
    <a href="">
        <span>需求</span>
        <span>反馈</span>
    </a>
</div>

<script src="/Public/Home/js/jquery-1.7.2.min.js"></script>
<script src="/Public/Home/js/bootstrap.min.js"></script>
<script src="/Public/Home/js/article.js"></script>
</body>
</html>