<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>瑞博行 -- 我要招标</title>
    <meta content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" name="viewport" />
    <link rel="stylesheet" href="/Public/Home/css/bootstrap.min.css">
    <link rel="stylesheet" href="/Public/Home/css/mark.css">
    <link rel="stylesheet" href="/Public/Home/css/public.css">
    <link rel="stylesheet" href="/Public/layui/css/layui.css">
    <script  src="/Public/layui/layui.all.js"></script>
    <script src="/Public/Home/js/include.js"></script>
</head>
<body>
<!--导航-->
<div class="nav">
    <div class="content">
        <p class="top text-center">
            <span>找商铺就选睿博行！</span>
            <span>一键提交需求 即可为你服务</span>
        </p>
        <p class="entrust">
            <input type="text" id="daohang_mobile">
            <span id="daohangweituo">立即委托</span>
        </p>
        <ul>
            <li><a href="/index.php/Home/SubPage/About">关于我们</a></li>
            <li><a href="/index.php/Home/SubPage/Business">业务板块</a></li>
            <li><a href="/index.php/Home/List/CaseList">招商项目</a></li>
            <li><a href="/index.php/Home/List/ZhaoBiaoList">我要招标</a></li>
            <li><a href="/index.php/Home/List/NewsList">新闻资讯</a></li>
            <li><a href="/index.php/Home/SubPage/Prospect">企业愿景</a></li>
            <li><a href="/index.php/Home/SubPage/Join">加入我们</a></li>
            <li><a href="/index.php/Home/SubPage/Contact">联系我们</a></li>
            <li><a href="/index.php/Home/User/Login">我要登录</a></li>
            <li><a href="/index.php/Home/User/Register">立即注册</a></li>
        </ul>
    </div>
    <a href="javascript:;" class="act">×</a>
</div>
<!--导航-->
<!--banner-->
<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
    <?php
 $bannerInfo = M('mobile_banner')->select(); ?>
    <!-- Indicators -->
    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">
        <?php if(is_array($bannerInfo)): $i = 0; $__LIST__ = $bannerInfo;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><div class="item">
                <img src="<?php echo C('imgurl'); echo ($v["img"]); ?>">
            </div><?php endforeach; endif; else: echo "" ;endif; ?>
    </div>
    <div class="banner">
        <img src="/Public/Home/images/logo.png" alt="logo" class="img-top">
        <a href="javascript:;" class="anniu">
            <img src="/Public/Home/images/three.png">
        </a>
        <div class="wz">
            <p>升级传统<span>新房</span>交易，开启<span>10倍</span>效能卖房</p>
            <p>公司自营项目、合作企业、以及需要资金改造升级的物业</p>
        </div>
        <p class="entrust">
            <input type="text" id="weituoshoujihao" placeholder=" 输入手机号">
            <span id="entrust">立即委托</span>
        </p>
    </div>
</div>
<!--banner-->

<div class="entrust-xq">
    <div class="left">
        <a href="javascript:;" id="lijiweituo" class="ast">立即委托</a>
        <p>
            我们会有客服专员<br>
            联系您，请您耐心等待！
        </p>
    </div>
    <div class="left">
        <a href="/Home/User/UserCenter" class="ast">完善资料并委托</a>
        <p>
            完善资料，帮您分配 <br>
            相应的客服专员，需求明确<br>
            节省您的宝贵时间！<br>
        </p>
        <a href="javascript:;" class="clos">关闭</a>
    </div>
</div>
<script src="/Public/Home/js/jquery-1.7.2.min.js"></script>
<script src="/Public/Home/js/bootstrap.min.js"></script>
<script src="/Public/Home/js/swiper-3.4.0.min.js"></script>
<script type="text/javascript">
    $(".carousel-indicators li").eq(0).addClass("active");
    $(".carousel-inner .item").eq(0).addClass("active");
    $(function(){
        $('#lijiweituo').click(function(){
           var shoujihao =  $('#weituoshoujihao').val();
           console.log(shoujihao);
            if (shoujihao=='') {
                layer.msg('请输入手机号', function(){
                    
                });
                return false;
            }
            var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(17[0-9]{1})|(18[0-9]{1}))+\d{8})$/; 
            if (!myreg.test(shoujihao)) {
                layer.msg('请输入正确的手机号', function(){
                    
                });
                return false;
            }
            $.get('/Home/Other/NiMing',{mobile:shoujihao},function(result){
                if(result == 1)
                {
                    layer.alert('委托成功', {icon: 6});
                }
                 else
                {
                     layer.msg('委托失败', {icon: 5});
                }
            })
        });
        $('#daohangweituo').click(function(){
           var mobile =  $('#daohang_mobile').val();
           console.log(mobile);
            if (mobile=='') {
                layer.msg('请输入手机号', function(){
                    
                });
                return false;
            }
            var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(17[0-9]{1})|(18[0-9]{1}))+\d{8})$/; 
            if (!myreg.test(mobile)) {
                layer.msg('请输入正确的手机号', function(){
                    
                });
                return false;
            }
            $.get('/Home/Other/NiMing',{mobile:mobile},function(result){
                if(result == 1)
                {
                    layer.alert('委托成功', {icon: 6});
                }
                 else
                {
                     layer.msg('委托失败', {icon: 5});
                }
            })
        });
    });
</script>

<div class="top">
    <div class="content">
        <ul>
            <?php if(is_array($business)): $i = 0; $__LIST__ = $business;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><li>
                <img src="<?php echo ($v["business_img"]); ?>">
                <p><?php echo ($v["business_name"]); ?></p>
            </li><?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
    </div>
</div>

<div class="mark-c">
    <img src="/Public/Home/images/zhaobiao.png" class="img-top">
    <div class="biao">
        <div class="left">
            <img src="/Public/Home/images/jian(2).png">
            <div class="l-right">
                <p><?php echo ($ConfInfo["conf_company_telephone"]); ?><span>咨询热线</span></p>
                <p><span>招商流程</span></p>
                <?php echo htmlspecialchars_decode($company['zhaoshang_liucheng']) ?>
            </div>
        </div>
        <div class="right">
            <form action="/index.php/Home/SubPage/Zixun" method="post">
                <input type="hidden" name="caseTitle" id="zixun-caseTitle" value="<?php echo $_GET['title'];?>">
                <p class="top">快速咨询</p>
                <p>
                    <input type="text" name="name" id="zixun-name" placeholder="请输入姓名">
                </p>
                <p>
                    <input type="text" name="mobile" id="zixun-mobile" placeholder="请输入您的联系电话">
                </p>
                <p>
                    <textarea name="content" id="zixun-content" cols="20" rows="5" placeholder="在线填写需求"></textarea>
                </p>
                <p>
                    <input type="button" id="zixun-tijiao" value="立即提交">
                </p>
            </form>
        </div>
    </div>
</div>

<div class="liao">
    <div class="content">
        <img src="/Public/Home/images/liao.png" class="img-top">
        <div class="top">
          <?php echo htmlspecialchars_decode($zhaobiaotupian['liaojieta']) ?>
        </div>
    </div>
</div>

<div class="list">
    <ul>
        <li>
            <img src="/Public/Home/images/img1.png">
            <div>
                <p class="top">
                    <span>团</span>
                    <span>队</span>
                    <span>组</span>
                    <span>建</span>
                </p>
                <p>物业部</p>
                <p>运营部组建</p>
            </div>
        </li>
        <li>
            <img src="/Public/Home/images/img2.png">
            <div>
                <p class="top">
                    <span>交</span>
                    <span>房</span>
                    <span>验</span>
                    <span>收</span>
                </p>
                <p>入场签约</p>
                <p>装修进场</p>
            </div>
        </li>
        <li>
            <img src="/Public/Home/images/img3.png">
            <div>
                <p class="top">
                    <span>后</span>
                    <span>期</span>
                    <span>养</span>
                    <span>市</span>
                </p>
                <p>运营管理</p>
                <p>物业管理</p>
                <p>宣传推广</p>
            </div>
        </li>
        <li>
            <img src="/Public/Home/images/img4.png">
            <div>
                <p class="top">
                    <span>开</span>
                    <span>业</span>
                    <span>促</span>
                    <span>销</span>
                </p>
                <p>开业彩排</p>
                <p>开业营销</p>
                <p>开业形象推广</p>
            </div>
        </li>
        <li>
            <img src="/Public/Home/images/img5.png">
            <div>
                <p class="top">
                    <span>卖</span>
                    <span>场</span>
                    <span>包</span>
                    <span>装</span>
                </p>
                <p>道士系统制作</p>
                <p>内外场商业气氛营造</p>
            </div>
        </li>
        <li>
            <img src="/Public/Home/images/img6.png">
            <div>
                <p class="top">
                    <span>入</span>
                    <span>场</span>
                    <span>布</span>
                    <span>货</span>
                </p>
                <p>商户入场率</p>
                <p>入场布货率</p>
                <p>二装完成率</p>
            </div>
        </li>
    </ul>
</div>

<div class="dui">
    <div class="content">
        <div class="top">服务对象</div>
        <div class="wz">
             <?php echo htmlspecialchars_decode($zhaobiaotupian['fuwuduixiang']) ?>
        </div>
        <div class="top1"></div>
        <ul class="ulst1">
            <li><a href="javascript:;">项目照片</a></li>
        </ul>
        <div class="imglist">
             <?php echo htmlspecialchars_decode($zhaobiaotupian['case_content']); ?>
        </div>
    </div>
</div>

<!--footer-->
<div class="footer">
    <?php  $Conf = M('conf'); $ConfInfo = $Conf->where('id=1')->find(); ?>
<div class="content text-center">
        <p class="top"><?php echo ($ConfInfo["conf_24hours"]); ?> / <?php echo ($ConfInfo["conf_company_telephone"]); ?> </p>
        <p class="top-w"><?php echo ($ConfInfo["conf_company_address"]); ?></p>
        <div class="wei">
            <img src="<?php echo ($ConfInfo["conf_qrcode"]); ?>">
            <div>
                <p><?php echo ($ConfInfo["conf_company_name"]); ?></p>
                <p><?php echo ($ConfInfo["conf_company_records"]); ?></p>
                <p>技术支持：鼎智诚科技</p>
            </div>
        </div>
    </div>
</div>
<!--footer-->

<div class="fixed-bottom">
    <div class="content">
        <ul>
            <li><a href="/">网站首页</a></li>
            <li><a href="#">立即委托</a></li>
            <li><a href="tel:<?php echo ($ConfInfo["conf_company_telephone"]); ?>">合作热线</a></li>
            <li><a href="/index.php/Home/User/join.html">加入我们</a></li>
        </ul>
    </div>
</div>

<div class="fixed-right">
     <?php
 $Userid = cookie('User_id'); if(empty($Userid)){ ?>
    <a href="/index.php/Home/User/Login">登录</a>
    <?php }else{ ?>
    <a href="/index.php/Home/User/UserCenter">中心</a>
    <?php } ?>
    <a href="/index.php/Home/User/Register">注册</a>
</div>

<script src="/Public/Home/js/jquery-1.7.2.min.照片js"></script>
<script src="/Public/Home/js/bootstrap.min.js"></script>
<script src="/Public/Home/js/index.js"></script>
<script type="text/javascript">
    $(function(){
          $('#zixun-tijiao').click(function(){
            var name = $('#zixun-name').val();
            var caseTitle = $('#zixun-caseTitle').val();
            var mobile = $('#zixun-mobile').val();
            var content = $('#zixun-content').val();
            if (name == '') {
                layer.msg('请填写你的姓名', function(){
                    
                });
                return false;
            }
            if (mobile == '') {
                layer.msg('请填写手机号', function(){
                    
                });
                return false;
            }
            var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(17[0-9]{1})|(18[0-9]{1}))+\d{8})$/; 
            if (!myreg.test(mobile)) {
                layer.msg('请输入正确的手机号', function(){
                    
                });
                return false;
            }
            if (content == '') {
                layer.msg('请填写需求', function(){
                    
                });
                return false;
            }
            $.post('/Home/SubPage/Zixun',{name:name,mobile:mobile,content:content,caseTitle:caseTitle},function(res){
                if(res == 1)
                {
                    layer.alert('委托成功', {icon: 6});
                    $('#zixun-name').val('');
                    $('#zixun-mobile').val('');
                    $('#zixun-content').val('');
                }
                if(res == 0)
                {
                     layer.msg('委托失败', {icon: 5});
                }
            });
        });
    })
   
</script>
</body>
</html>