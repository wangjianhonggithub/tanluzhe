<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>瑞博行 -- 首页</title>
    <meta content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" name="viewport" />
    <link rel="stylesheet" href="/Public/Home/css/bootstrap.min.css">
    <link rel="stylesheet" href="/Public/Home/css/swiper.css">
    <link rel="stylesheet" href="/Public/Home/css/index.css">
    <link rel="stylesheet" href="/Public/Home/css/public.css">
    <link rel="stylesheet" href="/Public/layui/css/layui.css">
    <script  src="/Public/layui/layui.all.js"></script>
    <script src="/Public/Home/js/include.js"></script>
</head>

<!--导航-->
<div class="nav">
    <div class="content">
        <p class="top text-center">
            <span>找商铺就选睿博行！</span>
            <span>一键提交需求 即可为你服务</span>
        </p>
        <p class="entrust">
            <input type="text" id="daohang_mobile">
            <span id="daohangweituo">立即委托</span>
        </p>
        <ul>
            <li><a href="/index.php/Home/SubPage/About">关于我们</a></li>
            <li><a href="/index.php/Home/SubPage/Business">业务板块</a></li>
            <li><a href="/index.php/Home/List/CaseList">招商项目</a></li>
            <li><a href="/index.php/Home/List/NewsList">新闻资讯</a></li>
            <li><a href="/index.php/Home/SubPage/Prospect">企业愿景</a></li>
            <li><a href="/index.php/Home/SubPage/Join">加入我们</a></li>
            <li><a href="/index.php/Home/SubPage/Contact">联系我们</a></li>
            <li><a href="/index.php/Home/User/Login">我要登录</a></li>
            <li><a href="/index.php/Home/User/Register">立即注册</a></li>
        </ul>
    </div>
    <a href="javascript:;" class="act">×</a>
</div>
<!--导航-->
<!--banner-->
<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
    <?php
 $bannerInfo = M('mobile_banner')->select(); ?>
    <!-- Indicators -->
    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">
        <?php if(is_array($bannerInfo)): $i = 0; $__LIST__ = $bannerInfo;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><div class="item">
                <img src="<?php echo C('imgurl'); echo ($v["img"]); ?>">
            </div><?php endforeach; endif; else: echo "" ;endif; ?>
    </div>
     <?php
 $Conf = M('conf'); $ConfInfo = $Conf->where('id=1')->find(); ?>
    <div class="banner">
        <div class="logo" style="margin-top: 0.3rem">
           <?php echo htmlspecialchars_decode($ConfInfo['conf_caonima_logo']) ?>
        </div>
        <a href="javascript:;" class="anniu">
            <img src="/Public/Home/images/three.png">
        </a>
        
       
        <div class="wz">
            <?php echo htmlspecialchars_decode($ConfInfo['conf_sb']) ?>
        </div>
        <p class="entrust">
            <input type="text" id="weituoshoujihao" placeholder=" 输入手机号">
            <span id="entrust">立即委托</span>
        </p>
    </div>
</div>
<!--banner-->

<div class="entrust-xq">
    <div class="left">
        <a href="javascript:;" id="lijiweituo" class="ast">立即委托</a>
        <p>
            我们会有客服专员<br>
            联系您，请您耐心等待！
        </p>
    </div>
    <div class="left">
        <a href="/Home/User/UserCenter" class="ast">完善资料并委托</a>
        <p>
            完善资料，帮您分配 <br>
            相应的客服专员，需求明确<br>
            节省您的宝贵时间！<br>
        </p>
        <a href="javascript:;" class="clos">关闭</a>
    </div>
</div>
<script src="/Public/Home/js/jquery-1.7.2.min.js"></script>
<script src="/Public/Home/js/bootstrap.min.js"></script>
<script src="/Public/Home/js/swiper-3.4.0.min.js"></script>
<script type="text/javascript">
    $(".carousel-indicators li").eq(0).addClass("active");
    $(".carousel-inner .item").eq(0).addClass("active");
    $(function(){
        $('#lijiweituo').click(function(){
           var shoujihao =  $('#weituoshoujihao').val();
           console.log(shoujihao);
            if (shoujihao=='') {
                layer.msg('请输入手机号', function(){
                    
                });
                return false;
            }
            var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(17[0-9]{1})|(18[0-9]{1}))+\d{8})$/; 
            if (!myreg.test(shoujihao)) {
                layer.msg('请输入正确的手机号', function(){
                    
                });
                return false;
            }
            $.get('/Home/Other/NiMing',{mobile:shoujihao},function(result){
                if(result == 1)
                {
                    layer.alert('委托成功', {icon: 6});
                }
                 else
                {
                     layer.msg('委托失败', {icon: 5});
                }
            })
        });
        $('#daohangweituo').click(function(){
           var mobile =  $('#daohang_mobile').val();
           console.log(mobile);
            if (mobile=='') {
                layer.msg('请输入手机号', function(){
                    
                });
                return false;
            }
            var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(17[0-9]{1})|(18[0-9]{1}))+\d{8})$/; 
            if (!myreg.test(mobile)) {
                layer.msg('请输入正确的手机号', function(){
                    
                });
                return false;
            }
            $.get('/Home/Other/NiMing',{mobile:mobile},function(result){
                if(result == 1)
                {
                    layer.alert('委托成功', {icon: 6});
                }
                 else
                {
                     layer.msg('委托失败', {icon: 5});
                }
            })
        });
    });
</script>

<div class="title">
    <div class="content">
        <ul>
            <li>
               <a href="/index.php/Home/SubPage/About">
                   <img src="/Public/Home/images/icon(1).png" alt="">
                   <p>关于我们</p>
               </a>
            </li>
            <li>
               <a href="/index.php/Home/SubPage/Business">
                   <img src="/Public/Home/images/icon(4).png" alt="">
                   <p>业务范围</p>
               </a>
            </li>
            <li>
               <a href="/index.php/Home/List/CaseList">
                   <img src="/Public/Home/images/icon(2).png" alt="">
                   <p>招商项目</p>
               </a>
            </li>
            <li>
                <a href="/index.php/Home/SubPage/Contact">
                    <img src="/Public/Home/images/icon(3).png" alt="">
                    <p>联系我们</p>
                </a>
            </li>
        </ul>
    </div>
</div>

<!--精准匹配-->
<div class="project">
    <div class="content">
        <div class="top text-center">
            <p><?php echo ($mobile[0]['english']); ?></p>
            <p><?php echo ($mobile[0]['chinese']); ?></p>
        </div>
        <ul>
            <li>
                <a href="/index.php/Home/User/Zufang">
                    <p>
                        <span>我要出租</span>
                        <span>快速匹配优质租客</span>
                    </p>
                    <img src="/Public/Home/images/zu(2).png">
                </a>
            </li>
            <li>
                <a href="/index.php/Home/User/ZhaoDian">
                    <p>
                        <span>我要找店</span>
                        <span>快速匹配优质店铺</span>
                    </p>
                    <img src="/Public/Home/images/zu(1).png">
                </a>
            </li>
        </ul>
    </div>
</div>
<!--精准匹配-->

<div class="business business-frist">
    <div class="content">
        <div class="big">
            <?php
 $yewubankuai = M('yewu')->limit(3)->order('id asc')->select(); ?>
            <div class="title yewuactive">
                <?php if(is_array($yewubankuai)): $i = 0; $__LIST__ = $yewubankuai;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><a href="javascript:;" class="yewuxuanxiang" data-id='<?php echo ($v["id"]); ?>'><?php echo ($v["yewu_name"]); ?></a><?php endforeach; endif; else: echo "" ;endif; ?>
            </div>
            <div class="wz">
                <div class="nr active" id="yewumiaoshu">
                   <?php echo ($yewubankuai[0]["yewu_miaoshu"]); ?>
                </div>
            </div>
        </div>
    </div>
</div>


<!--招商项目-->
<!-- <div class="project">
    <div class="content">
        <div class="top text-center">
            <p>CHINA MERCHANTS</p>
            <p>招商项目</p>
        </div>
        <ul>
            <?php if(is_array($case)): $i = 0; $__LIST__ = $case;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><li>
                <a href="<?php if($v['type'] == 1){echo '/index.php/Home/ListInfo/CaseInfo?id='.$v['id'].'&title='.$v[case_title];}else{echo '/index.php/Home/SubPage/Invitation?title='.$v[case_title];}?>">
                    <img src="<?php echo ($v["case_img"]); ?>">
                    <p>
                        <span><?php echo ($v["case_title"]); ?></span>
                        <span><?php echo ($v["case_description"]); ?></span>
                    </p>
                </a>
            </li><?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
    </div>
</div> -->
<!--招商项目-->

<!--项目案例-->
<div class="case">
    <div class="content">
        <div class="top">
            <p><?php echo ($mobile[1]['english']); ?></p>
            <p>
                <span><?php echo ($mobile[1]['chinese']); ?></span>
            </p>
            <?php echo htmlspecialchars_decode($company['zhaoshang_content']) ?>
        </div>
        <ul>
            <?php if(is_array($classify)): $i = 0; $__LIST__ = $classify;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$ade): $mod = ($i % 2 );++$i;?><li><a href="/Home/List/CaseList"><?php echo ($ade["case_classify_name"]); ?></a></li><?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
        <div class="more">
            <a href="javascript:;">
                <p>查看更多</p>
                <img src="/Public/Home/images/jian.png">
            </a>
        </div>
    </div>
</div>
<!--项目案例-->

<!--关于瑞博行-->
<!-- <div class="about">
    <div class="content">
        <div class="top text-center">
            <a href="/index.php/Home/SubPage/About">
                <p>ABOUT US</p>
                <p>关于瑞博行</p>
            </a>
        </div>
        <p class="text-center">
            <?php echo htmlspecialchars_decode($company['guanyu_content']) ?>
        </p>
    </div>
</div> -->
<div class="advantage">
    <div class="content">
        <div class="top text-center">
            <a href="/index.php/Home/List/NewsList">
            <p><?php echo ($mobile[2]['english']); ?></p >
            <p><?php echo ($mobile[2]['chinese']); ?></p >
            </a>
        </div>
        <div id="carousel-example-generic2" class="carousel slide" data-ride="carousel">
            <!-- Indicators -->
            <ol class="carousel-indicators">
                <?php foreach($news as $key=>$mobileasd){?>
                <li data-target="#carousel-example-generic2" data-slide-to="<?=$key?>"></li>
                <?php }?>
            </ol>

            <!-- Wrapper for slides -->
            <div class="carousel-inner" role="listbox">
                <?php if(is_array($news)): $i = 0; $__LIST__ = $news;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$mob): $mod = ($i % 2 );++$i;?><div class="item">
                    <a href="/index.php/Home/ListInfo/NewsInfo?id=<?php echo ($mob["id"]); ?>">
                        <img src="<?php echo C('imgurl'); echo ($mob["news_img"]); ?>">
                        <div class="wz-t">
                             <?php echo htmlspecialchars_decode($mob['news_description']) ?>
                        </div>
                    </a>
                </div><?php endforeach; endif; else: echo "" ;endif; ?>
            </div>
        </div>
    </div>
</div>
<!--关于瑞博行-->

<!--平台支持-->
<div class="platform">
    <div class="content">
        <div class="top text-center">
            <p><?php echo ($mobile[3]['english']); ?></p>
            <p><?php echo ($mobile[3]['chinese']); ?></p>
        </div>
        <div class="lunbo">
            <div class="swiper-container">
                <div class="swiper-wrapper">
                    <?php if(is_array($hezuo)): $i = 0; $__LIST__ = $hezuo;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$ave): $mod = ($i % 2 );++$i;?><div class="swiper-slide"><img src="../../../..<?php echo ($ave["logo"]); ?>"></div><?php endforeach; endif; else: echo "" ;endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<!--平台支持-->

<!--平台优势-->
<div class="advantage">
    <div class="content">
        <div class="top text-center">
            <p><?php echo ($mobile[4]['english']); ?></p>
            <p><?php echo ($mobile[4]['chinese']); ?></p>
        </div>
        <div id="carousel-example-generic1" class="carousel slide" data-ride="carousel">
            <!-- Indicators -->

            <ol class="carousel-indicators">
                <?php foreach($Youshi as $key=>$value){?>
                <li data-target="#carousel-example-generic1" data-slide-to="<?=$key?>"></li>
                <?php }?>
            </ol>

            <!-- Wrapper for slides -->
            <div class="carousel-inner" role="listbox">
                <?php if(is_array($Youshi)): $i = 0; $__LIST__ = $Youshi;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vas): $mod = ($i % 2 );++$i;?><div class="item">
                        <img src="<?php echo C('imgurl'); echo ($vas["youshi_img"]); ?>">
                        <div class="wz-t">
                            <?php echo ($vas["youshi_content"]); ?>
                        </div>
                    </div><?php endforeach; endif; else: echo "" ;endif; ?>
            </div>
        </div>
    </div>
</div>

<!--平台优势-->
<!--footer-->
<div class="footer">
    <?php  $Conf = M('conf'); $ConfInfo = $Conf->where('id=1')->find(); ?>
<div class="content text-center">
        <p class="top"><?php echo ($ConfInfo["conf_24hours"]); ?> / <?php echo ($ConfInfo["conf_company_telephone"]); ?> </p>
        <p class="top-w"><?php echo ($ConfInfo["conf_company_address"]); ?></p>
        <div class="wei">
            <img src="<?php echo C('imgurl'); echo ($ConfInfo["conf_qrcode"]); ?>" style="width: 2.16rem">
            <div>
                <p><?php echo ($ConfInfo["conf_company_name"]); ?></p>
                <p><?php echo ($ConfInfo["conf_company_records"]); ?></p>
            </div>
        </div>
    </div>
</div>
<!--footer-->

<div class="fixed-bottom">
    <div class="content">
        <ul>
            <li><a href="/">网站首页</a></li>
            <li><a href="#">立即委托</a></li>
            <li><a href="tel:<?php echo ($ConfInfo["conf_company_telephone"]); ?>">合作热线</a></li>
            <li><a href="/index.php/Home/SubPage/Join">加入我们</a></li>
        </ul>
    </div>
</div>

<div class="fixed-right">
     <?php
 $Userid = cookie('User_id'); if(empty($Userid)){ ?>
    <a href="/index.php/Home/User/Login"> <p>立即</p> <p>登陆</p></a>
    <?php }else{ ?>
    <a href="/index.php/Home/User/UserCenter"><p>个人</p> <p>中心</p></a>
    <?php } ?>
    <a href="/index.php/Home/User/Register"> <p>免费</p> <p>注册</p></a>
</div>
<script src="/Public/Home/js/jquery-1.7.2.min.js"></script>
<script src="/Public/Home/js/bootstrap.min.js"></script>
<script src="/Public/Home/js/swiper-3.4.0.min.js"></script>
<script src="/Public/Home/js/index.js"></script>
<script>
    $(".yewuactive a").eq(0).addClass("active");
    $(function(){
        var mySwiper = new Swiper ('.swiper-container', {
        loop: true,
        nextButton: '.swiper-button-next',
        prevButton: '.swiper-button-prev'
        });
        $("#carousel-example-generic1 ol li").eq(0).addClass("active");
        $("#carousel-example-generic1 .item").eq(0).addClass("active");
        $("#carousel-example-generic2 .item").eq(0).addClass("active");
        $("#carousel-example-generic2 ol li").eq(0).addClass("active");
        $('.yewuxuanxiang').click(function(){
            var id = $(this).attr('data-id');
            $.get('/Home/Index/GetYewu',{id:id},function(res){
                var result=eval("("+res+")");
                console.log(res);
                $('#yewumiaoshu').html(result.yewu_miaoshu);
            });
        });
    });
</script>
</body>
</html>