<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>瑞博行 -- 个人中心</title>
    <meta content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" name="viewport" />
    <link rel="stylesheet" href="/Public/Home/css/bootstrap.min.css">
    <link rel="stylesheet" href="/Public/Home/css/personal.css">
    <link rel="stylesheet" href="/Public/Home/css/personal-nav.css">
    <link rel="stylesheet" href="/Public/layui/css/layui.css">
    <script  src="/Public/layui/layui.all.js"></script>
    <script src="/Public/Home/js/include.js"></script>
</head>

<div class="personal">
    <div class="content">
        <div class="nav">
    <p class="top">
        <img src="/Public/Home/images/login-logo.png">
        <span>
            个人中心
            <a href="/index.php/Home/User/Loginout">退出</a>
        </span>
    </p>
    <ul>
        <li>
            <a href="/index.php/Home/User/UserCenter">完善资料</a>
        </li>
        <li>
            <a href="/index.php/Home/User/UpdatePasswd">修改密码</a>
        </li>
        <li>
            <a href="/index.php/Home/User/UpdateTelephone">修改手机号</a>
        </li>
        <li>
            <a href="/index.php/Home/User/Single">我的反馈单</a>
        </li>
    </ul>
</div>
<p class="title text-center">
    <span>请选择您需要的业务完善您的资料</span>
    <span>直接跳转到下一步</span>
</p>

<div class="fixed-bottom">
    <div class="content">
        <ul>
            <li><a href="/">网站首页</a></li>
            <li><a href="/" style="color: #0687fe;">立即委托</a></li>
            <li><a href="tel:18910217777">合作热线</a></li>
            <li><a href="/index.php/Home/SubPage/Join">加入我们</a></li>
            
        </ul>
    </div>
</div>

<div class="fixed-right">
     <?php
 $Userid = cookie('User_id'); if(empty($Userid)){ ?>
    <a href="/index.php/Home/User/Login"> <p>立即</p> <p>登陆</p></a>
    <?php }else{ ?>
    <a href="/index.php/Home/User/UserCenter"><p>个人</p> <p>中心</p></a>
    <?php } ?>
    <a href="/index.php/Home/User/Register"> <p>免费</p> <p>注册</p></a>
</div>
        <ul class="ulst">
            <li><a href="/index.php/Home/User/Zufang"><img src="/Public/Home/images/zu.png" alt=""></a></li>
            <li><a href="/index.php/Home/User/ZhaoDian"><img src="/Public/Home/images/zhao.png" alt=""></a></li>
        </ul>
    </div>
</div>

<script src="/Public/Home/js/jquery-1.7.2.min.js"></script>
<script src="/Public/Home/js/bootstrap.min.js"></script>
<script src="/Public/Home/js/index.js"></script>
</body>
</html>