<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>瑞博行 -- 加入我们</title>
    <meta content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" name="viewport" />
    <link rel="stylesheet" href="/Public/Home/css/bootstrap.min.css">
    <link rel="stylesheet" href="/Public/Home/css/join.css">
    <link rel="stylesheet" href="/Public/Home/css/public.css">
    <link rel="stylesheet" href="/Public/layui/css/layui.css">
    <script  src="/Public/layui/layui.all.js"></script>
    <script src="/Public/Home/js/include.js"></script>
</head>
<body>
<!--导航-->
<div class="nav">
    <div class="content">
        <p class="top text-center">
            <span>找商铺就选睿博行！</span>
            <span>一键提交需求 即可为你服务</span>
        </p>
        <p class="entrust">
            <input type="text" id="daohang_mobile">
            <span id="daohangweituo">立即委托</span>
        </p>
        <ul>
            <li><a href="/index.php/Home/SubPage/About">关于我们</a></li>
            <li><a href="/index.php/Home/SubPage/Business">业务板块</a></li>
            <li><a href="/index.php/Home/List/CaseList">招商项目</a></li>
            <li><a href="/index.php/Home/List/NewsList">新闻资讯</a></li>
            <li><a href="/index.php/Home/SubPage/Prospect">企业愿景</a></li>
            <li><a href="/index.php/Home/SubPage/Join">加入我们</a></li>
            <li><a href="/index.php/Home/SubPage/Contact">联系我们</a></li>
            <li><a href="/index.php/Home/User/Login">我要登录</a></li>
            <li><a href="/index.php/Home/User/Register">立即注册</a></li>
        </ul>
    </div>
    <a href="javascript:;" class="act">×</a>
</div>
<!--导航-->
<!--banner-->
<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
    <?php
 $bannerInfo = M('mobile_banner')->select(); ?>
    <!-- Indicators -->
    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">
        <?php if(is_array($bannerInfo)): $i = 0; $__LIST__ = $bannerInfo;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><div class="item">
                <img src="<?php echo C('imgurl'); echo ($v["img"]); ?>">
            </div><?php endforeach; endif; else: echo "" ;endif; ?>
    </div>
    <div class="banner">
        <img src="/Public/Home/images/logo.png" alt="logo" class="img-top">
        <a href="javascript:;" class="anniu">
            <img src="/Public/Home/images/three.png">
        </a>
         <?php
 $Conf = M('conf'); $ConfInfo = $Conf->where('id=1')->find(); ?>
       
        <div class="wz">
            <?php echo htmlspecialchars_decode($ConfInfo['conf_sb']) ?>
        </div>
        <p class="entrust">
            <input type="text" id="weituoshoujihao" placeholder=" 输入手机号">
            <span id="entrust">立即委托</span>
        </p>
    </div>
</div>
<!--banner-->

<div class="entrust-xq">
    <div class="left">
        <a href="javascript:;" id="lijiweituo" class="ast">立即委托</a>
        <p>
            我们会有客服专员<br>
            联系您，请您耐心等待！
        </p>
    </div>
    <div class="left">
        <a href="/Home/User/UserCenter" class="ast">完善资料并委托</a>
        <p>
            完善资料，帮您分配 <br>
            相应的客服专员，需求明确<br>
            节省您的宝贵时间！<br>
        </p>
        <a href="javascript:;" class="clos">关闭</a>
    </div>
</div>
<script src="/Public/Home/js/jquery-1.7.2.min.js"></script>
<script src="/Public/Home/js/bootstrap.min.js"></script>
<script src="/Public/Home/js/swiper-3.4.0.min.js"></script>
<script type="text/javascript">
    $(".carousel-indicators li").eq(0).addClass("active");
    $(".carousel-inner .item").eq(0).addClass("active");
    $(function(){
        $('#lijiweituo').click(function(){
           var shoujihao =  $('#weituoshoujihao').val();
           console.log(shoujihao);
            if (shoujihao=='') {
                layer.msg('请输入手机号', function(){
                    
                });
                return false;
            }
            var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(17[0-9]{1})|(18[0-9]{1}))+\d{8})$/; 
            if (!myreg.test(shoujihao)) {
                layer.msg('请输入正确的手机号', function(){
                    
                });
                return false;
            }
            $.get('/Home/Other/NiMing',{mobile:shoujihao},function(result){
                if(result == 1)
                {
                    layer.alert('委托成功', {icon: 6});
                }
                 else
                {
                     layer.msg('委托失败', {icon: 5});
                }
            })
        });
        $('#daohangweituo').click(function(){
           var mobile =  $('#daohang_mobile').val();
           console.log(mobile);
            if (mobile=='') {
                layer.msg('请输入手机号', function(){
                    
                });
                return false;
            }
            var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(17[0-9]{1})|(18[0-9]{1}))+\d{8})$/; 
            if (!myreg.test(mobile)) {
                layer.msg('请输入正确的手机号', function(){
                    
                });
                return false;
            }
            $.get('/Home/Other/NiMing',{mobile:mobile},function(result){
                if(result == 1)
                {
                    layer.alert('委托成功', {icon: 6});
                }
                 else
                {
                     layer.msg('委托失败', {icon: 5});
                }
            })
        });
    });
</script>

<div class="join-top">
    <div class="content">
        <p class="top">
            <?php $mobile = M('mobile_conf')->select(); ?>
            <span><?php echo ($mobile[11]['english']); ?></span>
            <span><?php echo ($mobile[11]['chinese']); ?></span>
        </p>
    </div>
</div>

<div class="join">
    <div class="content">
        <div id="carousel-example-generic1" class="carousel slide s-banner" data-ride="carousel">
            <!-- Indicators -->
            <ol class="carousel-indicators">
                <?php foreach($Join as $key=>$value){ ?>
                <li data-target="#carousel-example-generic1" data-slide-to="<?=$key?>" class="yuan"></li>
                <?php }?>
            </ol>
            <div class="carousel-inner" role="listbox">
                <?php if(is_array($Join)): $i = 0; $__LIST__ = $Join;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$value): $mod = ($i % 2 );++$i;?><div class="item">
                    <p class="bt">应聘职位</p>
                    <p class="zw">
                        <span><?php echo ($value["job_name"]); ?></span>
                    </p>
                    <p class="xq">
                        <?php echo htmlspecialchars_decode($value['job_demand']) ?>
                    </p>
                    <p class="anniu-btn">
                        <a href=""><?php echo date('Y-m-d',$value['create_time']) ?></a>
                        <a href="">我要应聘</a>
                    </p>
                </div><?php endforeach; endif; else: echo "" ;endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="contact">
    <div class="content">
        <ul>
            <li>
                <img src="/Public/Home/images/jion(1).png">
                    <span>
                        招聘电话 <br>
                         <?php echo ($conf["conf_join_telephone"]); ?>
                    </span>
            </li>
            <li>
                <img src="/Public/Home/images/jion(2).png">
                    <span>
                        简历投送邮箱<br>
                        <?php echo ($conf["conf_jion_email"]); ?>
                    </span>
            </li>
            <li>
                <img src="/Public/Home/images/jion(3).png">
                    <span>
                        应聘地址<br>
                        <?php echo ($conf["conf_company_address"]); ?>
                    </span>
            </li>
        </ul>
    </div>
</div>

<div class="recruitment">
    <div class="content">
        <img src="/Public/Home/images/recruitment.png" class="img-top">
        <div class="dan">
            <p class="title">快速编写微简历</p>
            <form action="/index.php/Home/SubPage/DoJoin" method="post" enctype="multipart/form-data">
                <ul> 
                    <li class="list">
                        <label class="f-one"><span class="title-t">姓名 </span> <input type="text" name="resume_name" id="resume_name"></label>
                        <label class="f-two"><span class="title-t">出生年月 </span> <input type="text" id="resume_birth" name="resume_birth"></label>
                    </li>
                    <li style="clear: both">
                        <span class="title-t">性别 </span>
                        <label><input type="radio" value="1" checked name="resume_gender"> <span>男</span></label>
                        <label><input type="radio" value="2" name="resume_gender"> <span>女</span></label>
                    </li>
                    <li>
                        <label><span>联系电话 </span> <input type="text" maxlength="11" id="resume_telephone" name="resume_telephone"></label>
                    </li>
                    <li class="list">
                        <label class="f-one"><span class="title-t">应聘职务 </span> <input type="text" id="resume_required_position" name="resume_required_position"></label>
                        <label class="f-two"><span class="title-t">最高学历 </span> <input type="text" id="resume_education" name="resume_education"></label>
                    </li>
                    <li>
                        <label>
                            <span>工作经历以及个人介绍 </span>
                            <textarea rows="5" name="resume_undergo" id="resume_undergo" placeholder="在线填写您的工作经历个人介绍，提升您的就职机会！"></textarea>
                        </label>
                    </li>
                    <li>
                        <input type="button" id="join-tijiao" value="立即提交">
                    </li>
                </ul>
            </form>
        </div>
    </div>
</div>

<!--footer-->
<div class="footer">
    <?php  $Conf = M('conf'); $ConfInfo = $Conf->where('id=1')->find(); ?>
<div class="content text-center">
        <p class="top"><?php echo ($ConfInfo["conf_24hours"]); ?> / <?php echo ($ConfInfo["conf_company_telephone"]); ?> </p>
        <p class="top-w"><?php echo ($ConfInfo["conf_company_address"]); ?></p>
        <div class="wei">
            <img src="<?php echo ($ConfInfo["conf_qrcode"]); ?>">
            <div>
                <p><?php echo ($ConfInfo["conf_company_name"]); ?></p>
                <p><?php echo ($ConfInfo["conf_company_records"]); ?></p>
                <p>技术支持：鼎智诚科技</p>
            </div>
        </div>
    </div>
</div>
<!--footer-->

<div class="fixed-bottom">
    <div class="content">
        <ul>
            <li><a href="/">网站首页</a></li>
            <li><a href="#">立即委托</a></li>
            <li><a href="tel:<?php echo ($ConfInfo["conf_company_telephone"]); ?>">合作热线</a></li>
            <li><a href="/index.php/Home/SubPage/Join">加入我们</a></li>
        </ul>
    </div>
</div>

<div class="fixed-right">
     <?php
 $Userid = cookie('User_id'); if(empty($Userid)){ ?>
    <a href="/index.php/Home/User/Login"> <p>立即</p> <p>登陆</p></a>
    <?php }else{ ?>
    <a href="/index.php/Home/User/UserCenter"><p>个人</p> <p>中心</p></a>
    <?php } ?>
    <a href="/index.php/Home/User/Register"> <p>免费</p> <p>注册</p></a>
</div>
<script src="/Public/Home/js/jquery-1.7.2.min.js"></script>
<script src="/Public/Home/js/bootstrap.min.js"></script>
<script src="/Public/Home/js/index.js"></script>
<script type="text/javascript">
     $("#carousel-example-generic1 .item").eq(0).addClass("active");
     $("#carousel-example-generic1 .yuan").eq(0).addClass("active");
     $(function(){
        $('#join-tijiao').click(function(){
            var resume_name = $('#resume_name').val();
            var resume_birth = $('#resume_birth').val();
            var resume_gender = $('input[name="resume_gender"]:checked').val();
            var resume_telephone = $('#resume_telephone').val();
            var resume_required_position = $('#resume_required_position').val();
            var resume_education = $('#resume_education').val();
            var resume_undergo = $('#resume_undergo').val();
            if (resume_name == '') {
                layer.msg('请输入姓名', function(){
                    
                });
                return false;
            }
            if (resume_birth == '') {
                layer.msg('请输入出生年月日', function(){
                    
                });
                return false;
            }
            if (resume_telephone == '') {
                layer.msg('请输入手机号', function(){
                    
                });
                return false;
            }
            var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(17[0-9]{1})|(18[0-9]{1}))+\d{8})$/; 
            if (!myreg.test(resume_telephone)) {
                layer.msg('请输入正确的手机号', function(){
                    
                });
                return false;
            }
            if (resume_required_position == '') {
                layer.msg('请输入想要应聘的职务', function(){
                    
                });
                return false;
            }
            if (resume_education == '') {
                layer.msg('请输入您的最高学历', function(){
                    
                });
                return false;
            }
            if (resume_undergo == '') {
                layer.msg('请输入您的工作经历以及个人介绍', function(){
                    
                });
                return false;
            }
            $.post('/Home/SubPage/DoJoin',{resume_name:resume_name,resume_birth:resume_birth,resume_gender:resume_gender,resume_telephone:resume_telephone,resume_required_position:resume_required_position,resume_education:resume_education,resume_undergo:resume_undergo},function(res){
                var msg=eval("("+res+")");
                 if (msg.status == 1) {
                    layer.alert(msg.info, {icon: 6});
                    $('#resume_name').val('');
                    $('#resume_birth').val('');
                    $('#resume_telephone').val('');
                    $('#resume_required_position').val('');
                    $('#resume_education').val('');
                    $('#resume_undergo').val('');
                 }
                 if(msg.status == 0)
                 {
                     layer.alert(msg.info, {icon: 5});
                 }

                 if(msg.status == 2)
                 {
                    layer.msg(msg.info, function(){
                    });
                    return false;
                 }

            })
        });
     });
</script>
</body>
</html>