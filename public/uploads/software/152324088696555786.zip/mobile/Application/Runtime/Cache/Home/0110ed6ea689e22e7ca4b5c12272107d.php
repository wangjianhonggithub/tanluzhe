<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>瑞博行 -- 忘记密码</title>
    <meta content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" name="viewport" />
    <link rel="stylesheet" href="/Public/Home/css/bootstrap.min.css">
    <link rel="stylesheet" href="/Public/Home/css/login.css">
    <link rel="stylesheet" href="/Public/layui/css/layui.css">
    <script  src="/Public/layui/layui.all.js"></script>
    <script src="/Public/Home/js/include.js"></script>
</head>
<body>

<div class="login">
    <div class="content">
        <img src="/Public/Home/images/login-logo.png" alt="logo" class="img-top">
        <p class="zhao">找回密码</p>
        <form>
            <label class="shou">
                <img src="/Public/Home/images/ren.png">
                <input type="text" placeholder="请输入手机号" name="mobile" id="mobile" maxlength="11">
            </label>
            <p class="zhu">
                请在输入框中输入要重置密码的账户手机号，
                我们会在24小时内为您重置密码
            </p>
            <input type="button" id="zhaohui-tijiao" value="立即提交" class="inp2">
        </form>
    </div>
</div>



<script src="/Public/Home/js/jquery-1.7.2.min.js"></script>
<script src="/Public/Home/js/bootstrap.min.js"></script>
<script src="/Public/Home/js/index.js"></script>
<script type="text/javascript">
    $(function(){
        $('#zhaohui-tijiao').click(function(){
            var mobile = $('#mobile').val();
            $.post('/Home/User/DoForGet',{mobile:mobile},function(res){
               var msg=eval("("+res+")");
               if (msg.status==2) {
                   layer.msg(msg.info, function(){
                   });
                   return false;
               }
               if (msg.status==1) {
                   layer.alert(msg.info, {icon: 6});
                   window.location.href='/';
               }
               if (msg.status == 0) {
                   layer.alert(msg.info, {icon: 5});
               }
            }); 
        });
    });
</script>
</body>
</html>