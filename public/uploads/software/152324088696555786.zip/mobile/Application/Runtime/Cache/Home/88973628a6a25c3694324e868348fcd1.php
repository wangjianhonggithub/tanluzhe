<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>瑞博行 -- 登录</title>
    <meta content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" name="viewport" />
    <link rel="stylesheet" href="/Public/Home/css/bootstrap.min.css">
    <link rel="stylesheet" href="/Public/Home/css/login.css">
    <link rel="stylesheet" href="/Public/layui/css/layui.css">
    <script  src="/Public/layui/layui.all.js"></script>
    <script src="/Public/Home/js/include.js"></script>
</head>
<body>

<div class="login">
    <div class="content">
        <img src="/Public/Home/images/login-logo.png" alt="logo" class="img-top">
        <img src="/Public/Home/images/denglu.png" class="dl">
        <form >
            <label>
                <img src="/Public/Home/images/ren.png">
                <input type="text" name="username" id="username" placeholder="请输入手机号" maxlength="11">
            </label>
            <label>
                <img src="/Public/Home/images/suo.png">
                <input type="password" name="password" id="password" placeholder="请输入登录密码">
                <a href="/index.php/Home/User/ForGet">忘记密码</a>
            </label>
            <p>还没有账号？去<a href="/index.php/Home/User/Register"> 注册</a></p>
            <input type="button" id="login" value="立即登录" class="inp">
        </form>
    </div>
</div>



<script src="/Public/Home/js/jquery-1.7.2.min.js"></script>
<script src="/Public/Home/js/bootstrap.min.js"></script>
<script src="/Public/Home/js/index.js"></script>
<script type="text/javascript">
    $(function(){
        $('#login').click(function(){
            var username = $('#username').val();
            var password = $('#password').val();
            $.post('/Home/User/DoLogin',{username:username,password:password},function(result){
                 var msg=eval("("+result+")");
                 if (msg.status == 1) {
                     layer.alert(msg.info, {icon: 6});
                     window.location.href='/Home/User/UserCenter';
                 }
                 if(msg.status == 0)
                 {
                     layer.alert(msg.info, {icon: 5});
                 }

                 if(msg.status == 2)
                 {
                    layer.msg(msg.info, function(){
                    });
                    return false;
                 }
            });
        });
    });
</script>
</body>
</html>