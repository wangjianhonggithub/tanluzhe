<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>瑞博行 -- 联系我们</title>
    <meta content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" name="viewport" />
    <link rel="stylesheet" href="/Public/Home/css/bootstrap.min.css">
    <link rel="stylesheet" href="/Public/Home/css/contact.css">
    <script src="/Public/Home/js/include.js"></script>
</head>
<body>

<!--导航-->
<nav class="navbar navbar-default">
    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="/"><img  src="/Public/Home/images/logo.png" alt="logo"></a>
        </div>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="/">首页</a></li>
                <li><a href="/Home/SubPage/About">关于瑞博行</a></li>
                <li><a href="/Home/SubPage/Business">业务板块</a></li>
                <li>
                    <a href="/Home/SubPage/Article">
                        招商项目
                    </a>
                    <div class="fixed-nav">
                        <img  src="/Public/Home/images/1.jpg" alt="">
                        <p>
                            <span>真情像草原广阔，层层风雨不能阻隔，一剪寒梅傲立雪招商项目招商项目招商项目招商项目招商项目招商项目招商项目</span>
                            <a href="invitation.html" class="ast">我要招标</a>
                        </p>
                    </div>
                </li>
                <li><a href="/Home/SubPage/Prospect">企业愿景</a></li>
                <li><a href="/Home/SubPage/Join">加入我们</a></li>
            </ul>
        </div><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>
<!--导航-->

<div class="entrust">
    <div class="left">
        <a href="" class="ast">立即委托</a>
        <p>
            我们会有客服专员<br>
            联系您，请您耐心等待！
        </p>
    </div>
    <div class="left">
        <a href="" class="ast">完善资料并委托</a>
        <p>
            完善资料，帮您分配 <br>
            相应的客服专员，需求明确<br>
            节省您的宝贵时间！<br>
        </p>
        <a href="javascript:;" class="clos">关闭</a>
    </div>
</div>


<!--banner-->
<div id="carousel-example-generic" class="carousel slide banner" data-ride="carousel">
    <div class="carousel-inner" role="listbox">
        <div class="item active">
            <img src="/Public/Home/images/banner.jpg">
        </div>
        <div class="item">
            <img src="/Public/Home/images/banner.jpg">
        </div>
        <div class="item">
            <img src="/Public/Home/images/banner.jpg">
        </div>
        <div class="item">
            <img src="/Public/Home/images/banner.jpg">
        </div>
    </div>
    <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
    <div class="banner-fixed">
        <p class="top">找商铺就找瑞博行!</p>
        <p class="title">一键提交需求 即可为你服务</p>
        <p>
            <input type="text" placeholder=" 输入手机号">
            <button id="entrust">立即委托</button>
        </p>
    </div>
</div>
<!--banner-->

<div class="w-top">
    <div class="content">
        <ul>
            <li class="active-t"><a href="structure.html">组织结构</a></li>
            <li><a href="contact.html">联系我们</a></li>
        </ul>
    </div>
</div>

<div class="new-b">
    <div class="content">
        <p></p>
        <p>联系我们</p>
    </div>
</div>

<div class="contact">
    <div class="content">
        <div class="left">
            <img src="/Public/Home/images/xx.png" class="img-top">
            <div class="js">
                <img src="/Public/Home/images/shouji.png" class="shou">
                <div class="big">
                    <p>地址：<?php echo ($ConfInfo["conf_company_address"]); ?></p>
                    <p>电话：<?php echo ($ConfInfo["conf_company_telephone"]); ?></p>
                    <p>邮箱：<?php echo ($ConfInfo["conf_company_email"]); ?></p>
                    <img src="<?php echo ($ConfInfo["conf_qrcode"]); ?>">
                    <p class="bot">微信公众号</p>
                </div>
            </div>
        </div>
        <div class="right">
            <p>
                <img src="/Public/Home/images/map.png">
            </p>
            <img src="/Public/Home/images/name.png" class="name">
        </div>
    </div>
</div>

<div class="feedback">
    <div class="content">
        <p class="top">
            <span class="tt"></span>
            需求反馈
            <span class="jz">反馈您的需求，我们会以最快的速度联系您</span>
        </p>
        <form>
            <label>
                <span class="spn"><input type="text" placeholder="请输入姓名"><span>选填</span></span>
                <span class="spn"><input type="text" placeholder="请输入手机号"></span>
            </label>
            <label>
                <textarea cols="30" rows="5" placeholder="请填写您的需求，我们会在最快的时间给您反馈"></textarea>
            </label>
            <input type="submit" value="立即提交" class="sub">
        </form>
    </div>
</div>



<!--搜索案例-->
<div class="seek">
    <div class="content">
        <p class="top">快捷搜索</p>
        <p class="suo">
            <input type="text" placeholder=" 输入关键词">
            <button>立即搜索</button>
        </p>
        <p class="wz">
            找到跟您想似的案例，帮助您更好的了解我们
        </p>
        <div class="fixed-f">
            <p>专业管理团队</p>
        </div>
    </div>
</div>
<!--搜索案例-->

<!--footer-->
<div class="footer">
    <div class="content">
        <div class="left">
            <ul>
                <li>
                    <p class="title">开发产品</p>
                    <p>门面房托管</p>
                    <p>社区商业</p>
                    <p>商场·超市·国企房源</p>
                </li>
                <li>
                    <p class="title">招商品牌</p>
                    <p>招商资源</p>
                    <p>联系人</p>
                    <p>品牌类别</p>
                    <p>前景</p>
                </li>
                <li>
                    <p class="title">招商方式</p>
                    <p>渠道</p>
                    <p>电话</p>
                    <p>网络</p>
                    <p>招标</p>
                </li>
            </ul>
            <div class="fixed-f">
                <p>专业高级顾问</p>
            </div>
        </div>
        <?php  $Conf = M('conf'); $ConfInfo = $Conf->where('id=1')->find(); ?>
        <div class="right">
            <span class="r-left">
                <span>CONTACT 联系我们</span>
                <span><?php echo ($ConfInfo["conf_company_name"]); ?></span>
                <span>电话：<?php echo ($ConfInfo["conf_company_telephone"]); ?> </span>
                <span>邮箱：<?php echo ($ConfInfo["conf_company_email"]); ?></span>
                <span>备案号：<?php echo ($ConfInfo["conf_company_records"]); ?></span>
            </span>
            <img  src="<?php echo ($ConfInfo["conf_qrcode"]); ?>">
        </div>
    </div>
</div>
<!--footer-->

<div class="fixed-right">
    <a href="javascript:;">
        <span>联系</span>
        <span>电话</span>
        <p class="fu"><img  src="/Public/Home/images/dian.png" alt=""> <span><?php echo ($ConfInfo["conf_company_telephone"]); ?></span></p>
    </a>
    <?php
 $Userid = cookie('User_id'); if(empty($Userid)){ ?>
    <a href="/Home/User/Login">
        <span>立即</span>
        <span>登录</span>
    </a>
    <?php }else{ ?>
    <a href="/Home/User/UserCenter">
        <span>个人</span>
        <span>中心</span>
    </a>
    <?php } ?>
    <a href="/Home/User/Register">
        <span>免费</span>
        <span>注册</span>
    </a>
    <a href="">
        <span>需求</span>
        <span>反馈</span>
    </a>
</div>

<script src="/Public/Home/js/jquery-1.7.2.min.js"></script>
<script src="/Public/Home/js/bootstrap.min.js"></script>
<script src="/Public/Home/js/index.js"></script>
</body>
</html>