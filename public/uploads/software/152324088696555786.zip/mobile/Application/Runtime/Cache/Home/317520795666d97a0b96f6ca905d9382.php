<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>瑞博行 -- 修改密码</title>
    <meta content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" name="viewport" />
    <link rel="stylesheet" href="/Public/Home/css/bootstrap.min.css">
    <link rel="stylesheet" href="/Public/Home/css/personal-single.css">
    <link rel="stylesheet" href="/Public/Home/css/personal-nav.css">
    <link rel="stylesheet" href="/Public/layui/css/layui.css">
    <script  src="/Public/layui/layui.all.js"></script>
    <script src="/Public/Home/js/include.js"></script>
</head>
<body>

<div class="personal">
    <div class="content">
        <div class="nav">
    <p class="top">
        <img src="/Public/Home/images/login-logo.png">
        <span>
            个人中心
            <a href="/index.php/Home/User/Loginout">退出</a>
        </span>
    </p>
    <ul>
        <li>
            <a href="/index.php/Home/User/UserCenter">完善资料</a>
        </li>
        <li>
            <a href="/index.php/Home/User/UpdatePasswd">修改密码</a>
        </li>
        <li>
            <a href="/index.php/Home/User/UpdateTelephone">修改手机号</a>
        </li>
        <li>
            <a href="/index.php/Home/User/Single">我的反馈单</a>
        </li>
    </ul>
</div>
<p class="title text-center">
    <span>请选择您需要的业务完善您的资料</span>
    <span>直接跳转到下一步</span>
</p>

<div class="fixed-bottom">
    <div class="content">
        <ul>
            <li><a href="/">网站首页</a></li>
            <li><a href="/" style="color: #0687fe;">立即委托</a></li>
            <li><a href="tel:18910217777">合作热线</a></li>
            <li><a href="/index.php/Home/SubPage/Join">加入我们</a></li>
            
        </ul>
    </div>
</div>

<div class="fixed-right">
     <?php
 $Userid = cookie('User_id'); if(empty($Userid)){ ?>
    <a href="/index.php/Home/User/Login"> <p>立即</p> <p>登陆</p></a>
    <?php }else{ ?>
    <a href="/index.php/Home/User/UserCenter"><p>个人</p> <p>中心</p></a>
    <?php } ?>
    <a href="/index.php/Home/User/Register"> <p>免费</p> <p>注册</p></a>
</div>
        <div class="personal-right">
            <p class="top"><span>我的反馈单</span></p>
            <ul>
                <?php if(is_array($weituo)): $i = 0; $__LIST__ = $weituo;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><li>
                    <p>委托手机号：<?php echo ($v["mobile"]); ?></p>
                    <p>委托状态：<?php echo date("Y-m-d",$v['create_time']) ?></p>
                    <p>状态：<?php if($v['status'] == 0){echo "跟进中";}else{echo "已完成";} ?></p>
                    <?php
 if($v['status'] == 1){ ?>
                        <p>
                            <a href="/index.php/Home/User/SingleInfo?id=<?php echo ($v["id"]); ?>">详情</a>
                        </p>
                        <?php
 } ?>
                </li><?php endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </div>
    </div>
</div>




<script src="/Public/Home/js/jquery-1.7.2.min.js"></script>
<script src="/Public/Home/js/bootstrap.min.js"></script>
<script src="/Public/Home/js/index.js"></script>
</body>
</html>