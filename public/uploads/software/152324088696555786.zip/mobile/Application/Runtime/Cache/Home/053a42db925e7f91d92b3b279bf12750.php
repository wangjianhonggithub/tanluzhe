<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>瑞博行 -- 注册</title>
    <meta content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" name="viewport" />
    <link rel="stylesheet" href="/Public/Home/css/bootstrap.min.css">
    <link rel="stylesheet" href="/Public/Home/css/login.css">
    <link rel="stylesheet" href="/Public/layui/css/layui.css">
    <script  src="/Public/layui/layui.all.js"></script>
    <script src="/Public/Home/js/include.js"></script>
</head>
<body>

<div class="login">
    <div class="content">
        <img src="/Public/Home/images/login-logo.png" alt="logo" class="img-top">
        <img src="/Public/Home/images/zhuce.png" class="dl">
        <form action="/index.php/Home/User/DoRegister" method="post">
            <label>
                <img src="/Public/Home/images/ren.png">
                <input type="text" placeholder="请输入手机号" id="username" name="username" maxlength="11">
            </label>
            <label>
                <img src="/Public/Home/images/suo.png">
                <input type="password" name="password" id="password" placeholder="请输入登录密码">
            </label>
            <p>已有账号？去<a href="/index.php/Home/User/Login"> 登录</a></p>
            <input type="button" id="zhuce-tijiao" value="立即注册" class="inp1">
        </form>
    </div>
</div>



<script src="/Public/Home/js/jquery-1.7.2.min.js"></script>
<script src="/Public/Home/js/bootstrap.min.js"></script>
<script src="/Public/Home/js/index.js"></script>
<script type="text/javascript">
    $(function(){
        $('#zhuce-tijiao').click(function(){
            var username = $('#username').val();
            var password = $('#password').val();
            $.post('/Home/User/DoRegister',{username:username,password:password},function(res){
               var msg=eval("("+res+")");
               if (msg.status==2) {
                   layer.msg(msg.info, function(){
                   });
                   return false;
               }
               if (msg.status==1) {
                   layer.alert(msg.info, {icon: 6});
                   window.location.href='/Home/User/UserCenter';
               }
               if (msg.status == 0) {
                   layer.alert(msg.info, {icon: 5});
               }
            }); 
        });
    });
</script>
</body>
</html>