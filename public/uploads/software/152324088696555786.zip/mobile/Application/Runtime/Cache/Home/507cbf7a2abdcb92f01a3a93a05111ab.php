<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>瑞博行 -- 列表</title>
    <meta content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" name="viewport" />
    <link rel="stylesheet" href="/Public/Home/css/bootstrap.min.css">
    <link rel="stylesheet" href="/Public/Home/css/case-list.css">
    <link rel="stylesheet" href="/Public/Home/css/public.css">
    <link rel="stylesheet" href="/Public/layui/css/layui.css">
    <script  src="/Public/layui/layui.all.js"></script>
    <script src="/Public/Home/js/include.js"></script>
</head>

<!--导航-->
<div class="nav">
    <div class="content">
        <p class="top text-center">
            <span>找商铺就选睿博行！</span>
            <span>一键提交需求 即可为你服务</span>
        </p>
        <p class="entrust">
            <input type="text" id="daohang_mobile">
            <span id="daohangweituo">立即委托</span>
        </p>
        <ul>
            <li><a href="/index.php/Home/SubPage/About">关于我们</a></li>
            <li><a href="/index.php/Home/SubPage/Business">业务板块</a></li>
            <li><a href="/index.php/Home/List/CaseList">招商项目</a></li>
            <li><a href="/index.php/Home/List/NewsList">新闻资讯</a></li>
            <li><a href="/index.php/Home/SubPage/Prospect">企业愿景</a></li>
            <li><a href="/index.php/Home/SubPage/Join">加入我们</a></li>
            <li><a href="/index.php/Home/SubPage/Contact">联系我们</a></li>
            <li><a href="/index.php/Home/User/Login">我要登录</a></li>
            <li><a href="/index.php/Home/User/Register">立即注册</a></li>
        </ul>
    </div>
    <a href="javascript:;" class="act">×</a>
</div>
<!--导航-->
<!--banner-->
<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
    <?php
 $bannerInfo = M('mobile_banner')->select(); ?>
    <!-- Indicators -->
    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">
        <?php if(is_array($bannerInfo)): $i = 0; $__LIST__ = $bannerInfo;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><div class="item">
                <img src="<?php echo C('imgurl'); echo ($v["img"]); ?>">
            </div><?php endforeach; endif; else: echo "" ;endif; ?>
    </div>
     <?php
 $Conf = M('conf'); $ConfInfo = $Conf->where('id=1')->find(); ?>
    <div class="banner">
        <div class="logo" style="margin-top: 0.3rem">
           <?php echo htmlspecialchars_decode($ConfInfo['conf_caonima_logo']) ?>
        </div>
        <a href="javascript:;" class="anniu">
            <img src="/Public/Home/images/three.png">
        </a>
        
       
        <div class="wz">
            <?php echo htmlspecialchars_decode($ConfInfo['conf_sb']) ?>
        </div>
        <p class="entrust">
            <input type="text" id="weituoshoujihao" placeholder=" 输入手机号">
            <span id="entrust">立即委托</span>
        </p>
    </div>
</div>
<!--banner-->

<div class="entrust-xq">
    <div class="left">
        <a href="javascript:;" id="lijiweituo" class="ast">立即委托</a>
        <p>
            我们会有客服专员<br>
            联系您，请您耐心等待！
        </p>
    </div>
    <div class="left">
        <a href="/Home/User/UserCenter" class="ast">完善资料并委托</a>
        <p>
            完善资料，帮您分配 <br>
            相应的客服专员，需求明确<br>
            节省您的宝贵时间！<br>
        </p>
        <a href="javascript:;" class="clos">关闭</a>
    </div>
</div>
<script src="/Public/Home/js/jquery-1.7.2.min.js"></script>
<script src="/Public/Home/js/bootstrap.min.js"></script>
<script src="/Public/Home/js/swiper-3.4.0.min.js"></script>
<script type="text/javascript">
    $(".carousel-indicators li").eq(0).addClass("active");
    $(".carousel-inner .item").eq(0).addClass("active");
    $(function(){
        $('#lijiweituo').click(function(){
           var shoujihao =  $('#weituoshoujihao').val();
           console.log(shoujihao);
            if (shoujihao=='') {
                layer.msg('请输入手机号', function(){
                    
                });
                return false;
            }
            var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(17[0-9]{1})|(18[0-9]{1}))+\d{8})$/; 
            if (!myreg.test(shoujihao)) {
                layer.msg('请输入正确的手机号', function(){
                    
                });
                return false;
            }
            $.get('/Home/Other/NiMing',{mobile:shoujihao},function(result){
                if(result == 1)
                {
                    layer.alert('委托成功', {icon: 6});
                }
                 else
                {
                     layer.msg('委托失败', {icon: 5});
                }
            })
        });
        $('#daohangweituo').click(function(){
           var mobile =  $('#daohang_mobile').val();
           console.log(mobile);
            if (mobile=='') {
                layer.msg('请输入手机号', function(){
                    
                });
                return false;
            }
            var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(17[0-9]{1})|(18[0-9]{1}))+\d{8})$/; 
            if (!myreg.test(mobile)) {
                layer.msg('请输入正确的手机号', function(){
                    
                });
                return false;
            }
            $.get('/Home/Other/NiMing',{mobile:mobile},function(result){
                if(result == 1)
                {
                    layer.alert('委托成功', {icon: 6});
                }
                 else
                {
                     layer.msg('委托失败', {icon: 5});
                }
            })
        });
    });
</script>

<div class="case">
    <div class="content">
                 <?php $mobile = M('mobile_conf')->select(); ?>
        <div class="top text-center">
            <p class="bt"><?php echo ($mobile[7]['english']); ?></p>
            <p class="wz"><?php echo ($mobile[7]['chinese']); ?></p>
        </div>
        <ul>
            <?php if(is_array($CaseList)): $i = 0; $__LIST__ = $CaseList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><li>
                <a href="<?php if($v['type'] == 1){echo '/index.php/Home/ListInfo/CaseInfo?id='.$v['id'].'&title='.$v[case_title];}else{echo '/index.php/Home/SubPage/Invitation?title='.$v[case_title];}?>">
                    <img src="<?php echo C('imgurl'); echo ($v["case_img"]); ?>" alt="">
                    <p>
                        <span><?php echo ($v["case_title"]); ?></span>
                        <span><?php echo ($v["case_description"]); ?></span>
                        <span>归类：<?php echo ($v["case_classify_name"]); ?></span>
                        <span>﹀</span>
                    </p>
                </a>
            </li><?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
    </div>
</div>

<div class="case-b">
    <div class="content">
        <div class="top">
            <?php echo htmlspecialchars_decode($company['zhaoshang_content']) ?>
        </div>
        <ul>
            <?php if(is_array($classify)): $i = 0; $__LIST__ = $classify;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><li><a href=""><?php echo ($v["case_classify_name"]); ?></a></li><?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
    </div>
</div>

<!--footer-->
<div class="footer">
    <?php  $Conf = M('conf'); $ConfInfo = $Conf->where('id=1')->find(); ?>
<div class="content text-center">
        <p class="top"><?php echo ($ConfInfo["conf_24hours"]); ?> / <?php echo ($ConfInfo["conf_company_telephone"]); ?> </p>
        <p class="top-w"><?php echo ($ConfInfo["conf_company_address"]); ?></p>
        <div class="wei">
            <img src="<?php echo C('imgurl'); echo ($ConfInfo["conf_qrcode"]); ?>" style="width: 2.16rem">
            <div>
                <p><?php echo ($ConfInfo["conf_company_name"]); ?></p>
                <p><?php echo ($ConfInfo["conf_company_records"]); ?></p>
            </div>
        </div>
    </div>
</div>
<!--footer-->

<div class="fixed-bottom">
    <div class="content">
        <ul>
            <li><a href="/">网站首页</a></li>
            <li><a href="#">立即委托</a></li>
            <li><a href="tel:<?php echo ($ConfInfo["conf_company_telephone"]); ?>">合作热线</a></li>
            <li><a href="/index.php/Home/SubPage/Join">加入我们</a></li>
        </ul>
    </div>
</div>

<div class="fixed-right">
     <?php
 $Userid = cookie('User_id'); if(empty($Userid)){ ?>
    <a href="/index.php/Home/User/Login"> <p>立即</p> <p>登陆</p></a>
    <?php }else{ ?>
    <a href="/index.php/Home/User/UserCenter"><p>个人</p> <p>中心</p></a>
    <?php } ?>
    <a href="/index.php/Home/User/Register"> <p>免费</p> <p>注册</p></a>
</div>

<script src="/Public/Home/js/jquery-1.7.2.min.js"></script>
<script src="/Public/Home/js/bootstrap.min.js"></script>
<script src="/Public/Home/js/index.js"></script>
</body>
</html>