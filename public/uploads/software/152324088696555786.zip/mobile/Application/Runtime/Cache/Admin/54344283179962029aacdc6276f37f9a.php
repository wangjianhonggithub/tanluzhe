<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<!--[if lt IE 7]> <html class="lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--><html lang="en"><!--<![endif]-->
<head>
    <meta charset="utf-8">

    <!-- Viewport Metatag -->
    <meta name="viewport" content="width=device-width,initial-scale=1.0">

    <!-- Plugin Stylesheets first to ease overrides -->
    <link rel="stylesheet" type="text/css" href="/Public/Admin/plugins/colorpicker/colorpicker.css" media="screen">

    <!-- Required Stylesheets -->
    <link rel="stylesheet" type="text/css" href="/Public/Admin/bootstrap/css/bootstrap.min.css" media="screen">
    <link rel="stylesheet" type="text/css" href="/Public/Admin/css/fonts/ptsans/stylesheet.css" media="screen">
    <link rel="stylesheet" type="text/css" href="/Public/Admin/css/fonts/icomoon/style.css" media="screen">

    <link rel="stylesheet" type="text/css" href="/Public/Admin/css/mws-style.css" media="screen">
    <link rel="stylesheet" type="text/css" href="/Public/Admin/css/icons/icol16.css" media="screen">
    <link rel="stylesheet" type="text/css" href="/Public/Admin/css/icons/icol32.css" media="screen">
    <link rel="stylesheet" type="text/css" href="/Public/Admin/css/mypage.css" media="screen">

    <!-- Demo Stylesheet -->
    <link rel="stylesheet" type="text/css" href="/Public/Admin/css/demo.css" media="screen">
    <link rel="stylesheet" type="text/css" href="/Public/Admin/css/resume.css" media="screen">
    <!-- jQuery-UI Stylesheet -->
    <link rel="stylesheet" type="text/css" href="/Public/Admin/jui/css/jquery.ui.all.css" media="screen">
    <link rel="stylesheet" type="text/css" href="/Public/Admin/jui/jquery-ui.custom.css" media="screen">
    <!-- Theme Stylesheet -->
    <link rel="stylesheet" type="text/css" href="/Public/Admin/css/mws-theme.css" media="screen">
    <link rel="stylesheet" type="text/css" href="/Public/Admin/css/themer.css" media="screen">
    <title>睿博行后台管理系统</title>

</head>

<body>
<!-- Header -->
<div id="mws-header" class="clearfix">

    <!-- Logo Container -->
    <div id="mws-logo-container">

        <!-- Logo Wrapper, images put within this wrapper will always be vertically centered -->
        <div id="mws-logo-wrap">
            <img src="/Public/Home/LOGO.png" alt="mws admin">
        </div>
    </div>

    <!-- User Tools (notifications, logout, profile, change password) -->
    <div id="mws-user-tools" class="clearfix">

        <!-- Notifications -->


        <!-- Messages -->

        <!-- User Information and functions section -->

            <!-- Username and Functions -->
                <ul>
                    <li><a href="/Admin/Login/loginout">退出</a></li>
                </ul>
    </div>
</div>

<!-- Start Main Wrapper -->
<div id="mws-wrapper">

    <!-- Necessary markup, do not remove -->
    <div id="mws-sidebar-stitch"></div>
    <div id="mws-sidebar-bg"></div>

    <!-- Sidebar Wrapper -->
    <div id="mws-sidebar">

        <!-- Hidden Nav Collapse Button -->
        <div id="mws-nav-collapse">
            <span></span>
            <span></span>
            <span></span>
        </div>


        <!-- Main Navigation -->
        <div id="mws-navigation">
            <ul>
                <li>
                    <a href="#"><i class="icon-feather"></i> 会员用户管理</a>
                    <ul>
                        <li><a href="/Admin">会员用户管理</a></li>
                        <li><a href="/Admin/User/ChongZhi">重置</a></li>
                        <li><a href="/Admin/User/Phone">更换手机号</a></li>
                    </ul>
                </li></li>
                <li><a href="/Admin/AdminUser/AdminUserList"><i class="icon-user"></i> 后台用户管理</a></li>
                <li><a href="/Admin/Join/Jianli"><i class="icon-user"></i> 简历管理</a></li>
                <li>
                    <a href="#"><i class="icon-feather"></i> 案例/投标管理</a>
                    <ul>
                        <li><a href="/Admin/Case/CaseList">案例</a></li>
                        <li><a href="/Admin/Case/TouBiao">投标</a></li>
                        <li><a href="/Admin/Case/CaseClassify">分类</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#"><i class="icon-envelope"></i> 信息资讯</a>
                    <ul>
                        <li><a href="/Admin/News/NewsList">文章</a></li>
                        <li><a href="/Admin/News/classify">分类</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#"><i class="icon-envelope"></i> 业务管理</a>
                    <ul>
                        <li><a href="/Admin/Conf/BusinessList">业务管理图标</a></li>
                        <li><a href="/Admin/Yewu/YewuList">业务分类</a></li>
                        <li><a href="/Admin/Yewu/YewuFanwei">服务范围</a></li>
                    </ul>
                </li>
                <li><a href="/Admin/Cooperate/CooperateList"><i class="icon-users"></i> 合作管理</a></li>

                <li>
                    <a href="#"><i class="icon-flag"></i> 网站建设</a>
                    <ul>
                        <li><a href="/Admin/Join/JoinList">招聘管理</a></li>
                        <li><a href="/Admin/Other/StaffList">职员管理</a></li>
                        <li><a href="/Admin/Conf/Company">企业资料</a></li>
                        <li><a href="/Admin/Conf/Qiye">企业愿景</a></li>
                        <li><a href="/Admin/Conf/YewuInfo">业务信息</a></li>
                    </ul>
                </li>
                
                <li>
                    <a href="#"><i class="icon-feather"></i> 委托管理</a>
                    <ul>
                        <li><a href="/Admin/Other/Zufang">出租委托</a></li>
                        <li><a href="/Admin/Other/Zhaodian">找店委托</a></li>
                        <li><a href="/Admin/Other/NiMing">匿名委托</a></li>
                        <li><a href="/Admin/Other/XuQiu">需求反馈</a></li>
                        <li><a href="/Admin/Other/ZiXun">招标信息</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#"><i class="icon-list"></i> 配置管理</a>
                    <ul>
                        <li><a href="/Admin/Banner/BannerList">Banner</a></li>
                        <!-- <li><a href="/Admin/Banner/BannerColumnList">导航</a></li> -->
                        <li><a href="/Admin/AdminUser/UpdateAdminUser">修改后台用户密码</a></li>
                        <li><a href="/Admin/Conf/conf">网站配置</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
<!-- 首页用户列表开始 -->
<div class="container">
    <div class="mws-panel grid_7">
        <div class="mws-panel-header">
            <span><i class="icon-table"></i> 添加新闻资讯</span>
        </div>
        <div class="mws-panel-body no-padding">
            <form class="mws-form" action="/Admin/News/DoNewsAdd" method="post" enctype="multipart/form-data">
                <div class="mws-form-inline">
                    <div class="mws-form-row">
                        <label class="mws-form-label">所属分类</label>
                        <div class="mws-form-item">
                            <select name="classify_id">
                                <?php if(is_array($res)): $i = 0; $__LIST__ = $res;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><option value="<?php echo ($v["classify_id"]); ?>"><?php echo ($v["classify_name"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
                            </select>
                        </div>
                    </div>
                    <div class="mws-form-row">
                        <label class="mws-form-label">新闻资讯标题</label>
                        <div class="mws-form-item">
                            <input type="text" name="news_title" class="large">
                        </div>
                    </div>
                    <div class="mws-form-row">
                        <label class="mws-form-label">新闻封面图</label>
                        <div class="mws-form-item">
                            <input type="file" name="news_img" class="large">
                        </div>
                    </div>
                    <div class="mws-form-row">
                        <label class="mws-form-label">新闻资讯描述</label>
                        <div class="mws-form-item">
                            <input type="text" name="news_description" class="large">
                        </div>
                    </div>
                    <div class="mws-form-row">
                        <label class="mws-form-label">新闻资讯内容</label>
                        <div class="mws-form-item">
                            <script id="container" name="content" type="text/plain">
                            </script>
                        </div>
                    </div>
                </div>
                <div class="mws-button-row">
                    <input type="submit" value="点击提交" class="btn btn-danger">
                </div>
            </form>
        </div>   
    </div>
</div>
<!-- Main Container End -->
<script type="text/javascript" src="/public/ueditor/ueditor.config.js"></script>
<!-- 编辑器源码文件 -->
<script type="text/javascript" src="/public/ueditor/ueditor.all.js"></script>
<!-- 实例化编辑器 -->
<script>
    var editor = UE.getEditor('container',{
        initialFrameWidth :830,//设置编辑器宽度
        initialFrameHeight:400,//设置编辑器高度
        scaleEnabled:true
    });
</script>
<!-- 结束 -->
    </div>

    <!-- JavaScript Plugins -->
    <script src="/Public/Admin/js/libs/jquery-1.8.3.min.js"></script>
    <script src="/Public/Admin/js/libs/jquery.mousewheel.min.js"></script>
    <script src="/Public/Admin/js/libs/jquery.placeholder.min.js"></script>
    <script src="/Public/Admin/custom-plugins/fileinput.js"></script>

    <!-- jQuery-UI Dependent Scripts -->
    <script src="/Public/Admin/jui/js/jquery-ui-1.9.2.min.js"></script>
    <script src="/Public/Admin/jui/jquery-ui.custom.min.js"></script>
    <script src="/Public/Admin/jui/js/jquery.ui.touch-punch.js"></script>

    <!-- Plugin Scripts -->
    <script src="/Public/Admin/plugins/colorpicker/colorpicker-min.js"></script>
    <script src="/Public/Admin/plugins/validate/jquery.validate-min.js"></script>

    <!-- Wizard Plugin -->
    <script src="/Public/Admin/custom-plugins/wizard/wizard.min.js"></script>
    <script src="/Public/Admin/custom-plugins/wizard/jquery.form.min.js"></script>

    <!-- Core Script -->
    <script src="/Public/Admin/bootstrap/js/bootstrap.min.js"></script>
    <script src="/Public/Admin/js/core/mws.js"></script>

    <!-- Themer Script (Remove if not needed) -->
    <script src="/Public/Admin/js/core/themer.js"></script>

    <!-- Demo Scripts (remove if not needed) -->
    <script src="/Public/Admin/js/demo/demo.wizard.js"></script>