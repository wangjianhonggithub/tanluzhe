<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>瑞博行 -- 搜索结果</title>
    <meta content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" name="viewport" />
    <link rel="stylesheet" href="/Public/Home/css/bootstrap.min.css">
    <link rel="stylesheet" href="/Public/Home/css/search.css">
    <script src="/Public/Home/js/include.js"></script>
</head>
<body>

<!--导航-->
<nav class="navbar navbar-default">
    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="/"><img  src="/Public/Home/images/logo.png" alt="logo"></a>
        </div>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="/">首页</a></li>
                <li><a href="/Home/SubPage/About">关于瑞博行</a></li>
                <li>
                    <a href="/Home/SubPage/Business">业务板块</a>
                    <div class="fixed-nav fixed-xm">
                        <p>业务范围</p>
                        <p>开发产品</p>
                        <p>招商品牌</p>
                    </div>
                </li>
                <li>
                    <a href="/Home/List/CaseList">
                        招商项目
                    </a>
                    <?php  $zhaoshanginfo = M('case')->order('id desc')->select(); ?>
                    <div class="fixed-nav">
                        <img  src="<?php echo $zhaoshanginfo[0]['case_img'] ?>" alt="">
                        <p>
                            <span><?php echo htmlspecialchars_decode($zhaoshanginfo[0]['case_content']) ?></span>
                            <a href="/Home/SubPage/Invitation" class="ast">我要招标</a>
                        </p>
                    </div>
                </li>
                <li><a href="/Home/SubPage/Prospect">企业愿景</a></li>
                <li><a href="/Home/SubPage/Join">加入我们</a></li>
            </ul>
        </div><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>
<!--导航-->

<div class="entrust">
    <div class="left">
        <a href="javascript:;" id="lijiweituo" class="ast">立即委托</a>
        <p>
            我们会有客服专员<br>
            联系您，请您耐心等待！
        </p>
    </div>
    <div class="left">
        <a href="/Home/User/UserCenter" class="ast">完善资料并委托</a>
        <p>
            完善资料，帮您分配 <br>
            相应的客服专员，需求明确<br>
            节省您的宝贵时间！<br>
        </p>
        <a href="javascript:;" class="clos">关闭</a>
    </div>
</div>



<div id="carousel-example-generic" class="carousel slide banner" data-ride="carousel">
    <div class="carousel-inner" role="listbox">
        <?php if(is_array($Banner)): $i = 0; $__LIST__ = $Banner;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$value): $mod = ($i % 2 );++$i;?><div class="item">
            <img  src="<?php echo ($value["banner_img"]); ?>">
        </div><?php endforeach; endif; else: echo "" ;endif; ?>
    </div>
<div class="banner-fixed">
        <p class="top">找商铺就找瑞博行!</p>
        <p class="title">一键提交需求 即可为你服务</p>
        <p>
            <input type="text" id="weituoshoujihao" placeholder=" 输入手机号">
            <button id="entrust">立即委托</button>
        </p>
</div>
</div>

<div class="search">
    <div class="content">
        <p class="top">搜索结果：</p>
        <ul>
            <?php if(is_array($Seach)): $i = 0; $__LIST__ = $Seach;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><li>
                <a href="/Home/ListInfo/CaseInfo?id=<?php echo ($v["id"]); ?>">
                    <img src="<?php echo ($v["case_img"]); ?>" alt="">
                    <span class="wz">
                        <span class="bt"><?php echo ($v["case_title"]); ?></span>
                        <span class="nr">
                            <?php echo ($v["case_description"]); ?>
                        </span>
                    </span>
                </a>
            </li><?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
    </div>
</div>

<!--搜索案例-->
<div class="seek">
    <div class="content">
        <p class="top">快捷搜索</p>
        <p class="suo">
            <form action="/Home/SubPage/Seach" method="get" accept-charset="utf-8">
              <input type="text" name="seach" placeholder=" 输入关键词">
                <button type="sublimt">立即搜索</button>
            </form>
        </p>
        <p class="wz">
            找到跟您想似的案例，帮助您更好的了解我们
        </p>
        <div class="fixed-f">
            <p>专业管理团队</p>
        </div>
    </div>
</div>
<!--搜索案例-->

<!--footer-->
<div class="footer">
    <div class="content">
        <div class="left">
            <?php  $yewu = M('yewu')->select(); $fenlei = M('yewufanwei')->select(); foreach($yewu as &$yewuinfo){ $yewuinfo['fenlei'] = []; foreach($fenlei as $fenleiinfo){ if($yewuinfo['id'] == $fenleiinfo['yid']){ $yewuinfo['fenlei'][] = $fenleiinfo; } } } ?>
            <ul>
                <?php foreach($yewu as $value){?>
                <li>
                    <p class="title"><?php echo $value['yewu_name']?></p>
                    <?php foreach($value['fenlei'] as $v){ ?>
                    <p><?php echo $v['fanwei']?></p>
                    <?php }?>
                </li>
                <?php }?>
            </ul>
            <div class="fixed-f">
                <p>专业高级顾问</p>
            </div>
        </div>
        <?php  $Conf = M('conf'); $ConfInfo = $Conf->where('id=1')->find(); ?>
        <div class="right">
            <span class="r-left">
                <span>CONTACT 联系我们</span>
                <span><?php echo ($ConfInfo["conf_company_name"]); ?></span>
                <span>电话：<?php echo ($ConfInfo["conf_company_telephone"]); ?> </span>
                <span>邮箱：<?php echo ($ConfInfo["conf_company_email"]); ?></span>
                <span>备案号：<?php echo ($ConfInfo["conf_company_records"]); ?></span>
            </span>
            <img  src="<?php echo ($ConfInfo["conf_qrcode"]); ?>">
        </div>
    </div>
</div>
<!--footer-->

<div class="fixed-right">
    <a href="javascript:;">
        <span>联系</span>
        <span>电话</span>
        <p class="fu"><img  src="/Public/Home/images/dian.png" alt=""> <span><?php echo ($ConfInfo["conf_company_telephone"]); ?></span></p>
    </a>
    <?php
 $Userid = cookie('User_id'); if(empty($Userid)){ ?>
    <a href="/Home/User/Login">
        <span>立即</span>
        <span>登录</span>
    </a>
    <?php }else{ ?>
    <a href="/Home/User/UserCenter">
        <span>个人</span>
        <span>中心</span>
    </a>
    <?php } ?>
    <a href="/Home/User/Register">
        <span>免费</span>
        <span>注册</span>
    </a>
    <a href="">
        <span>需求</span>
        <span>反馈</span>
    </a>
</div>


<script src="/Public/Home/js/jquery-1.7.2.min.js"></script>
<script src="/Public/Home/js/bootstrap.min.js"></script>
<script src="/Public/Home/js/index.js"></script>
<script type="text/javascript">
     $("#carousel-example-generic .item").eq(0).addClass("active");
</script>
</body>
</html>