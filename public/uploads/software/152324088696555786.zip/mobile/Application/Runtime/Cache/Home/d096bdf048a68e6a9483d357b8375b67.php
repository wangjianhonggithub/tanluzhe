<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>瑞博行 -- 企业愿景</title>
    <meta content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" name="viewport" />
    <link rel="stylesheet" href="/Public/Home/css/bootstrap.min.css">
    <link rel="stylesheet" href="/Public/Home/css/prospect.css">
    <script src="/Public/Home/js/include.js"></script>
</head>
<body>

<!--导航-->
<nav class="navbar navbar-default">
    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.html"><img  src="/Public/Home/images/logo.png" alt="logo"></a>
        </div>
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="/">首页</a></li>
                <li><a href="/Home/SubPage/About">关于瑞博行</a></li>
                <li><a href="/Home/SubPage/Business">业务板块</a></li>
                <li>
                    <a href="/Home/SubPage/Article">
                        招商项目
                    </a>
                    <div class="fixed-nav">
                        <img  src="/Public/Home/images/1.jpg" alt="">
                        <p>
                            <span>真情像草原广阔，层层风雨不能阻隔，一剪寒梅傲立雪招商项目招商项目招商项目招商项目招商项目招商项目招商项目</span>
                            <a href="invitation.html" class="ast">我要招标</a>
                        </p>
                    </div>
                </li>
                <li><a href="/Home/SubPage/Prospect">企业愿景</a></li>
                <li><a href="join.html">加入我们</a></li>
            </ul>
        </div><!-- /.navbar-collapse -->
    </div><!-- /.container-fluid -->
</nav>
<!--导航-->

<div class="entrust">
    <div class="left">
        <a href="" class="ast">立即委托</a>
        <p>
            我们会有客服专员<br>
            联系您，请您耐心等待！
        </p>
    </div>
    <div class="left">
        <a href="" class="ast">完善资料并委托</a>
        <p>
            完善资料，帮您分配 <br>
            相应的客服专员，需求明确<br>
            节省您的宝贵时间！<br>
        </p>
        <a href="javascript:;" class="clos">关闭</a>
    </div>
</div>

<!--banner-->
<div id="carousel-example-generic" class="carousel slide banner" data-ride="carousel">
    <div class="carousel-inner" role="listbox">
        <div class="item active">
            <img src="/Public/Home/images/banner.jpg">
        </div>
        <div class="item">
            <img src="/Public/Home/images/banner.jpg">
        </div>
        <div class="item">
            <img src="/Public/Home/images/banner.jpg">
        </div>
        <div class="item">
            <img src="/Public/Home/images/banner.jpg">
        </div>
    </div>
    <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
    <div class="banner-fixed">
        <p class="top">找商铺就找瑞博行!</p>
        <p class="title">一键提交需求 即可为你服务</p>
        <p>
            <input type="text" placeholder=" 输入手机号">
            <button id="entrust">立即委托</button>
        </p>
    </div>
</div>
<!--banner-->

<!--企业愿景-->
<div class="prospect prospect-n">
    <div class="content">
        <ul>
            <li>
                <a href="javascript:;">
                    <img src="/Public/Home/images/yuanjing.png">
                    <span class="big">
                        <span class="top">
                            企业愿景
                            <b></b>
                        </span>
                        <span class="wz">睿博行全员将以公正、诚实、守信等为人处事的工作原则，尽职尽责，高效执行工作规范、与合作伙伴共享行业成长、
                        不断创新创造更高价值不断创新创造更高价值不断创新创造更高价值不断创新创造更高价值不断创新创造更高价值不
                        断创新创造更高价值不断创新创造更高价值不断创新创造更高价值不断创新创造更高价值不断创新创造更高价值不断
                        创新创造更高价值不断创新创造更高价值不断创新创造更高价值不断创新创造更高价值不断创新创造更高价值不断创
                        新创造更高价值！</span>
                    </span>
                </a>
            </li>
        </ul>
    </div>
</div>
<!--企业愿景-->

<!--核心目标-->
<div class="prospect prospect-t">
    <div class="content">
        <ul>
            <li>
                <a href="javascript:;">
                    <span class="big">
                        <span class="top">
                            核心目标
                              <b></b>
                        </span>
                        <span class="wz">睿博行全员将以公正、诚实、守信等为人处事的工作原则，尽职尽责，高效执行工作规范、与合作伙伴共享行业成长、不
                            断创新创造更高价值！</span>
                    </span>
                    <img src="/Public/Home/images/yuanjing.png">
                </a>
            </li>
        </ul>
    </div>
</div>
<!--核心目标-->

<!--战略文化-->
<div class="culture">
    <div class="content">
        <img src="/Public/Home/images/culture-l.png">
        <div class="wz">
            <p>战略文化</p>
            北京睿博行卓越商业管理公司、是一家主要从事商业地产项目前期业态论证，主题定位管理，自主经营以及金融投资全方位商业
            管理公司，注册资金1000万，同时为开发项目提供商业经营管理团队输出、广告营销推广代理、项目
        </div>
        <img src="/Public/Home/images/culture-r.png" class="img-r">
    </div>
</div>
<!--战略文化-->


<!--搜索案例-->
<div class="seek">
    <div class="content">
        <p class="top">快捷搜索</p>
        <p class="suo">
            <input type="text" placeholder=" 输入关键词">
            <button>立即搜索</button>
        </p>
        <p class="wz">
            找到跟您想似的案例，帮助您更好的了解我们
        </p>
        <div class="fixed-f">
            <p>专业管理团队</p>
        </div>
    </div>
</div>
<!--搜索案例-->

<!--footer-->
<div class="footer">
    <div class="content">
        <div class="left">
            <ul>
                <li>
                    <p class="title">开发产品</p>
                    <p>门面房托管</p>
                    <p>社区商业</p>
                    <p>商场·超市·国企房源</p>
                </li>
                <li>
                    <p class="title">招商品牌</p>
                    <p>招商资源</p>
                    <p>联系人</p>
                    <p>品牌类别</p>
                    <p>前景</p>
                </li>
                <li>
                    <p class="title">招商方式</p>
                    <p>渠道</p>
                    <p>电话</p>
                    <p>网络</p>
                    <p>招标</p>
                </li>
            </ul>
            <div class="fixed-f">
                <p>专业高级顾问</p>
            </div>
        </div>
        <div class="right">
            <span class="r-left">
                <span>CONTACT 联系我们</span>
                <span>北京睿博行卓越商业地产有限公司</span>
                <span>电话：189 - 1021 - 7777 </span>
                <span>邮箱：rbh6668888@163.com</span>
                <span>备案号：xxxxxx</span>
            </span>
            <img  src="/Public/Home/images/w.png">
        </div>
    </div>
</div>
<!--footer-->

<div class="fixed-right">
    <a href="javascript:;">
        <span>联系</span>
        <span>电话</span>
        <p class="fu"><img  src="/Public/Home/images/dian.png" alt=""> <span>189 - 1021 - 7777</span></p>
    </a>
    <a href="login.html">
        <span>立即</span>
        <span>登录</span>
    </a>
    <a href="registered.html">
        <span>免费</span>
        <span>注册</span>
    </a>
    <a href="">
        <span>需求</span>
        <span>反馈</span>
    </a>
</div>

<script src="/Public/Home/js/jquery-1.7.2.min.js"></script>
<script src="/Public/Home/js/bootstrap.min.js"></script>
<script src="/Public/Home/js/prospect.js"></script>
</body>
</html>