<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>瑞博行 -- 个人中心</title>
    <meta content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" name="viewport" />
    <link rel="stylesheet" href="/Public/Home/css/bootstrap.min.css">
    <link rel="stylesheet" href="/Public/Home/css/personal-zufang.css">
    <link rel="stylesheet" href="/Public/Home/css/personal-nav.css">
    <link rel="stylesheet" href="/Public/layui/css/layui.css">
    <script  src="/Public/layui/layui.all.js"></script>
    <script src="/Public/Home/js/include.js"></script>
</head>
<body>

<div class="personal">
    <div class="content">
        <div class="nav">
    <p class="top">
        <img src="/Public/Home/images/login-logo.png">
        <span>
            个人中心
            <a href="/index.php/Home/User/Loginout">退出</a>
        </span>
    </p>
    <ul>
        <li>
            <a href="/index.php/Home/User/UserCenter">完善资料</a>
        </li>
        <li>
            <a href="/index.php/Home/User/UpdatePasswd">修改密码</a>
        </li>
        <li>
            <a href="/index.php/Home/User/UpdateTelephone">修改手机号</a>
        </li>
        <li>
            <a href="/index.php/Home/User/Single">我的反馈单</a>
        </li>
    </ul>
</div>
<p class="title text-center">
    <span>请选择您需要的业务完善您的资料</span>
    <span>直接跳转到下一步</span>
</p>

<div class="fixed-bottom">
    <div class="content">
        <ul>
            <li><a href="/">网站首页</a></li>
            <li><a href="/" style="color: #0687fe;">立即委托</a></li>
            <li><a href="tel:18910217777">合作热线</a></li>
            <li><a href="/index.php/Home/SubPage/Join">加入我们</a></li>
            
        </ul>
    </div>
</div>

<div class="fixed-right">
     <?php
 $Userid = cookie('User_id'); if(empty($Userid)){ ?>
    <a href="/index.php/Home/User/Login"> <p>立即</p> <p>登陆</p></a>
    <?php }else{ ?>
    <a href="/index.php/Home/User/UserCenter"><p>个人</p> <p>中心</p></a>
    <?php } ?>
    <a href="/index.php/Home/User/Register"> <p>免费</p> <p>注册</p></a>
</div>
        <div class="personal-right">
            <p class="top"><span>我要找店</span></p>
            <form action="/index.php/Home/User/DoZhaoDian" method="post">
                <label class="lab">
                    <span>姓名</span>
                    <input type="text" name="name" id="zhao-name" placeholder="请输入您的姓名">
                </label>
                <label>
                    <span>性别</span>
                    <input type="radio" class="inp" checked value="1" name="gender"> <span class="xin">男 士</span>
                    <input type="radio" class="inp1" value="2" name="gender"> <span class="xin">女 士</span>
                </label>
                <label class="lab">
                    <span>联系方式</span>
                    <input type="text" name="mobile" id="zhao-mobile" placeholder="请输入您的常用联系电话">
                </label>
                <label class="lab">
                    <span>联系邮箱</span>
                    <input type="text" name="email" id="zhao-email" placeholder="">
                </label>
                <label class="lab">
                    <span>请输入您的行业</span>
                    <input type="text" placeholder="" id="zhao-hangye" name="hangye">
                </label>
                <label class="lab">
                    <span>您的店名</span>
                    <input type="text" placeholder="" id="zhao-dianming" name="dianming">
                </label>
                <label class="lab">
                    <span>需求面积</span>
                    <input type="text" name="mianji" id="zhao-mianji" placeholder="" class="mian"> <span class="pin">m²</span>
                </label>
                <label class="lab">
                    <span>理想区域</span>
                    <input type="text" name="lixiangquyu" id="zhao-lixiangquyu" placeholder="">
                </label>
                <input type="button" id="zhao-tijiao" value="点击提交" class="tujiao">
            </form>
        </div>
    </div>
</div>

<script src="/Public/Home/js/jquery-1.7.2.min.js"></script>
<script src="/Public/Home/js/bootstrap.min.js"></script>
<script src="/Public/Home/js/index.js"></script>
<script type="text/javascript">
    $(function(){
        $('#zhao-tijiao').click(function(){
            var name = $('#zhao-name').val();
            var gender = $('input[name="gender"]:checked').val();
            var mobile = $('#zhao-mobile').val();
            var email = $('#zhao-email').val();
            var hangye = $('#zhao-hangye').val();
            var dianming = $('#zhao-dianming').val();
            var mianji = $('#zhao-mianji').val();
            var lixiangquyu = $('#zhao-lixiangquyu').val();
            if (name == '') {
                layer.msg('请填写姓名', function(){
                 });
                return false;
            }
            if (mobile == '') {
                layer.msg('请填手机号', function(){
                 });
                return false;
            }
            var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(17[0-9]{1})|(18[0-9]{1}))+\d{8})$/; 
            if (!myreg.test(mobile)) {
                layer.msg('请输入正确的手机号', function(){
                    
                });
                return false;
            }  
            if (email == '') {
                layer.msg('请填写邮箱', function(){
                 });
                return false;
            }
            var myreg = /^(\w)+(\.\w+)*@(\w)+((\.\w{2,3}){1,3})$/; 
            if (!myreg.test(email)) {
                layer.msg('请输入正确邮箱', function(){
                    
                });
                return false;
            }  
            if (hangye == '') {
                layer.msg('请输入您的行业', function(){
                 });
                return false;
            }
            if (dianming == '') {
                layer.msg('请填写店名', function(){
                 });
                return false;
            }
            if (mianji == '') {
                layer.msg('请填写面积', function(){
                 });
                return false;
            }
            if (lixiangquyu == '') {
                layer.msg('请填写理想区域', function(){
                 });
                return false;
            }
            $.post('/Home/User/DoZhaoDian',{name:name,gender:gender,mobile:mobile,hangye:hangye,dianming:dianming,mianji:mianji,lixiangquyu:lixiangquyu},function(res){
                var msg=eval("("+res+")");
                 if (msg.status == 1) {
                    layer.alert(msg.info, {icon: 6});
                    $('#zhao-name').val('');
                    $('#zhao-email').val('');
                    $('#zhao-mobile').val('');
                    $('#zhao-hangye').val('');
                    $('#zhao-dianming').val('');
                    $('#zhao-mianji').val('');
                    $('#zhao-lixiangquyu').val('');
                 }
                 if(msg.status == 0)
                 {
                     layer.alert(msg.info, {icon: 5});
                 }
            });
        });
    });
</script>
</body>
</html>