<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>瑞博行 -- 个人中心</title>
    <meta content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no" name="viewport" />
    <link rel="stylesheet" href="/Public/Home/css/bootstrap.min.css">
    <link rel="stylesheet" href="/Public/Home/css/personal-zufang.css">
    <link rel="stylesheet" href="/Public/Home/css/personal-nav.css">
    <link rel="stylesheet" href="/Public/layui/css/layui.css">
    <script  src="/Public/layui/layui.all.js"></script>
    <script src="/Public/Home/js/include.js"></script>
</head>
<body>

<div class="personal">
    <div class="content">
        <div class="nav">
    <p class="top">
        <img src="/Public/Home/images/login-logo.png">
        <span>
            个人中心
            <a href="/index.php/Home/User/Loginout">退出</a>
        </span>
    </p>
    <ul>
        <li>
            <a href="/index.php/Home/User/UserCenter">完善资料</a>
        </li>
        <li>
            <a href="/index.php/Home/User/UpdatePasswd">修改密码</a>
        </li>
        <li>
            <a href="/index.php/Home/User/UpdateTelephone">修改手机号</a>
        </li>
        <li>
            <a href="/index.php/Home/User/Single">我的反馈单</a>
        </li>
    </ul>
</div>
<p class="title text-center">
    <span>请选择您需要的业务完善您的资料</span>
    <span>直接跳转到下一步</span>
</p>

<div class="fixed-bottom">
    <div class="content">
        <ul>
            <li><a href="/">网站首页</a></li>
            <li><a href="tel:18910217777">免费电话</a></li>
            <li><a href="">在线沟通</a></li>
            <li><a href="">立即委托</a></li>
        </ul>
    </div>
</div>

<div class="fixed-right">
     <?php
 $Userid = cookie('User_id'); if(empty($Userid)){ ?>
    <a href="/index.php/Home/User/Login">登录</a>
    <?php }else{ ?>
    <a href="/index.php/Home/User/UserCenter">中心</a>
    <?php } ?>
    <a href="/index.php/Home/User/Register">注册</a>
</div>
        <div class="personal-right">
            <p class="top"><span>我要租房</span></p>
            <form action="/index.php/Home/User/DoZuFang" method="post" enctype="multipart/form-data">
                <label class="lab">
                    <span>姓名</span>
                    <input type="text" name="name" id="zu-name" placeholder="请输入您的姓名">
                </label>
                <label>
                    <span>性别</span>
                    <input type="radio"  class="inp" value="1" name="gender" checked> <span class="xin">男 士</span>
                    <input type="radio" class="inp1" value="2" name="gender"> <span class="xin">女 士</span>
                </label>
                <label class="lab">
                    <span>联系方式</span>
                    <input type="text" name="mobile" id="zu-mobile" placeholder="请输入您的常用联系电话">
                </label>
                <label class="lab">
                    <span>联系邮箱</span>
                    <input type="email" name="email" id="zu-email">
                </label>
                <label class="lab">
                    <span>出租面积</span>
                    <input type="text" name="chuzumianji" id="zu-chuzumianji">
                </label>
                <label>
                    <span>是否可分割</span>
                    <input type="radio" class="inp" value="1" name="is_fenge"> <span class="xin">是</span>
                    <input type="radio" class="inp1" value="2" name="is_fenge" checked> <span class="xin">否</span>
                </label>
                <label>
                    <span>是否可餐饮</span>
                    <input type="radio" class="inp" value="1" name="is_canyin" checked> <span class="xin">是</span>
                    <input type="radio" class="inp1" value="2" name="is_canyin"> <span class="xin">否</span>
                </label>
                <label class="lab">
                    <span>理想招商业态</span>
                    <input type="text" name="zhaoshang_status" id="zu-zhaoshang_status">
                </label>
                <label class="lab">
                    <span>出租资金</span>
                    <input type="text" name="zujin" id="zu-zujin">
                    <select name="zujin_type">
                        <option value="1">元 / 月</option>
                        <option value="2">元 / 天 / 平</option>
                    </select>
                </label>
                <label class="lab">
                    <span>出租位置</span>
                    <input type="text" name="chuzu_weizhi" id="zu-chuzu_weizhi">
                </label>
                <label class="lab">
                    <span>上传实物图片</span>
                    <span class="inp-d">
                        <input type="file" name="fangwu_img" class="inp-b">
                    </span>
                </label>
                <input type="button" id="zu-tijiao" value="点击提交" class="tujiao">
            </form>
        </div>
    </div>
</div>
<script src="/Public/Home/js/jquery-1.7.2.min.js"></script>
<script src="/Public/Home/js/bootstrap.min.js"></script>
<script src="/Public/Home/js/index.js"></script>
<script type="text/javascript">
    $(function(){
        $('#zu-tijiao').click(function(){
            var name = $('#zu-name').val();
            var gender = $('input[name="gender"]:checked').val();
            var mobile = $('#zu-mobile').val();
            var email = $('#zu-email').val();
            var gender = $('input[name="gender"]:checked').val();
            var chuzumianji = $('#zu-chuzumianji').val();
            var is_fenge = $('input[name="is_fenge"]:checked').val();
            var is_canyin = $('input[name="is_canyin"]:checked').val();
            var zhaoshang_status = $('#zu-zhaoshang_status').val();
            var zujin = $('#zu-zujin').val();
            var zujin_type = $('input[name="zujin_type"]:selected').val();
            var chuzu_weizhi = $('#zu-chuzu_weizhi').val();
            var formData = new FormData($('form')[0]);
            $.ajax({
              type: "POST",
              url: "/Home/User/DoZuFang",
              data:formData,
              contentType: false,
              processData: false,
              success: function (res) {
                var msg=eval("("+res+")");
                 if (msg.status == 1) {
                     layer.alert(msg.info, {icon: 6});
                     $('#zu-name').val('');
                     $('#zu-mobile').val('');
                     $('#zu-email').val('');
                     $('#zu-chuzumianji').val('');
                     $('#zu-zhaoshang_status').val('');
                     $('#zu-zujin').val('');
                     $('#zu-chuzu_weizhi').val('');
                 }
                 if(msg.status == 0)
                 {
                     layer.alert(msg.info, {icon: 5});
                 }
                 if(msg.status == 2)
                 {
                    layer.msg(msg.info, function(){
                     });
                    return false;
                 }
                  if(msg.status == 3)
                 {
                    layer.msg(msg.info, function(){
                     });
                    return false;
                 }
                 if(msg.status == 4)
                 {
                    layer.msg(msg.info, function(){
                     });
                    return false;
                 }
              }
            });
        });
    });
</script>
</body>
</html>