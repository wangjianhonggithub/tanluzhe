<?php 
namespace Home\Controller;
/**
* 列表模块
*/
use Think\Controller;
class ListInfoController extends Controller
{
	/**
	 * 新闻详情
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-08
	 * @Email    carlos0608@163.com
	 */
	public function NewsInfo()
	{
		$id = $_GET['id'];
		$result = M('news')
				->join('carlos_classify ON carlos_classify.classify_id = carlos_news.classify_id')
				->where("carlos_news.id=$id")
				->find();
		$Banner = M('banner')->where('cid=4')->select();
        $this->assign('banner',$Banner);
		$this->assign('result',$result);		
		$this->display();
	}

	public function CaseInfo()
	{
		$id = $_GET['id'];
		$Case = M('case')
				->join('carlos_case_classify ON carlos_case_classify.classify_id=carlos_case.classify_id')
				->where("carlos_case.id=$id")
				->find();
		$Banner = M('banner')->where('cid=4')->select();
        $this->assign('banner',$Banner);
		$this->assign('Case',$Case);		
		$this->display();
	}
	
}
 ?>