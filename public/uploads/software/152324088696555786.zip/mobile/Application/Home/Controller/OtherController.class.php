<?php 
namespace Home\Controller;
/**
* 
*/
use Think\Controller;
class OtherController extends Controller
{
	public function XuQiu()
	{
		if (IS_POST) {
			$data['name'] = $_POST['name'];
			$data['mobile'] = $_POST['mobile'];
			$data['content'] = $_POST['content'];
			$data['create_time'] = time();
			$data['type'] = 1;
			$XuQiu = D('Xuqiu');
			if (!$XuQiu->create()) {
				exit($XuQiu->getError());
			}else{
				if ($XuQiu->add($data)) {
					echo 1;
				}else{
					echo 0;
				}
			}
		}else{
			echo 2;
		}
	}
	
	public function NiMing()
	{
		$data['phone'] = $_GET['mobile'];
		$data['create_time'] = time();
		$NiMing = M('niming');
		if ($NiMing->add($data)) {
			echo 1;
		}else{
			echo 2;
		}
	}

}
 ?>