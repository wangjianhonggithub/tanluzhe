<?php 
namespace Home\Controller;
/**
* 所有的子页面控制器
*/
use Think\Controller;
class SubPageController extends Controller
{
	/**
	 * About 关于瑞博行
	 */
	public function About()
	{
		$Banner = M('banner')->where('cid=2')->select();
        $this->assign('banner',$Banner);
		$company = M('company')->where('id=1')->find();
        $this->assign('company',$company);
		$this->display();
	}
	/**
	 * structure  组织结构
	 */
	public function Structure()
	{	
		$Conf = M('conf');
        $ConfInfo = $Conf->where('id=1')->find();
        $this->assign('ConfInfo',$ConfInfo);
        $staff = M('staff');
        $staffinfo = $staff->select();
        $this->assign('staffinfo',$staffinfo);
		$this->display();
	}
	/**
	 * 联系我们
	 */
	public function Contact()
	{
		$Conf = M('conf');
        $ConfInfo = $Conf->where('id=1')->find();
        $this->assign('ConfInfo',$ConfInfo);
		$this->display();
	}
	/**
	 * 业务模块
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-08
	 * @Email    carlos0608@163.com
	 */
	public function Business()
	{
		$yewu = M('yewu');
        $yewuInfo = $yewu->select();
        $this->assign('yewuInfo',$yewuInfo);
        $fanweiOne = M('yewufanwei')->where("yid=1")->select();
        $this->assign('fanwei1',$fanweiOne);
        $fanweiTwo = M('yewufanwei')->where("yid=2")->select();
        $this->assign('fanwei2',$fanweiTwo);
        $fanweiThree = M('yewufanwei')->where("yid=3")->select();
        $this->assign('fanwei3',$fanweiThree);
        $fanweiFour = M('yewufanwei')->where("yid=4")->select();
        $this->assign('fanwei4',$fanweiFour);
        $fanweiFive = M('yewufanwei')->where("yid=5")->select();
        $this->assign('fanwei5',$fanweiFive);
        $Banner = M('banner')->where('cid=3')->select();
        $this->assign('banner',$Banner);        
		$this->display();
	}

	public function YewuLian()
	{
		$id = $_GET['yewu_id'];
		$yewu = M('yewu');
		$result = $yewu->where("id=$id")->find();
		echo json_encode($result);
	}

	public function YewuOne()
	{
		$id = $_GET['fanwei_id'];
		$yewu = M('yewufanwei');
		$result = $yewu->where("yfid=$id")->find();
		echo json_encode($result);
	}
	public function YewuTwo()
	{
		$id = $_GET['fanwei_id'];
		$yewu = M('yewufanwei');
		$result = $yewu->where("yfid=$id")->find();
		echo json_encode($result);
	}
	public function YewuThree()
	{
		$id = $_GET['fanwei_id'];
		$yewu = M('yewufanwei');
		$result = $yewu->where("yfid=$id")->find();
		echo json_encode($result);
	}
	public function YewuFour()
	{
		$id = $_GET['fanwei_id'];
		$yewu = M('yewufanwei');
		$result = $yewu->where("yfid=$id")->find();
		echo json_encode($result);
	}
	public function YewuFive()
	{
		$id = $_GET['fanwei_id'];
		$yewu = M('yewufanwei');
		$result = $yewu->where("yfid=$id")->find();
		echo json_encode($result);
	}
	/**
	 * 招商
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-08
	 * @Email    carlos0608@163.com
	 */
	public function Article()
	{
		$company = M('company')->where('id=1')->find();
        $this->assign('company',$company);
		$this->display();
	}
	/**
	 * 企业愿景
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-08
	 * @Email    carlos0608@163.com
	 */
	public function Prospect()
	{
		$Banner = M('banner')->where('cid=5')->select();
        $this->assign('banner',$Banner);
		$Qiye = M('qiye');
        $QiyeInfo = $Qiye->where('id=1')->find();
        $this->assign('QiyeInfo',$QiyeInfo);
		$this->display();
	}
	/**
	 * 加入我们
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-08
	 * @Email    carlos0608@163.com
	 */
	public function Join()
	{
		$Banner = M('banner')->where('cid=6')->select();
        $this->assign('banner',$Banner);
		$Join = M('join')->select();
    	$this->assign('Join',$Join);
    	$conf = M('conf')->where('id=1')->find();
    	$this->assign('conf',$conf);
		$this->display();
	}

	public function DoJoin()
	{
		if (IS_POST) {
			$data['resume_name'] =$_POST['resume_name'];
			$data['resume_birth'] =$_POST['resume_birth'];
			$data['resume_telephone'] =$_POST['resume_telephone'];
			$data['resume_gender'] =$_POST['resume_gender'];
			$data['resume_unit'] =null;
			$data['resume_duty'] =null;
			$data['resume_required_position'] =$_POST['resume_required_position'];
			$data['resume_education'] =$_POST['resume_education'];
			$data['resume_school'] =null;
			$data['resume_undergo'] =$_POST['resume_undergo'];
			$data['create_time'] =time();
			$data['update_time'] =time();
			$data['status'] =0;
        	$Resume = D('Resume');
			if (!$Resume->create()) {
				$msg = $Resume->getError();
				echo json_encode(['info'=>$msg,'status'=>2]);
			}else{
				if($Resume->add($data)){
					echo json_encode(['info'=>'投递成功','status'=>1]);
				}else{
					echo json_encode(['info'=>'投递失败','status'=>0]);
				}
			}
		}else{	
			$this->error('非法请求','/index.php/Home/SubPage/Join');
		}
	}
	/**
	 * 招标
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-08
	 * @Email    carlos0608@163.com
	 */
	public function Invitation()
	{
		$id = $_GET['id'];
		$zhaoshanginfo = M('case')->where("id=$id")->find();
		$this->assign('zhaobiaotupian',$zhaoshanginfo);
		$Banner = M('banner')->where('cid=4')->select();
        $this->assign('banner',$Banner);
		$Conf = M('conf');
        $ConfInfo = $Conf->where('id=1')->find();
        $this->assign('ConfInfo',$ConfInfo);
		$company = M('company')->where('id=1')->find();
        $this->assign('company',$company);
        $business = M('business')->select();
        $this->assign('business',$business);
		$this->display();
	}

	public function Zixun()
	{
		if (IS_POST) {
			$data['name'] = $_POST['name'];
			$data['mobile'] = $_POST['mobile'];
			$data['casetitle'] =$_POST['caseTitle'];
			$data['content'] = $_POST['content'];
			$data['create_time'] = time();
			$data['type'] = 2;
			$XuQiu = D('Xuqiu');
			if (!$XuQiu->create()) {
				$msg = $XuQiu->getError();
				echo json_encode(['info'=>$msg,'status'=>2]);
			}else{
				if ($XuQiu->add($data)) {
					echo 1;
				}else{
					echo 0;
				}
			}
		}else{
			$this->error('非法请求');
		}
	}
	/**
	 * 搜索页面
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-14
	 * @Email    carlos0608@163.com
	 */
	public function Seach()
	{
        $userForm=M('case'); 
		$Banner = M('banner')->where('cid=1')->select();
        $this->assign('Banner',$Banner);
        $seach = $_GET['seach'];
        if (!empty($seach)) {
        	$where['case_title|case_description|case_content'] = array('like','%'.$seach.'%');
        	$res = $userForm->where($where)->select();
        	$this->assign('Seach',$res);
        }
		$this->display();
	}
}
 ?>