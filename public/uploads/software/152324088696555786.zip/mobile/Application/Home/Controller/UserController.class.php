<?php
namespace Home\Controller;
use Think\Controller;
/**
 * 用户操作--控制器
 */
class UserController extends Controller 
{
	/**
	 * 用户登录
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-08
	 * @Email    carlos0608@163.com
	 */
    public function Login(){
    	$this->display();
    }
    /**
     * 执行登录
     * @Author   CarLos(翟)
     * @DateTime 2018-01-09
     * @Email    carlos0608@163.com
     */
    public function DoLogin()
    {
        $rules = array(
            array('username','/^1[3|4|5|8|7][0-9]\d{4,8}$/','请输入正确的手机号!',0,'regex',1),
            array('username','require','请输入用户名!!!'), //默认情况下用正则进行验证
            array('password','require','请输入密码!!!'), //默认情况下用正则进行验证
        );
       $username = I('post.username');
       $password = md5(I('post.password'));
            
        $User = D("User"); // 实例化User对象
        if (!$User->validate($rules)->create()){
             // 如果创建失败 表示验证没有通过 输出错误提示信息
             $msg = $User->getError();
             echo json_encode(['info'=>$msg,'status'=>2]);
        }else{
             $result = $User->where("username='$username' AND password='$password'")->find();
             if ($result) {
                  cookie('User_id',$result['id']);
                 // $this->success('登录成功','/Home/User/UserCenter');
                  echo json_encode(['info'=>'登陆成功','status'=>1]);
               }else{
                  echo json_encode(['info'=>'登录失败,请检查用户名和密码','status'=>0]);
                 // $this->error('登录失败,请检查用户名和密码');
               }
        }

    }
    /**
     * 退出登录
     * @Author   CarLos(翟)
     * @DateTime 2018-01-09
     * @Email    carlos0608@163.com
     */
    public function Loginout()
    {
        cookie('User_id',null);
        $this->redirect('/');
    }








    /**
     * 密码重置
     * @Author   CarLos(翟)
     * @DateTime 2018-01-09
     * @Email    carlos0608@163.com
     */
    public function ForGet()
    {
        $this->display();
    }

    public function DoForGet()
    {
       if (IS_POST) {
            $data['mobile'] = I('post.mobile');
            $data['create_time'] = time();
            $user = D('Chongzhi');
            if (!$user->create()) {
                $msg = $user->getError();
                echo json_encode(['info'=>$msg,'status'=>'2']);
            }else{
                $result = $user->add($data);
                if ($result) {
                    echo json_encode(['info'=>'我们会在24小时内为您重置密码','status'=>'1']);
                }else{
                    echo json_encode(['info'=>'操作失败','status'=>'0']);
                }
            }
        } 
    }
    /**
     * 用户注册
     * @Author   CarLos(翟)
     * @DateTime 2018-01-08
     * @Email    carlos0608@163.com
     */
    public function Register()
    {
    	$this->display();
    }
    /**
     * 执行用户注册
     */
    public function DoRegister()
    {
    	if (IS_POST) {
    		$data['username'] = I('post.username');
    		$data['password'] = md5(I('post.password'));
    		$data['create_time'] = time();
    		$data['update_time'] = time();
    		$user = D('User');
            if (!$user->create()) {
                $msg = $user->getError();
                echo json_encode(['info'=>$msg,'status'=>'2']);
            }else{
                $result = $user->add($data);
                if ($result) {
                    cookie('User_id',$result);
                    echo json_encode(['info'=>'注册成功','status'=>'1']);
                    // $this->success('注册成功','/Home/User/UserCenter');
                }else{
                    echo json_encode(['info'=>'注册失败','status'=>'0']);
                }
            }
    	}
    }
    /**
     * 个人中心
     * @Author   CarLos(翟)
     * @DateTime 2018-01-09
     * @Email    carlos0608@163.com
     */
    public function UserCenter()
    {   
        $user_id = cookie('User_id');
        if (empty($user_id)) {
           $this->redirect('/Home/User/Login');
        }
        $this->display();
    }
    /**
     * 修改密码
     * @Author   CarLos(翟)
     * @DateTime 2018-01-09
     * @Email    carlos0608@163.com
     */
    public function UpdatePasswd()
    {
       $user_id = cookie('User_id');
       if (empty($user_id)) {
           $this->redirect('/Home/User/Login');
       }
       $this->assign('UserId',$user_id);
       $this->display(); 
    }

    public function DoUpdatePassword()
    {   
        $id = $_POST['uid'];
        $user = M('user')->where("id=$id")->find();
        $password = $_POST['oldPassword'];
        $NewPassword = $_POST['NewPassword'];
        if ($password=='') {
            echo json_encode(['info'=>'请填写旧密码','status'=>'2']);
        }else if ($NewPassword=='') {
            echo json_encode(['info'=>'请填写新密码','status'=>'2']);
        }else if (md5($password) != $user['password']) {
            echo json_encode(['info'=>'旧密码不正确','status'=>'2']);
        }else{
            $jiami =md5($NewPassword);
            $result = M('user')->where("id=$id")->save(['password'=>$jiami]);

            if ($result) {
                cookie('User_id',null);
                // $this->success('修改成功','/index.php/Home/User/Login');
                echo json_encode(['info'=>'修改成功','status'=>'1']);
            }else{
                echo json_encode(['info'=>'修改失败','status'=>'0']);
            }
        }

    }
    /**
     * 修改手机号
     * @Author   CarLos(翟)
     * @DateTime 2018-01-09
     * @Email    carlos0608@163.com
     */
    public function UpdateTelephone()
    {
       $user_id = cookie('User_id');
       if (empty($user_id)) {
           $this->redirect('/Home/User/Login');
       }
       $user = M('user')->where("id=$user_id")->find(); 
       $this->assign('username',$user);       
       $this->display(); 
    }

    public function DoUpdatePhone()
    {
        if (IS_POST) {
            $data['uid'] = I('post.uid');
            $data['oldphone'] = I('post.oldphone');
            $data['newphone'] = I('post.newphone');
            $data['create_time'] = time();
            $user = D('UpdatePhone');
            if (!$user->create()) {
                $msg = $user->getError();
                echo json_encode(['info'=>$msg,'status'=>'2']);
            }else{
                $result = $user->add($data);
                if ($result) {
                    cookie('User_id',$result);
                    // $this->success('提交成功','/index.php/Home/User/UserCenter');
                    echo json_encode(['info'=>'修改成功','status'=>'1']);
                }else{
                    echo json_encode(['info'=>'修改失败','status'=>'0']);
                    // $this->error('提交失败','/index.php/Home/User/DoUpdatePhone');
                }
            }
        }
    }
    /**
     * 反馈单
     * @Author   CarLos(翟)
     * @DateTime 2018-01-09
     * @Email    carlos0608@163.com
     */
    public function Single()
    {
       $user_id = cookie('User_id');
       if (empty($user_id)) {
           $this->redirect('/Home/User/Login');
       }
       $uid = cookie('User_id');
        $weituo = M('weituo')->where("uid=$uid")->select();
        $this->assign('weituo',$weituo);        
        $this->display();
    }
    /**
     * 反馈单详情
     * @Author   CarLos(翟)
     * @DateTime 2018-01-09
     * @Email    carlos0608@163.com
     */
    public function SingleInfo()
    {
       $user_id = cookie('User_id');
       if (empty($user_id)) {
           $this->redirect('/Home/User/Login');
       }
       $id = $_GET['id'];
       $weituo = M('weituo')->where("id=$id")->find();
       $this->assign('weituo',$weituo);        
       $this->display();
    }


    /**
     * 出租
     * @Author   CarLos(翟)
     * @DateTime 2018-01-09
     * @Email    carlos0608@163.com
     */
    public function Zufang()
    {
        $user_id = cookie('User_id');
        if (empty($user_id)) {
            $this->redirect('/Home/User/Login');
        }  
        $this->display();
    }
    /**
     * 执行添加租房信息
     * @Author   CarLos(翟)
     * @DateTime 2018-01-09
     * @Email    carlos0608@163.com
     */
    public function DoZuFang()
    {
        if (IS_POST) {
            $data['name'] = I('post.name');
            $data['uid'] = cookie('User_id');
            $data['gender'] = I('post.gender');
            $data['mobile'] = I('post.mobile');
            $data['email'] = I('post.email');
            $data['chuzumianji'] = I('post.chuzumianji');
            $data['is_fenge'] = I('post.is_fenge');
            $data['is_canyin'] = I('post.is_canyin');
            $data['zhaoshang_status'] = I('post.zhaoshang_status');
            $data['zujin'] = I('post.zujin');
            $data['chuzu_weizhi'] = I('post.chuzu_weizhi');
            $data['zujin_type'] = I('post.zujin_type');
            $data['create_time'] = time();
            $data['type'] = 1;
            $data['status'] = 0;
            $upload = new \Think\Upload();// 实例化上传类
            $upload->maxSize   =     3145728 ;// 设置附件上传大小
            $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
            $upload->rootPath  =     './Uploads/'; // 设置附件上传根目录
            $upload->savePath  =     ''; // 设置附件上传（子）目录
            $info   =   $upload->upload();
            if(!$info) {// 上传错误提示错误信息
                $resmsg = $upload->getError();
                echo json_encode(['info'=>$resmsg,'status'=>3]);
            }else{// 上传成功
                foreach($info as $file){
                    $res =  $file['savepath'].$file['savename'];
                }
                $data['fangwu_img'] = '/Uploads/'.$res;
                $Weituo = D("Weituo");
                if (!$Weituo->create()) {
                    $msg = $Weituo->getError();
                    echo json_encode(['info'=>$msg,'status'=>2]);
                }else{
                    if ($Weituo->add($data)) {
                        echo json_encode(['info'=>'操作成功','status'=>1]);
                    }else{
                        echo json_encode(['info'=>'操作失败','status'=>0]);
                    }
                }
            }
        }else{
            echo json_encode(['info'=>'非法请求','status'=>4]);
        }
    }

    /**
     * 添加找店信息
     * @Author   CarLos(翟)
     * @DateTime 2018-01-09
     * @Email    carlos0608@163.com
     */
    public function ZhaoDian()
    {
        $user_id = cookie('User_id');
        if (empty($user_id)) {
            $this->redirect('/Home/User/Login');
        }  
        $this->display();
    }
    /**
     * 执行找店添加
     * @Author   CarLos(翟)
     * @DateTime 2018-01-09
     * @Email    carlos0608@163.com
     */
    public function DoZhaoDian()
    {
        if (IS_POST) {
           $data['name'] = I('post.name');
           $data['uid'] = cookie('User_id');
           $data['gender'] = I('post.gender');
           $data['mobile'] = I('post.mobile');
           $data['hangye'] = I('post.hangye');
           $data['dianming'] = I('post.dianming');
           $data['mianji'] = I('post.mianji');
           $data['lixiangquyu'] = I('post.lixiangquyu');
           $data['email'] = I('post.email');
           $data['create_time'] = time();
           $data['status'] = 0;
           $data['type'] = 2;
           $Zhaodian = D("Weituo");
                if (!$Zhaodian->create()) {
                    $meg = $Zhaodian->getError();
                    echo json_encode(['info'=>$meg,'status'=>2]);
                }else{
                    if ($Zhaodian->validate($rules)->add($data)) {
                         echo json_encode(['info'=>'操作成功','status'=>1]);
                    }else{
                         echo json_encode(['info'=>'操作失败','status'=>0]);
                    }
                }
        }else{
            $this->error('非法请求');
        }
    }
}   