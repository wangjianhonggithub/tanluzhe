<?php 
namespace Home\Controller;
/**
* 列表模块
*/
use Think\Controller;
class ListController extends Controller
{
	/**
	 * 新闻列表
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-08
	 * @Email    carlos0608@163.com
	 */
	public function NewsList()
	{
		/**
		 * 查询分类
		 */
		$NewsList = M('news')
				->join('carlos_classify ON carlos_classify.classify_id = carlos_news.classify_id')
				->select();
		$Banner = M('banner')->where('cid=4')->select();
        $this->assign('banner',$Banner);
		$this->assign('NewsList',$NewsList);
		$this->display();
	}
	/**
	 * 选项卡
	 * @Author   CarLos(翟)
	 * @DateTime 2018-01-08
	 * @Email    carlos0608@163.com
	 */
	public function GetNewClassify()
	{
		$classify_id = $_GET['classify_id'];
		$classify = M('news')
				->join('carlos_classify ON carlos_classify.classify_id = carlos_news.classify_id')
				->where("carlos_news.classify_id = $classify_id")
				->select();
		echo json_encode($classify);
	}
	
	public function CaseList()
	{
		$classify = M('case_classify')->select();
		$this->assign('classify',$classify);
		$CaseList = M('case')
				->join('carlos_case_classify ON carlos_case_classify.classify_id = carlos_case.classify_id')
				->where('carlos_case.type=1')
				->select();
		$this->assign('CaseList',$CaseList);
		$company = M('company')->where('id=1')->find();
        $this->assign('company',$company);
        $Banner = M('banner')->where('cid=4')->select();
        $this->assign('banner',$Banner); 
		$this->display();
	}
	
	public function ZhaoBiaoList()
	{
		$classify = M('case_classify')->select();
		$this->assign('classify',$classify);
		$CaseList = M('case')
				->join('carlos_case_classify ON carlos_case_classify.classify_id = carlos_case.classify_id')
				->where('carlos_case.type=2')
				->select();
		$this->assign('CaseList',$CaseList);
		$company = M('company')->where('id=1')->find();
        $this->assign('company',$company);
        $Banner = M('banner')->where('cid=4')->select();
        $this->assign('banner',$Banner); 
		$this->display();
	}

	public function GetCaseClassify()
	{
		$classify_id = $_GET['classify_id'];
		$classify = M('case')
				->join('carlos_case_classify ON carlos_case_classify.classify_id = carlos_case.classify_id')
				->where("carlos_case.classify_id = $classify_id")
				->select();
		echo json_encode($classify);
	}
}
 ?>