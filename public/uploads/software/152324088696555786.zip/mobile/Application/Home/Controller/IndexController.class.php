<?php
namespace Home\Controller;
use Think\Controller;
class IndexController extends Controller {
    public function index(){
    	/**
    	 * 填入案例展示
    	 */
    	$case = M('case')->order('id desc')->limit(4)->select();
    	$this->assign('case',$case);
    	/**
    	 * 填入新闻
    	 */
        $classify = M('case_classify')->select();
        $this->assign('classify',$classify);
    	$news = M('news')->limit(3)->order('id desc')->select();
    	$this->assign('news',$news);
        $hezuo = M('hezuo')->select();
        $this->assign('hezuo',$hezuo);
        $Youshi = M('youshi')->select();
        $this->assign('Youshi',$Youshi);
        $mobile = M('mobile_conf')->select();
        $this->assign('mobile',$mobile);
        $mobile_about = M('mobile_about')->select();
        $this->assign('mobile_about',$mobile_about);
        /**
         * 查找合作伙伴 
         */
        $cooperation = M('cooperation')->select();
        $this->assign('cooperation',$cooperation);
        $company = M('company')->where('id=1')->find();
        $this->assign('company',$company);
      	$this->display();
    }

    public function GetYewu()
    {
        $id = $_GET['id'];
        $yewubankuai = M('yewu')->where("id=$id")->find();
        echo json_encode($yewubankuai);
    }
}