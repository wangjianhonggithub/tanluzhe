<?php
return array(
	'imgurl'=>'http://bjrbh.gotoip1.com',
);