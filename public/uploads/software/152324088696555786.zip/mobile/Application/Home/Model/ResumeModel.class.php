<?php 
namespace Admin\Model;
/**
* 
*/
use Think\Model;
class ResumeModel extends Model
{
	protected $tableName = 'resume';
	protected $_validate = array(
	 array('resume_name','require','请填写姓名'),
	 array('resume_birth','require','请填写年龄'),
	 array('resume_telephone','require','请填写电话'),
	 array('resume_telephone','/^1[3|4|5|8|7][0-9]\d{8}$/','请输入正确的手机号!',0,'regex',1), 
	 // array('resume_unit','require','请填写工作单位'),
	 // array('resume_duty','require','请填写现在的职位'),
	 array('resume_required_position','require','请填写想要应聘的职位'),
	 array('resume_education','require','请填写最高学历'),
     array('resume_undergo','require','请填写工作经历以及个人介绍'),
   	);
}
 ?>