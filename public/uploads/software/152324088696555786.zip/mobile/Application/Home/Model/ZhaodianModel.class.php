<?php 
namespace Home\Model;
/**
* 找店模型
*/
use Think\Model;
class ZhaodianModel extends Model
{
	protected $tableName = 'zhaodian';
	protected $_validate = array(
	 array('name','require','请填写你的姓名'),
	 array('gender','require','请选择你的性别'),
	 array('mobile','require','请填写常用电话'),
     array('mobile','/^1[3|4|5|8|7][0-9]\d{8}$/','请输入正确的手机号!',0,'regex',1), 
	 array('email','require','请填写你的邮箱'),
	 array('hangye','require','请填写你的行业'),
	 array('dianming','require','请填写你的店名'),
	 array('mianji','require','请填写需求面积'),
	 array('lixiangquyu','require','请填写理想区域'),
   	);
}
 ?>