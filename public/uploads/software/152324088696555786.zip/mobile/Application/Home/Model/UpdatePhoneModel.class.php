<?php 
namespace Home\Model;
/**
* 
*/
use Think\Model;
class UpdatePhoneModel extends Model
{
	protected $tableName = 'update_phone';
	protected $_validate = array(
	 array('newphone','require','请填写手机号'),
	 array('newphone','/^1[3|4|5|8|7][0-9]\d{8}$/','请输入正确的手机号!',0,'regex',1), 
   	);
}
 ?>