<?php 
namespace Home\Model;
/**
* 出租模型
*/
use Think\Model;
class WeituoModel extends Model
{
	protected $tableName = 'weituo';
	protected $_validate = array(
	 array('name','require','请填写你的姓名'),
	 array('gender','require','请选择你的性别'),
	 array('mobile','require','请填写常用电话'),
     array('mobile','/^1[3|4|5|8|7][0-9]\d{8}$/','请输入正确的手机号!',0,'regex',1), 
	 array('email','require','请填写你的邮箱'),
	 array('email','/^(\w)+(\.\w+)*@(\w)+((\.\w{2,3}){1,3})$/','请输入正确的邮箱!',0,'regex',1),
	 array('chuzumianji','require','请填写出租面积'),
	 array('zhaoshang_status','require','请填写理想招商状态'),
	 array('zujin','require','请填写租金'),
	 array('chuzu_weizhi','require','请填写出租位置'),
   	);
}
 ?>