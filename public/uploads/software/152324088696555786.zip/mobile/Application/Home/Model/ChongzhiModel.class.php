<?php 
namespace Home\Model;
/**
* 
*/
use Think\Model;
class ChongzhiModel extends Model
{
	protected $tableName = 'chongzhi';
	protected $_validate = array(
	 array('mobile','require','请填写手机号'),
	 array('mobile','/^1[3|4|5|8|7][0-9]\d{8}$/','请输入正确的手机号!',0,'regex',1), 
   	);
}
 ?>