<?php
namespace Home\Controller;
use Think\Controller;
/**
* 
*/
class CustomerController extends Controller
{
	public function CustomerList()
	{
		$cookie = cookie('UserId');
		if (empty($cookie)) {
			$this->redirect('/Home/Login/Login');
		}
		$result = M('customer');
		$count = $result->join('admin_users ON admin_users.id = customer.xid')->where("customer.xid=$cookie")->order('customer.id desc')->count();
		$p = getpage($count,10);
		$list = $result->join('admin_users ON admin_users.id = customer.xid')
		                ->join('source_type ON source_type.id = customer.type_id')
		                ->join('source_form ON source_form.id = customer.source_id')
						->field('customer.id,customer.riqi,customer.gs_name,customer.kp_name,customer.mobile,customer.hangye,admin_users.nickname,customer.create_time,customer.update_time,source_type.type_name,source_form.source')
						->order('customer.id desc')
						->where("customer.xid=$cookie")
						->limit($p->firstRow, $p->listRows)
						->select();
		$this->assign('list',$list);
		$this->assign('page', $p->show()); // 赋值分页输出
		$this->display();
	}

	public function AddCustomer()
	{
		$arr = ['A','B','C','D','E'];
		$user = D('AdminUsers');
		$result = $user->select();
		$Source = D('SourceForm')->select();
		$type = D('SourceType')->select();
		$this->assign('source',$Source);
		$this->assign('type',$type);
		$this->assign('user',$result);
		$this->assign('arr',$arr);

		$this->display();
	}

	/**
	 * 执行添加
	 */
	public function DoAddCustomer()
	{
		if (IS_POST) {
			$data['riqi'] = $_POST['riqi'];
			if ($_POST['is_tihai'] == 1) {
		    	$data['xid'] = 0;
		    }else{
		    	$data['xid'] = $_POST['xid'];
		    }
			$data['gs_name'] = $_POST['gs_name'];
			$data['kp_name'] = $_POST['kp_name'];
			$data['mobile'] = $_POST['mobile'];
			$data['hangye'] = $_POST['hangye'];
			$data['y_chengshu'] = $_POST['y_chengshu'];
			$data['wenti'] = isset($_POST['wenti']) ? $_POST['wenti']:'';
			$data['xingqu'] = isset($_POST['xingqu'])? $_POST['xingqu']:'';
			$data['xiezhu'] = '暂无';
			$data['d_chengshu'] = '暂无';
			$data['is_tihai'] = $_POST['is_tihai'];
			$data['type_id'] = $_POST['type_id'];
			$data['source_id'] = $_POST['source_id'];
			$data['create_time'] = time();
			$data['update_time'] = time();
			$Customer = D('Customer');
			if (!$Customer->create()) {
				exit($Customer->getError());
			}else{
				if ($Customer->add($data)) {
					$this->success('操作成功','/Home/Customer/CustomerList');
				}else{
					$this->error('操作失败');
				}
			}
		}else{
			$this->error('非法请求');
		}
	}

	public function UpdateCustomer()
	{
		$cookie = cookie('UserId');
		$id = $_GET['id'];
		$arr = ['A','B','C','D','E'];
		$user = D('AdminUsers');
		$Customer = D('Customer');
		$role = $user->where("id=$cookie")->find();
		$CustomerInfo = $Customer->where("id=$id")->find();
		$result = $user->select();
		$Source = D('SourceForm')->select();
		$type = D('SourceType')->select();
		$this->assign('source',$Source);
		$this->assign('type',$type);
		$this->assign('user',$result);
		$this->assign('role',$role);
		$this->assign('CustomerInfo',$CustomerInfo);
		$this->assign('arr',$arr);
		$this->display();
	}

	public function DoUpdateCustomer()
	{
		$id = $_GET['id'];
	    $data['riqi'] = $_POST['riqi'];
	    if ($_POST['is_tihai'] == 1) {
	    	$data['xid'] = 0;
	    }else{
	    	$data['xid'] = $_POST['xid'];
	    }
		$data['gs_name'] = $_POST['gs_name'];
		$data['kp_name'] = $_POST['kp_name'];
		$data['mobile'] = $_POST['mobile'];
		$data['hangye'] = $_POST['hangye'];
		$data['y_chengshu'] = $_POST['y_chengshu'];
		$data['wenti'] = isset($_POST['wenti']) ? $_POST['wenti']:'';
		$data['xingqu'] = isset($_POST['xingqu'])? $_POST['xingqu']:'';
		$data['xiezhu'] = isset($_POST['xiezhu']) ? $_POST['xiezhu'] :'暂无';
		$data['d_chengshu'] = isset($_POST['d_chengshu']) ? $_POST['d_chengshu']:'暂无';
		$data['is_tihai'] = $_POST['is_tihai'];
		$data['type_id'] = $_POST['type_id'];
		$data['source_id'] = $_POST['source_id'];
		$data['update_time'] = time();
		$Customer = D('Customer');
		if($Customer->where("id=$id")->save($data)){
			$this->success('操作成功','/Home/Customer/CustomerList');
		}else{
			$this->error('操作失败');
		}
	}


	/**
	 * 显示工海
	 */
	public function hall()
	{
		$cookie = cookie('UserId');
		if (empty($cookie)) {
			$this->redirect('/Home/Login/Login');
		}
		$result = M('customer');
		$count = $result->where('customer.is_tihai = 1 and customer.xid=0')->order('customer.id desc')->count();
		$p = getpage($count,16);
		$list = $result->field(true)
						->where("customer.is_tihai = 1 and customer.xid=0")
						->order('id desc')
						->limit($p->firstRow, $p->listRows)
						->select();
		$this->assign('list',$list);
		$this->assign('page', $p->show()); // 赋值分页输出
		$this->display();
	}

	/**
	 * PHPexcel导入
	 */
	public function Excel()
	{
		$this->display();
	}

	/**
	 * 执行导入Excel
	 */
	public function AddExcel()
	{
		$excel = InsterExcel();
		foreach($excel['excel_array'] as $k=>$v) {
			if ($v == null) {
				continue;
			}
            $excelDate[$k]['riqi'] = $v[0];
            $excelDate[$k]['xid'] = 0;
            $excelDate[$k]['gs_name'] = !empty($v[2]) ? $v[2]:'';
            $excelDate[$k]['kp_name'] = !empty($v[3]) ? $v[3]:'';
            $excelDate[$k]['mobile'] = !empty($v[4]) ? $v[4]:'';
            $excelDate[$k]['hangye'] = !empty($v[5]) ? $v[5]:'';
            $excelDate[$k]['y_chengshu'] = !empty($v[6]) ? $v[6]:'';
            $excelDate[$k]['xingqu'] = !empty($v[7]) ? $v[7]:'';
            $excelDate[$k]['wenti'] = !empty($v[8]) ? $v[8]:'';
            $excelDate[$k]['d_chengshu'] = !empty($v[9]) ? $v[9]:'';
            $excelDate[$k]['xiezhu'] = !empty($v[10]) ? $v[10]:'';
            $excelDate[$k]['create_time'] = time();
            $excelDate[$k]['update_time'] = time();
            $excelDate[$k]['is_tihai'] = 1;
        }
        $result = M('customer');
        if ($result->addAll($excelDate)) {
        	unlink($excel['DirPath']);
        	$this->success('操作成功','/Home/Customer/hall');
        }else{
        	$this->error('操作失败');
        }
	}

	public function CustomerSelect()
	{
		$id = $_GET['id'];
		$result = M('customer');
		$list = $result->join('admin_users ON admin_users.id = customer.xid')
						->join('source_type ON source_type.id = customer.type_id')
						->join('source_form ON source_form.id = customer.source_id')
						// ->field('customer.id,customer.riqi,customer.gs_name,customer.kp_name,customer.mobile,customer.hangye,admin_users.nickname,customer.create_time,customer.update_time')
						->field('customer.*,admin_users.nickname,source_type.type_name,source_form.source')
						->where("customer.id=$id")
						->find();
		$this->assign('CustomerInfo',$list);
		$this->display();
	}

	public function hallSelect()
	{
		$id = $_GET['id'];
		$result = M('customer');
		$list = $result->where("customer.id=$id")->find();
		$this->assign('CustomerInfo',$list);
		$this->display();
	}
}