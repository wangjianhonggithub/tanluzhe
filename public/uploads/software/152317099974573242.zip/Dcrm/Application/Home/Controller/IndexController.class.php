<?php
namespace Home\Controller;
use Think\Controller;
class IndexController extends Controller {
    public function index(){
    	$cookie = cookie('UserId');
		if (empty($cookie)) {
			$this->redirect('/Home/Login/Login');
		}
       $this->display();
    }
}