<?php
namespace Home\Controller;
use Think\Controller;
class ColumnController extends Controller 
{
    public function column()
    {	
        $cookie = cookie('UserId');
        if (empty($cookie)) {
            $this->redirect('/Home/Login/Login');
        }
    	$result = D('Column')->GetAll();
    	$data = tree($result,$pid=0,$lev=1);
    	$this->assign('list',$data);
    	$this->display();
    }

    /**
     * 显示添加
     */
    public function ColumnAdd()
    {
    	$result = D('Column')->GetAll();
    	$data = tree($result,$pid=0,$lev=1);
    	$this->assign('list',$data);
    	$this->display();
    }

    /**
     * 执行添加
     */
    public function DoAdd()
    {
    	if (IS_POST) {
    		$data['name']=$_POST['name'];
    		$data['url']=$_POST['url'];
    		$data['icon']=$_POST['icon'];
    		$data['pid']=$_POST['pid'];
    		$data['create_time']=time();
    		$data['update_time']=time();
    		$Column = D('Column');
			if (!$Column->create()) {
				exit($Column->getError());
			}else{
				if ($Column->add($data)) {
					$this->success('操作成功','/Home/Column/column');
				}else{
					$this->error('操作失败');
				}
			}
    	}else{
    		$this->error('非法请求');
    	}
    }

    public function UpdateD()
    {
    	$id = $_GET['id'];
    	$Column = D('Column');
    	$all = $Column->GetAll();
    	$data = tree($all,$pid=0,$lev=1);
    	$result = $Column->find($id);
    	$this->assign('list',$data);
    	$this->assign('Update',$result);
    	$this->display();
    }

    public function DoUpdate()
    {
    	$id = $_GET['id'];
    	$data['name']=$_POST['name'];
		$data['url']=$_POST['url'];
		$data['icon']=$_POST['icon'];
		$data['pid']=$_POST['pid'];
		$data['update_time']=time();
		$Column = D('Column');
		if($Column->where("id=$id")->save($data)){
			$this->success('操作成功','/Home/Column/column');
		}else{
			$this->error('操作失败');
		}
    }

    public function Delete()
    {
    	$id = $_GET['id'];
    	$Column = D('Column');
    	if($Column->delete($id)){
			$this->success('操作成功');
		}else{
			$this->error('操作失败');
		}
    }
}