<?php
namespace Home\Controller;
/**
* 
*/
use Think\Controller;
use Think\Db;
use Home\Model\SourceTypeModel;
use Home\Model\SourceFormModel;
class OtherController extends Controller
{
	/**
	 * 客户类型
	 * @Author   CarLos(翟)
	 * @DateTime 2018-03-26
	 * @Email    carlos0608@163.com
	 */
	public function TypeList()
	{
		$cookie = cookie('UserId');
        if (empty($cookie)) {
            $this->redirect('/Home/Login/Login');
        }
		$result = D('SourceType');
		$count = $result->order('id desc')->count();
		$p = getpage($count,10);
		$list = $result->field(true)->order('id desc')->limit($p->firstRow, $p->listRows)->select();
		$this->assign('list',$list);
		$this->assign('page', $p->show()); // 赋值分页输出
		$this->display();
	}
	/**
	 * 添加类型
	 * @Author   CarLos(翟)
	 * @DateTime 2018-03-26
	 * @Email    carlos0608@163.com
	 */
	public function AddType()
	{
		$this->display();
	}
	/**
	 * 执行添加类型
	 * @Author   CarLos(翟)
	 * @DateTime 2018-03-26
	 * @Email    carlos0608@163.com
	 */
	public function DoType()
	{
		if (IS_POST) {
			$data['type_name'] = $_POST['type_name'];
			$data['create_time'] = time();
			$data['update_time'] = time();
			$type = D('SourceType');
			if (!$type->create()) {
				$this->error($type->getError());
			}else{
				if ($type->add($data)) {
					$this->success('操作成功','/Home/Other/TypeList');
				}else{
					$this->error('操作失败');
				}
			}
		}else{
			$this->error('非法请求');
		}
	}

	/**
	 * 显示修改
	 */
	public function UpType($id)
	{
		$type = D('SourceType');
		$list = $type->GetOne($id);
		$this->assign('list',$list);
		$this->display();
	}

	public function DoUpType($id)
	{
		$data['type_name'] = $_POST['type_name'];
		$data['update_time'] = time();
		$result = SourceTypeModel::Up($id,$data);
		if ($result) {
			$this->success('操作成功','/Home/Other/TypeList');
		}else{
			$this->error('操作失败');
		}
	}

	public function DeleteType($id)
	{
		$result = SourceTypeModel::DataDelete($id);
		if ($result) {
			$this->success('操作成功','/Home/Other/TypeList');
		}else{
			$this->error('操作失败');
		}
	}


	/**
	 * 客户来源
	 */
	public function SourceList()
	{
		$cookie = cookie('UserId');
        if (empty($cookie)) {
            $this->redirect('/Home/Login/Login');
        }
		$result = D('SourceForm');
		$count = $result->order('id desc')->count();
		$p = getpage($count,10);
		$list = $result->field(true)->order('id desc')->limit($p->firstRow, $p->listRows)->select();
		$this->assign('list',$list);
		$this->assign('page', $p->show()); // 赋值分页输出
		$this->display();
	}

	public function AddSource()
	{
		$this->display();
	}


	public function DoSource()
	{

		if (IS_POST) {
			$data['source'] = $_POST['source'];
			$data['create_time'] = time();
			$data['update_time'] = time();
			$Source = D('SourceForm');
			if (!$Source->create()) {
				$this->error($Source->getError());
			}else{
				if ($Source->add($data)) {
					$this->success('操作成功','/Home/Other/SourceList');
				}else{
					$this->error('操作失败');
				}
			}
		}else{
			$this->error('非法请求');
		}
	}

	public function UpSource($id)
	{
		$Source = D('SourceForm');
		$list = $Source->GetOne($id);
		$this->assign('list',$list);
		$this->display();
	}


	public function DoUpSource($id)
	{
		$data['source'] = $_POST['source'];
		$data['update_time'] = time();
		$result = SourceFormModel::Up($id,$data);
		if ($result) {
			$this->success('操作成功','/Home/Other/SourceList');
		}else{
			$this->error('操作失败');
		}
	}

	public function DeleteSource($id)
	{
		$result = SourceFormModel::DataDelete($id);
		if ($result) {
			$this->success('操作成功','/Home/Other/SourceList');
		}else{
			$this->error('操作失败');
		}
	}
}