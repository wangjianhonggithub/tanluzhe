<?php
namespace Home\Controller;
/**
* 
*/
use Think\Controller;
class LoginController extends Controller
{
	public function Login()
	{
		$this->display();
	}	

	/**
	 * 执行登录
	 */
	public function DoLogin()
	{
		$username = $_POST['username'];
		$password = $_POST['password'];
		if (empty($username )) {
			$this->error('用户名不能为空');
		}
		if (empty($password)) {
			$this->error('请填写密码');
		}
		$res = D('AdminUsers')->where("username='$username'")->find();
		if ($res['password'] != md5($password)) {
			$this->error('密码不正确');
		}else{
			cookie('UserId',$res['id']);
			$this->success('登录成功','/');
		}

	}

	public function LoginOut()
	{
		cookie('UserId',null);
		$this->success('退出成功','/Home/Login/Login');
	}
}