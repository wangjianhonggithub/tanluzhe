<?php
namespace Home\Controller;
/**
* 
*/
use Think\Controller;
class AdminUserController extends Controller
{
	public function AdminUser()
	{
		$cookie = cookie('UserId');
		if (empty($cookie)) {
			$this->redirect('/Home/Login/Login');
		}
		$result = M('admin_users');
		$count = $result->order('id desc')->count();
		$p = getpage($count,10);
		$list = $result->field(true)->order('id desc')->limit($p->firstRow, $p->listRows)->select();
		$this->assign('list',$list);
		$this->assign('page', $p->show()); // 赋值分页输出
		$this->display();
	}

	/**
	 * 添加后台人员
	 */
	public function AddAdminUser()
	{
		$res = M('column')->select();
		$this->assign('list',$res);
		$this->display(); 
	}

	public function DoAdd()
	{
		$data['username'] =$_POST['username'];
		$data['password'] =md5($_POST['password']);
		$data['nickname'] =$_POST['nickname'];
		$data['role'] =implode(',',$_POST['role']);
		$data['identity'] =implode(',',$_POST['identity']);
		$data['create_time'] =time();
		$data['update_time'] =time();
		if (IS_POST) {
			$AdminUser = D('AdminUsers');
			if (!$AdminUser->create()) {
				exit($AdminUser->getError());
			}else{
				$result = $AdminUser->add($data);
				if ($result) {
					$this->success('操作成功','/Home/AdminUser/AdminUser');
				}else{
					$this->error('操作失败');
				}
			}

		}else{
			$this->error('非法请求');
		}
	}

	/**
	 * 显示修改
	 */
	public function AdminUpdate()
	{
		$id = $_GET['id'];
		$AdminUser = D('AdminUsers');
		$result = $AdminUser->find($id);
		$res = M('column')->select();
		$role = explode(',', $result['role']);
		$this->assign('list',$res);
		$this->assign('role',$role);
		$this->assign('result',$result);
		$this->display();
	}
	/**
	 * 执行修改
	 * @Author   CarLos(翟)
	 * @DateTime 2018-03-15
	 * @Email    carlos0608@163.com
	 */
	public function DoUpdate()
	{
		$id = $_GET['id'];
		$data['username'] =$_POST['username'];
		$data['password'] =md5($_POST['password']);
		$data['nickname'] =$_POST['nickname'];
		$data['identity'] =$_POST['identity'];
		$data['role'] =implode(',',$_POST['role']);
		$data['update_time'] =time();
		$AdminUser = D('AdminUsers');
		if ($AdminUser->where("id=$id")->save($data)) {
			$this->success('操作成功','/Home/AdminUser/AdminUser');
		}else{
			$this->error('操作失败');
		}
	}

	public function Delete()
	{
		$id = $_GET['id'];
    	$AdminUser = D('AdminUsers');
    	if($AdminUser->delete($id)){
			$this->success('操作成功');
		}else{
			$this->error('操作失败');
		}
	}
}