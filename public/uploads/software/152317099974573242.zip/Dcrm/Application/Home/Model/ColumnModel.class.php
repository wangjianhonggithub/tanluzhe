<?php
namespace Home\Model;
use Think\Model;
class ColumnModel extends Model
{
	protected $tableName = 'column';
	protected $_validate = array(
	 array('name','require','请填写栏目名'),
	 array('url','require','请填写url'),
	 array('icon','require','请填写icon'),
   	);

   	public static function GetAll()
   	{	
   		$result = M('column')->select();
   		return  $result;
   	}
}