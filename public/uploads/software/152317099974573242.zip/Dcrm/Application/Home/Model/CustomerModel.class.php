<?php 
namespace Home\Model;
use Think\Model;
/**
* 
*/
class CustomerModel extends Model
{
	protected $tableName = 'customer';
	protected $_validate = array(
          array('riqi','require','请填写日期'),
          array('gs_name','require','请填写公司名称'),
      	 array('gs_name','','该公司名称已经被其他同事添加过了',0,'unique',1),
      	 array('kp_name','require','请填写KP姓名'),
      	 array('kp_name','','该KP姓名已经被其他同事添加过了',0,'unique',1),
          array('mobile','require','请填写客户联系方式'),
      	 array('mobile','/^1[3|4|5|8|7][0-9]\d{8}$/','请输入正确的手机号!',0,'regex',1), 
      	 array('mobile','','该客户联系方式已经被其他同事添加过了',0,'unique',1),
      	 array('hangye','require','请填写主营业务'),
   	);

	
}
 ?>