<?php
namespace Home\Model;
/**
* 
*/
use Think\Model;
class SourceTypeModel extends Model
{
	protected $tableName = 'source_type';
	protected $_validate = array(
      	 array('type_name','','次分类已存在',0,'unique',1),
      	 array('type_name','require','请填写类型名称'),
   	);

   	public static function GetAll()
   	{	
   		$result = M('source_type')->select();
   		return  $result;
   	}

   	public static function GetOne($id)
   	{	
   		$result = M('source_type')->find($id);
   		return  $result;
   	}

    public static function Up($id,$data)
   	{	
   		$result = M('source_type')->where("id=$id")->save($data);
   		return  $result;
   	}

   	public static function DataDelete($id)
   	{	
   		$result = M('source_type')->delete($id);
   		return  $result;
   	}
}