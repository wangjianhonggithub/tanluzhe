<?php
namespace Home\Model;
/**
* 
*/
use Think\Model;
class SourceFormModel extends Model
{
	protected $tableName = 'source_form';
	protected $_validate = array(
      	 array('source','','次来源已存在',0,'unique',1),
      	 array('source','require','请填写来源'),
   	);

   	public static function GetAll()
   	{	
   		$result = M('source_form')->select();
   		return  $result;
   	}

   	public static function GetOne($id)
   	{	
   		$result = M('source_form')->find($id);
   		return  $result;
   	}

    public static function Up($id,$data)
   	{	
   		$result = M('source_form')->where("id=$id")->save($data);
   		return  $result;
   	}

   	public static function DataDelete($id)
   	{	
   		$result = M('source_form')->delete($id);
   		return  $result;
   	}
}