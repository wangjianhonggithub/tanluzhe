<?php
namespace Home\Model;
/**
* 
*/
use Think\Model;
class AdminUsersModel extends Model
{
	protected $tableName = 'admin_users';
	protected $_validate = array(
          array('username','require','请填写账号'),
      	 array('username','','帐号名称已经存在！',0,'unique',1),
      	 array('password','require','请填写密码'),
      	 array('nickname','require','请填写昵称'),
   	);

   	public static function GetAll()
   	{	
   		$result = M('admin_users')->select();
   		return  $result;
   	}
}