﻿项目目录
<include file="public:Header" />

<include file="public:footer" />


PHPexcel类文件
<?php

function inserExcel($excel = 'excel')
{
        Loader::import('PHPExcel.Classes.PHPExcel');
        Loader::import('PHPExcel.Classes.PHPExcel.Reader.Excel5');
        Loader::import('PHPExcel.Classes.PHPExcel.IOFactory.PHPExcel_IOFactory');
        //获取表单上传文件
        $file = request()->file('excel');
        $info = $file->validate(['ext' => 'xls'])->move(ROOT_PATH . 'public' . DS . 'uploads');
        if ($info) {
            $exclePath = $info->getSaveName();  //获取文件名
            $file_name = ROOT_PATH . 'public' . DS . 'uploads' . DS . $exclePath;   //上传文件的地址
            $objReader =\PHPExcel_IOFactory::createReader('Excel5');
            $obj_PHPExcel =$objReader->load($file_name, $encode = 'utf-8');  //加载文件内容,编码utf-8
            $excel_array=$obj_PHPExcel->getsheet(0)->toArray();   //转换为数组格式
            array_shift($excel_array);  //删除第一个数组(标题);
            // foreach($excel_array as $k=>$v) {
            //     $city[$k]['Id'] = $v[0];
            //     $city[$k]['code'] = $v[1];
            //     $city[$k]['path'] = $v[2];
            //     $city[$k]['pcode'] = $v[3];
            //     $city[$k]['name'] = $v[4];
            // }
            return $excel_array;
        } else {
            echo $file->getError();
        }
}

?>