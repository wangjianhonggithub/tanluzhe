<?php

/**
 * @Author: Administrator
 * @Date:   2018-03-14 10:36:54
 * @Last Modified by:   Administrator
 * @Last Modified time: 2018-03-23 14:15:54
 */

function getpage($count, $pagesize = 10) {
    $p = new Think\Page($count, $pagesize);
    $p->setConfig('header', '<li class="rows">共<b>%TOTAL_ROW%</b>条记录&nbsp;第<b>%NOW_PAGE%</b>页/共<b>%TOTAL_PAGE%</b>页</li>');
    $p->setConfig('prev', '上一页');
    $p->setConfig('next', '下一页');
    $p->setConfig('last', '末页');
    $p->setConfig('first', '首页');
    $p->setConfig('theme', '%FIRST%%UP_PAGE%%LINK_PAGE%%DOWN_PAGE%%END%%HEADER%');
    $p->lastSuffix = false;//最后一页不显示为总页数
    return $p;
}


function tree($arr,$pid=0,$lev=1)
{
	static $subs = [];
	foreach ($arr as $value) {
	    if ($value['pid'] == $pid){
	        $value['lev'] = $lev;
	        $subs[] = $value;
	        $subs = tree($arr,$value['id'],$lev+1);
	    }
	}
	return $subs;
}

// function GetTree($m,$name='child',$p_id = 0) {
//     $arr = array();
//     foreach ($m as $v) {
//         if ($v['pid'] == $p_id) {
//             $v['child'] = GetTree($m, $name, $v['id']);
//             $arr[] = $v;
//         }
//     }
//     return $arr;
// }
Vendor('PHPExcel.Classes.PHPExcel');
Vendor('PHPExcel.Classes.Reader.Excel5');
Vendor('PHPExcel.Classes.PHPExcel.IOFactory.PHPExcel_IOFactory');
function InsterExcel()
{
	$upload = new \Think\Upload();// 实例化上传类
    $upload->maxSize   =     3145728 ;// 设置附件上传大小
    $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg','xls');// 设置附件上传类型
    $upload->rootPath  =     './Uploads/Excel/'; // 设置附件上传根目录
    $upload->savePath  =     ''; // 设置附件上传（子）目录
    // 上传文件 
    $info   =   $upload->upload();
    if(!$info) {// 上传错误提示错误信息
        $this->error($upload->getError());
    }else{// 上传成功
    	foreach($info as $file){
            $res =  $file['savepath'].$file['savename'];
        }
    	$dirname = $upload->rootPath.$res;
  		// $objReader =\PHPExcel_IOFactory::createReader('Excel5');
  		$objReader = new \PHPExcel_Reader_Excel5();
        $obj_PHPExcel =$objReader->load($dirname, $encode = 'utf-8');  //加载文件内容,编码utf-8
        $excel_array=$obj_PHPExcel->getsheet(0)->toArray();   //转换为数组格式
        array_shift($excel_array);  //删除第一个数组(标题);
        $excelData['excel_array'] = $excel_array;
        $excelData['DirPath'] = $dirname;
        return $excelData;
    }
}
