<?php

namespace App\Http\Controllers\Home;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Banner;
use App\Model\AdvImage;
use App\Model\Caty;
class IndexController extends Controller
{
    public function show()
    {
    	$BannerOne = Banner::GetBannerSelect(1);
    	$BannerTwo = Banner::GetBannerSelect(2);
    	$BannerThree = Banner::GetBannerSelect(3);
        $AdvImage = AdvImage::GetAdvImageOne(1);
        $Caty = Caty::GetCatyHomeAll();
        return view('/Home/Index/Index',[
        	'BannerOne'=>$BannerOne,
        	'BannerTwo'=>$BannerTwo,
            'BannerThree'=>$BannerThree,
            'AdvImage'=>$AdvImage,
        	'CatyInd'=>$Caty,
        ]);
    }
}
