<?php

namespace App\Http\Controllers\Home;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Caty;
use App\Model\Help;
use App\Model\Banner;
use App\Model\AdvImage;
class ListController extends Controller
{
	/**
	 * 软件列表页
	 * @Author   CarLos(翟)
	 * @DateTime 2018-03-29
	 * @Email    carlos0608@163.com
	 * @param    [type]             $id [description]
	 */
    public function SoftwareList($id)
    {
        $BannerS = Banner::GetBannerSelect(6);
        $BannerZ = Banner::GetBannerSelect(7);
        $AdvImage = AdvImage::GetAdvImageOne(1);
        $Caty = Caty::GetCatyOne($id);
    	$CatyList = Caty::GetCatyHomeAll();
        return view('/Home/List/SoftwareList',[
            'CatyNav'=>$Caty,
            'SoftwareBannerS'=>$BannerS,
            'SoftwareBannerZ'=>$BannerZ,
            'AdvImage'=>$AdvImage,
        	'CatyList'=>$CatyList,
        ]);
    }
    /**
     * 帮助中心
     * @Author   CarLos(翟)
     * @DateTime 2018-03-29
     * @Email    carlos0608@163.com
     */
    public function Help()
    {
    	$data = Help::GetHomeHelpAll();
    	return view('/Home/List/HelpList',[
    		'Help'=>$data,
    	]);
    }
}
