<?php

namespace App\Http\Controllers\Home;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Conf;
use App\Model\User;
use Illuminate\Support\Facades\Hash;
use Cookie;
class UserController extends Controller
{
	/**
	 * 软件发布
	 * @Author   CarLos(翟)
	 * @DateTime 2018-03-30
	 * @Email    carlos0608@163.com
	 */
    public function SoftwareRelease()
    {
        return view('/Home/UserCenter/SoftwareRelease');
    }
    /**
     * 执行软件上传
     */
    public function DoSoftwareRelease(Request $request)
    {
        dd($_FILES);
    }




    /**
     * 用户下载记录
     * @Author   CarLos(翟)
     * @DateTime 2018-04-02
     * @Email    carlos0608@163.com
     */
    public function DownloadRecord()
    {
    	return view('/Home/UserCenter/DownloadRecord');
    }

    /**
     * 用户上传记录
     */
    public function UserUpLoad()
    {
        return view('/Home/UserCenter/UserUpLoad');
    }




    /**
     * 用户评论
     */
    public function UserComments()
    {
        return view('/Home/UserCenter/UserComments');
    }

    /**
     * 用户设置 (修改信息)
     * @Author   CarLos(翟)
     * @DateTime 2018-04-02
     * @Email    carlos0608@163.com
     */
    public function UserConf()
    {
        return view('/Home/UserCenter/UserConf');
    }

    /**
     * 修改密码
     * @Author   CarLos(翟)
     * @DateTime 2018-04-02
     * @Email    carlos0608@163.com
     */
    public function UserUpdatePasswd()
    {
        return view('/Home/UserCenter/UserUpdatePasswd');
    }
}
