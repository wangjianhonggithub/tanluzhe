<?php

namespace App\Http\Controllers\Home;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Conf;
use App\Model\User;
use Illuminate\Support\Facades\Hash;
use Cookie;
class LoginController extends Controller
{
    public function Login()
    {
    	$data = Conf::GetConfOne(1);
        return view('/Home/User/Login',[
        	'Login'=>$data,
        ]);
    }

    public function DoLogin(Request $request)
    {
    	$username = $request->username;
        $password = $request->password;
        if (empty($username)&&empty($password)) {
            return back()->with('info','请填写用户名和密码');
        }else{
            $User= User::where('username',$username)->first(); //读取数据库
            if ($User) {
            	if(Hash::check($request->password, $User->password)) {//检测密码
	                if ($User->is_freeze == 1) {
	                    $UserId = Cookie::make('UserId', $User->id);
	                    return redirect('/UserCenter')->with('info',"登录成功")->withCookie($UserId);
	                }else{
	                    return back()->with('info','您的账号已经被禁用');
	                }
	            }else{
	                return back()->with('info','密码不正确');
	            }
            }else{
            	return back()->with('info','账号不正确');
            }
        }
    }





    public function Forgot()
    {
        return view('/Home/User/Forgot');
    }

    /**
     * 检测手机
     */
    public function CheckMobile()
    {
        return view('/Home/User/CheckMobile');
    }


    /**
     * 检测密保
     */
    public function CheckEncrypted()
    {
        return view('/Home/User/CheckEncrypted');
    }


    /**
     * 检测邮箱CheckEmail
     */
    public function CheckEmail()
    {
        return view('/Home/User/CheckEmail');
    }
}
