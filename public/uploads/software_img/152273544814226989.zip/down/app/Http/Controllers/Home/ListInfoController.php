<?php

namespace App\Http\Controllers\Home;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Caty;
use App\Model\Help;
use App\Model\About;
use App\Model\Conf;
use App\Model\AdvImage;
use App\Model\Banner;
class ListInfoController extends Controller
{
	/**
	 * 帮助中心详情
	 * @Author   CarLos(翟)
	 * @DateTime 2018-03-29
	 * @Email    carlos0608@163.com
	 * @param    [type]             $id [description]
	 */
    public function HelpInfo($id)
    {
    	$data = Help::GetOne($id);
    	return view('/Home/ListInfo/HelpInfo',[
    		'HelpInfo'=>$data,
    	]);
    }
   
    public function ContactUs()
    {
        $data = Conf::GetConfOne(1);
    	return view('/Home/ListInfo/ContactUs',[
            'ContactUs'=>$data,
        ]);
    }

    public function AboutUs($id)
    {
    	$data = About::GetAboutOne($id);
    	return view('/Home/ListInfo/AboutUs',[
    		'AboutInfo'=>$data,
    	]);
    }

    public function SoftwareInfo($id)
    {
        $BannerI = Banner::GetBannerSelect(8);
        $AdvImage = AdvImage::GetAdvImageOne(1);
        $CatyList = Caty::GetCatyHomeAll();
        return view('/Home/ListInfo/SoftwareInfo',[
            'SoftwareCaty'=>$CatyList,
            'AdvImage'=>$AdvImage,
            'SoftwareBanner'=>$BannerI,
        ]);
    }
}
